<?php
/**
 * Customize typography
 * @since 1.0
 */

$wp_customize->add_section(
    'pi_typography',
    array(
        'title'     => esc_html__('Setting', 'sunrise'),
        'priority'  => $this->piControlPriority++,
        'panel'     => 'pi_typography_panel'
    )
);

$aFontWeight = get_option('pi_fontweight');
$aFontFamily = get_option('pi_fontfamily');
$aFontWeight = $aFontWeight ? $aFontWeight : false;

if ( !empty($aFontFamily) )
{
    foreach ( piConfigs::$aConfigs['configs']['typography'] as $key )
    {
        $wp_customize->add_setting(
            "pi_style_for_$key",
            array(
                'default'   => '',
                'type'      => '',
                'capability'=> 'edit_theme_options',
                'sanitize_callback' =>  array($this, 'sunrise_sanitize_data')
            )
        );

        $wp_customize->add_control(
            new piTitle(
                $wp_customize,
                "pi_style_for_$key",
                array(
                    "priority" => $this->piControlPriority++,
                    "type"     => "title",
                    "label"    => ucfirst($key),
                    "section"  => "pi_typography",
                    "settings" => "pi_style_for_$key"
                )
            )
        );

        $wp_customize->add_setting(
            "pi_options[typography][$key][fonttype]",
            array(
                'default'           =>  'default',
                'type'              =>  'option',
                'capability'        =>  'edit_theme_options',
                'sanitize_callback' =>  array($this, 'sunrise_sanitize_data')
            )
        );

        $wp_customize->add_control(
            "pi_options[typography][$key][fonttype]",
            array(
                'label'         => esc_html__('Font Type', 'sunrise'),
                'section'       => 'pi_typography',
                'settings'      => "pi_options[typography][$key][fonttype]",
                'priority'      => $this->piControlPriority++,
                'type'          => 'select',
                'choices'       => array(
                                    'default'   => esc_html__('Default', 'sunrise'),
                                    $aFontFamily=> $aFontFamily
                                )
            )
        );

        if ( $aFontWeight )
        {
            $wp_customize->add_setting(
                "pi_options[typography][$key][fontweight]",
                array(
                    'default'           =>  'normal',
                    'type'              =>  'option',
                    'capability'        =>  'edit_theme_options',
                    'sanitize_callback' =>  array($this, 'sunrise_sanitize_data')
                )
            );

            $wp_customize->add_control(
                "pi_options[typography][$key][fontweight]",
                array(
                    'label'         => esc_html__('Font Weight', 'sunrise'),
                    'section'       => 'pi_typography',
                    'settings'      => "pi_options[typography][$key][fontweight]",
                    'priority'      => $this->piControlPriority++,
                    'type'          => 'select',
                    'choices'       => $aFontWeight
                )
            );
        }
    }
}else{
    $wp_customize->add_setting(
        'pi_guide_enter_googlefont',
        array(
            'default'   =>'',
            'type'      =>'',
            'capability'=>'edit_theme_options',
            'sanitize_callback' =>  array($this, 'sunrise_sanitize_data')
        )
    );
    $wp_customize->add_control(
        new piDescription(
            $wp_customize,
            'pi_guide_enter_googlefont',
            array(
                'label'    => sunrise_wp_kses( sprintf(__('You haven\'t configured your googlefont yet, please click go to <a href="%s" target="_blank">here</a> and then enter your googlefont', 'sunrise'), esc_url ( admin_url('options-general.php?page=nexttheme-googlefont'))), false ),
                'section'  => 'pi_typography',
                'settings' => 'pi_guide_enter_googlefont',
                'priority' => $this->piControlPriority++,
                'type'     => 'description'
            )
        )
    );
}