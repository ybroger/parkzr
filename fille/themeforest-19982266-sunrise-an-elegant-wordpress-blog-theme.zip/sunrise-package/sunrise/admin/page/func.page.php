<?php
/**
 * Created by Next-theme
 */


add_action('save_post', 'sunrise_save_page_template_data');
add_action('edit_form_after_title', 'sunrise_add_page_builder_button');

function sunrise_add_page_builder_button()
{
    if ( isset($_GET['post']) )
    {
        $_GET['post'] = (int)$_GET['post'];
        $getTemplateName = get_page_template_slug($_GET['post']);

        if ( $getTemplateName == 'page-template.php' )
        {
            $pageUrl = admin_url('post.php') . '?post='.$_GET['post'].'&amp;action=edit';
            $pageUrl = urlencode($pageUrl);
            $url  = admin_url('customize.php') . '?return='.$pageUrl;
            ?>
            <a class="button button-primary pi-page-templates-button button-large" href="<?php echo esc_url( $url ) ; ?>"><?php esc_html_e('Content Builder', 'sunrise'); ?></a>
        <?php
        }
    }
}

add_action('add_meta_boxes', 'sunrise_page_settings');
function sunrise_page_settings()
{
    add_meta_box(
        'pi_about_contact_page',
        esc_html__('Settings', 'sunrise'),
        'sunrise_page_settings_area',
        'page',
        'advanced',
        'default'
    );
}

function sunrise_page_settings_area($post)
{
    $aSettings = get_post_meta($post->ID, '_pi_special_page', true);
    $aSettings = wp_parse_args($aSettings, array('sup_title'=>'About me'));
    ?>
    <p class="form-group">
        <label for="sup-title" class="form-label"><strong><?php esc_html_e('Sup title', 'sunrise'); ?></strong></label>
        <input type="text" class="wiloke_input form-control" id="sup-title" name="pi_special_page[sup_title]" value="<?php echo esc_html($aSettings['sup_title']); ?>" />
    </p>
    <?php
}


function sunrise_save_page_template_data($postID)
{
    if ( isset($_POST['post_type']) && $_POST['post_type'] == 'page'  )
    {
        if ( isset($_POST['pi_page_template']) )
        {
            $_POST['pi_page_template'] = sunrise_unslashed_before_update($_POST['pi_page_template']);
            update_post_meta($postID, '_pi_page_template', $_POST['pi_page_template']);
        }

        if ( isset($_POST['pi_special_page']) )
        {
            $_POST['pi_special_page'] = sunrise_unslashed_before_update($_POST['pi_special_page']);
            update_post_meta($postID, '_pi_special_page', $_POST['pi_special_page']);
        }
    }
}

