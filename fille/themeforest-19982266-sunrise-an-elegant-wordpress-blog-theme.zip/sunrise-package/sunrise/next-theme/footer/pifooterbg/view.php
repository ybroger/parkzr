<?php
/**
 * Created by Next-theme
 * @since 1.0
 */
function pi_get_footerbg()
{
    return SunriseBlogCustomize::sunrise_refresh_in_customize('pi_options[footer][footerbg]') ? SunriseBlogCustomize::sunrise_refresh_in_customize('pi_options[footer][footerbg]') : SunriseBlogFramework::$piOptions['footer']['footerbg'];
}
