<?php
/**
 * Created by Next-theme
 */

$wp_customize->add_section(
    'pi_page',
    array(
        'title'         => esc_html__('Page', 'sunrise'),
        'capability'    => 'edit_theme_options',
        'panel'         => 'pi_content_panel',
        'priority'      => $this->piSectionPriority++,
        'description'   => esc_html__('The sidebar setting  will change the default sidebar position', 'sunrise')
    )
);


/*Sidebar*/
$wp_customize->add_setting(
    "pi_options[content][sidebar_on_page]",
    array(
        'default'           =>  parent::$piOptions['content']['sidebar_on_page'],
        'type'              => 'option',
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => array($this, 'sunrise_sanitize_data')
    )
);

$wp_customize->add_control('pi_options[content][sidebar_on_page]',
    array(
        'label'     => esc_html__('Sidebar', 'sunrise'),
        'section'   => 'pi_page',
        'settings'  => 'pi_options[content][sidebar_on_page]',
        'priority'  => $this->piControlPriority++,
        'type'      => 'select',
        'choices'   => array(
            'default'     => esc_html__('Default', 'sunrise'),
            'no-sidebar'  => esc_html__('Turn Off', 'sunrise'),
        )
    )
);
/* End / Sharing Box */