<?php
/**
 * Created by Next-theme
 */

add_action('pi_hook_before_copyright', 'pi_add_sidebar_section', 10, 3);
function pi_add_sidebar_section($wp_customize, $piSectionPriority, $piContentPriority)
{
    $wp_customize->add_section(
        'pi_sidebar_section',
        array(
            'title'     => esc_html__('Sidebar', 'sunrise'),
            'priority'  => 6
        )
    );

    $wp_customize->add_setting(
        'pi_options[sidebar_layout]',
        array(
            'type'              => 'option',
            'default'           => 'right-sidebar',
            'capability'        => 'edit_theme_options',
            'sanitize_callback' => 'sunrise_sanitize_data'
        )
    );

    $wp_customize->add_control(
        'pi_option[sidebar_layout]',
        array(
            'label'         => esc_html__('Layout', 'sunrise'),
            'type'          => 'select',
            'priority'      => $piContentPriority,
            'section'       => 'pi_sidebar_section',
            'settings'      => 'pi_options[sidebar_layout]',
            'choices'       => array(
                'right-sidebar'  => esc_html__('Right', 'sunrise'),
                'left-sidebar'   => esc_html__('Left', 'sunrise'),
                'no-sidebar'     => esc_html__('No', 'sunrise')
            )
        )
    );

    $wp_customize->add_setting(
        'pi_options[sidebar_sticky]',
        array(
            'type'              => 'option',
            'default'           => 'is-sidebarsticky',
            'capability'        => 'edit_theme_options',
            'sanitize_callback' => 'sunrise_sanitize_data'
        )
    );

    $wp_customize->add_control(
        'pi_option[sidebar_sticky]',
        array(
            'label'         => esc_html__('Sticky Sidebar', 'sunrise'),
            'type'          => 'select',
            'priority'      => $piContentPriority,
            'section'       => 'pi_sidebar_section',
            'settings'      => 'pi_options[sidebar_sticky]',
            'choices'       => array(
                'is-sidebarsticky'      => esc_html__('Yes', 'sunrise'),
                'is-not-sidebarsticky'  => esc_html__('No', 'sunrise')
            )
        )
    );
}