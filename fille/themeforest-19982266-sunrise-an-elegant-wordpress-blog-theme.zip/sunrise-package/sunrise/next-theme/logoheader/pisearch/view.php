<?php
/**
 * Created by Next-theme
 * @since 1.0
 */

function pi_render_search_description($showingTitle = false)
{
    $content = SunriseBlogCustomize::sunrise_refresh_in_customize("pi_options[logoheader][description]") ? SunriseBlogCustomize::sunrise_refresh_in_customize("pi_options[logoheader][description]") : '';
    
    if ( empty($content) && isset(SunriseBlogFramework::$piOptions['logoheader']['description']) )
    {
        $content = SunriseBlogFramework::$piOptions['logoheader']['description'];
    }

    if ( empty($content) )
    {
        $content = 'Click The Icon To Show Search';
    }

    return $content;
}

function pi_render_search()
{
    $search = SunriseBlogCustomize::sunrise_refresh_in_customize('pi_options[logoheader][search]') ? SunriseBlogCustomize::sunrise_refresh_in_customize('pi_options[logoheader][search]') : SunriseBlogFramework::$piOptions['logoheader']['search'];

    if ( empty($search) )
    {
        $search = 1;
    }

    if ( $search != 'disable' && !empty($search) )
    {
        do_action('pi_before_render_search');
        ?>
        <!-- Page search -->
        <div class="page-search">
            <div class="tb">
                <div class="tb-cell">
                    <form action="<?php echo esc_url(home_url('/')); ?>" method="get" >
                        <input name="s" type="text" placeholder="<?php esc_html_e('Search and hit enter', 'sunrise'); ?>">
                    </form>
                </div>
            </div>
        </div>
        <!-- / Page search -->
        <?php
        do_action('pi_after_render_search');
    }
}
