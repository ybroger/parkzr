<?php
/*Template Name: Page Template */
$aTemplate = SunriseBlogFramework::sunrise_get_page_template_slug($post->ID);
$optionKey = SunriseBlogFramework::pi_parse_option_key($aTemplate);
SunriseBlogFramework::$piOptions = get_option($optionKey);
if ( empty(SunriseBlogFramework::$piOptions) )
{
    SunriseBlogFramework::$piOptions = piConfigs::$aConfigs['pi_options'];
}else{
	$aGeneralOptions = get_option('pi_options');

	if ( !function_exists('array_replace_recursive') && current_user_can('edit_theme_options') )
	{
		esc_html_e('Current PHP version is smaller 5.3.x, please log into cPanel and upgrade to higher.', 'sunrise');
		wp_die();
	}else{
		if ( !$aGeneralOptions )
		{
			SunriseBlogFramework::$piOptions = array_replace_recursive(piConfigs::$aConfigs['pi_options'], SunriseBlogFramework::$piOptions);
		}else{
			SunriseBlogFramework::$piOptions = array_replace_recursive($aGeneralOptions, SunriseBlogFramework::$piOptions);
		}
	}
}

get_template_part("index");
