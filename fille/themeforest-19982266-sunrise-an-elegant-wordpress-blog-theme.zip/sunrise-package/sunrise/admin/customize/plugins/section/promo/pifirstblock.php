<?php
/**
 * Created by Next-theme
 */

$wp_customize->add_section('pi_promo_firstblock', array(
    'title'     => esc_html__('First Block', 'sunrise'),
    'panel'     => 'pi_promo_panel',
    'priority'  => $this->piSectionPriority++
));


$wp_customize->add_setting(
    "pi_options[pi_promo][firstblock][heading]",
    array(
        'default'       =>  '',
        'type'          => 'option',
        'capability'    => 'edit_theme_options',
        'sanitize_callback' => array($this, 'sunrise_sanitize_data')
    )
);
$wp_customize->add_control('pi_options[pi_promo][firstblock][heading]',
    array(
        'label' 	=> esc_html__('Heading', 'sunrise'),
        'section' 	=> 'pi_promo_firstblock',
        'settings' 	=> 'pi_options[pi_promo][firstblock][heading]',
        'priority'  => $this->piControlPriority++,
        'type' 		=> 'text'
    )
);

$wp_customize->add_setting(
    "pi_options[pi_promo][firstblock][description]",
    array(
        'default'       =>  '',
        'type'          => 'option',
        'capability'    => 'edit_theme_options',
        'sanitize_callback' => array($this, 'sunrise_sanitize_data')
    )
);
$wp_customize->add_control('pi_options[pi_promo][firstblock][description]',
    array(
        'label'     => esc_html__('Description', 'sunrise'),
        'section'   => 'pi_promo_firstblock',
        'settings'  => 'pi_options[pi_promo][firstblock][description]',
        'priority'  => $this->piControlPriority++,
        'type'      => 'text'
    )
);

$wp_customize->add_setting(
    "pi_options[pi_promo][firstblock][link]",
    array(
        'default'       =>  '',
        'type'          => 'option',
        'capability'    => 'edit_theme_options',
        'sanitize_callback' => array($this, 'sunrise_sanitize_data')
    )
);
$wp_customize->add_control('pi_options[pi_promo][firstblock][link]',
    array(
        'label' 	=> esc_html__('Link', 'sunrise'),
        'section' 	=> 'pi_promo_firstblock',
        'settings' 	=> 'pi_options[pi_promo][firstblock][link]',
        'priority'  => $this->piControlPriority++,
        'type' 		=> 'text'
    )
);

$wp_customize->add_setting(
    "pi_options[pi_promo][firstblock][target]",
    array(
        'default'       =>  '_self',
        'type'          => 'option',
        'capability'    => 'edit_theme_options',
        'sanitize_callback' => array($this, 'sunrise_sanitize_data')
    )
);
$wp_customize->add_control('pi_options[pi_promo][firstblock][target]',
    array(
        'label' 	=> esc_html__('When user click on this box, where to open the link.', 'sunrise'),
        'section' 	=> 'pi_promo_firstblock',
        'settings' 	=> 'pi_options[pi_promo][firstblock][target]',
        'priority'  => $this->piControlPriority++,
        'type' 		=> 'select',
        'choices'   => array(
            '_self'  => esc_html__('Self', 'sunrise'),
            '_blank' => esc_html__('New Window', 'sunrise')
        )
    )
);


$wp_customize->add_setting(
    "pi_options[pi_promo][firstblock][bg_img]",
    array(
        'default'       =>  '',
        'type'          => 'option',
        'capability'    => 'edit_theme_options',
        'sanitize_callback' => array($this, 'sunrise_sanitize_data')
    )
);
$wp_customize->add_control(
    new WP_Customize_Image_Control(
        $wp_customize,
        'pi_options[pi_promo][firstblock][bg_img]',
        array(
            'label'     => esc_html__('Background Image', 'sunrise'),
            'section'   => 'pi_promo_firstblock',
            'settings'  => 'pi_options[pi_promo][firstblock][bg_img]',
            'priority'=>$this->piControlPriority++
        )
    )
);
