<?php
/**
 * Created by Next-theme
 */

$wp_customize->add_section('pi_post', array(
    'title'     => esc_html__('Post', 'sunrise'),
    'panel'     => 'pi_content_panel',
    'priority'  => $this->piSectionPriority++
));


/*Related Posts*/

/*Relate post title*/
$wp_customize->add_setting(
    'pi_options_relate_posts_title',
    array(
        'type'              =>'',
        'default'           =>'',
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => array($this, 'sunrise_sanitize_data')
    )
);

$wp_customize->add_control(
    new piTitle(
        $wp_customize,
        'pi_options_relate_posts_title',
        array(
            'label'     => esc_html__('Related Posts', 'sunrise'),
            'type'      => 'title',
            'priority'  => $this->piControlPriority++,
            'settings'  => 'pi_options_relate_posts_title',
            'section'   => 'pi_post'
        )
    )
);


/*Toggle*/
$wp_customize->add_setting(
    "pi_options[content][related_posts][toggle]",
    array(
        'default'       =>  parent::$piOptions['content']['related_posts']['toggle'],
        'type'          => 'option',
        'capability'    => 'edit_theme_options',
        'sanitize_callback' => array($this, 'sunrise_sanitize_data')
    )
);

$wp_customize->add_control('pi_options[content][related_posts][toggle]',
    array(
        'label' => esc_html__('Enable/Disable', 'sunrise'),
        'section' => 'pi_post',
        'settings' => 'pi_options[content][related_posts][toggle]',
        'priority'      => $this->piControlPriority++,
        'type' => 'select',
        'choices' => array(
            1 => esc_html__('Enable', 'sunrise'),
            0 => esc_html__('Disable', 'sunrise')
        ),
    )
);

/*Title*/
$wp_customize->add_setting(
    "pi_options[content][related_posts][title]",
    array(
        'default'       =>  parent::$piOptions['content']['related_posts']['title'],
        'type'          => 'option',
        'capability'    => 'edit_theme_options',
        'sanitize_callback' => array($this, 'sunrise_sanitize_data')
    )
);

$wp_customize->add_control('pi_options[content][related_posts][title]',
    array(
        'label'    => esc_html__('Title', 'sunrise'),
        'section'  => 'pi_post',
        'settings' => 'pi_options[content][related_posts][title]',
        'priority' => $this->piControlPriority++,
        'type'     => 'text',
    )
);

/*Get By*/
$wp_customize->add_setting(
    "pi_options[content][related_posts][get_by]",
    array(
        'default'       =>  parent::$piOptions['content']['related_posts']['get_by'],
        'type'          => 'option',
        'capability'    => 'edit_theme_options',
        'sanitize_callback' => array($this, 'sunrise_sanitize_data')
    )
);

$wp_customize->add_control('pi_options[content][related_posts][get_by]',
    array(
        'label' => esc_html__('Get by', 'sunrise'),
        'section' => 'pi_post',
        'settings' => 'pi_options[content][related_posts][get_by]',
        'priority'      => $this->piControlPriority++,
        'type' => 'select',
        'choices' => array(
            'category' => 'Category',
            'tags' => 'Tags'
        ),
    )
);

/*Number Of Posts*/
$wp_customize->add_setting(
    "pi_options[content][related_posts][number_of_posts]",
    array(
        'default'       =>  parent::$piOptions['content']['related_posts']['number_of_posts'],
        'type'          => 'option',
        'capability'    => 'edit_theme_options',
        'sanitize_callback' => array($this, 'sunrise_sanitize_data')
    )
);

$wp_customize->add_control('pi_options[content][related_posts][number_of_posts]',
    array(
        'label'    => esc_html__('Number Of Posts', 'sunrise'),
        'section'  => 'pi_post',
        'settings' => 'pi_options[content][related_posts][number_of_posts]',
        'priority' => $this->piControlPriority++,
        'type'     => 'text',
    )
);
