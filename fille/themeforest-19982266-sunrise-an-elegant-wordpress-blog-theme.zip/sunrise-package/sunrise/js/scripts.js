
(function($) {
    "use strict";
    /*==============================
        Is mobile
    ==============================*/
    var isMobile = {
        Android: function() {
            return navigator.userAgent.match(/Android/i);
        },
        BlackBerry: function() {
            return navigator.userAgent.match(/BlackBerry/i);
        },
        iOS: function() {
            return navigator.userAgent.match(/iPhone|iPad|iPod/i);
        },
        Opera: function() {
            return navigator.userAgent.match(/Opera Mini/i);
        },
        Windows: function() {
            return navigator.userAgent.match(/IEMobile/i);
        },
        any: function() {
            return (isMobile.Android() || isMobile.BlackBerry() || isMobile.iOS() || isMobile.Opera() || isMobile.Windows());
        }
    }

    /*==============================
        Image cover
    ==============================*/
    $.fn.imageCover = function() {
        $(this).each(function() {
            var self = $(this),
                image = self.find('img'),
                heightWrap = self.outerHeight(),
                widthImage = image.outerWidth(),
                heightImage = image.outerHeight();
            if (heightImage < heightWrap) {
                image.css({
                    'height': '100%',
                    'width': 'auto'
                });
            }
        });
    }

    function inputPlaceholder() {
        var $ph = $('input[type="search"], input[type="text"], input[type="email"], textarea');
        $ph.each(function() {
            var value = $(this).val();
            $(this).focus(function() {
                if ($(this).val() === value) {
                    $(this).val('');
                }
            });
            $(this).blur(function() {
                if ($(this).val() === '') {
                    $(this).val(value);
                }
            });
        });
    }

    function backgroundImage()
    {
        var section = $('.background-image');
        section.each(function()
        {
            var $this = $(this);
            if ($this.attr('data-background-image')) {
                var bg = $this.attr('data-background-image');
                $this.css('background-image', 'url(' + bg + ')');
            }
        });
    }

    function owlCarouselSlider() {
        var navslider = ['<i class="fa fa-angle-left"></i>', '<i class="fa  fa-angle-right"></i>'];
        if ($('.featured-slider').length > 0)
        {
            var setAutoplay = 10000, $featuredSlider = $('.featured-slider');
            $featuredSlider.owlCarousel({
                autoplay: setAutoplay,
                smartSpeed: 800,
                nav: true,
                loop: true,
                dots: true,
                items: 1,
                autoheight: true,
                addClassActive: true,
                navText: navslider
            });

            $featuredSlider.on('changed.owl.carousel', function(event) {
                var el   = $(event.target); 
                el.find('.timer-slider').css({
                    '-webkit-animation': 'none',
                    '-moz-animation': 'none',
                    'animation': 'none'
                });
                setTimeout(function() {
                    el.find('.timer-slider').css({
                        '-webkit-animation': 'timer ' + setAutoplay + 'ms linear infinite',
                        '-moz-animation': 'timer ' + setAutoplay + 'ms linear infinite',
                        'animation': 'timer ' + setAutoplay + 'ms linear infinite'
                    });
                }, 100);
            })

            if ( typeof _disableTimeSlider == 'undefined' )
            {
                $featuredSlider.prepend('<div class="timer-slider"></div>');

                $('.timer-slider').css({
                    '-webkit-animation': 'timer ' + setAutoplay + 'ms linear infinite',
                    '-moz-animation': 'timer ' + setAutoplay + 'ms linear infinite',
                    'animation': 'timer ' + setAutoplay + 'ms linear infinite',
                });
            }

            $(window).on('resize', function() {
                setTimeout(function() {
                    var windowWidth = $('.featured-slider').width(),
                        itemFeaturedWidth = $('.featured-slider').find('.item-content').width(),
                        setOwlNavWidth = (windowWidth - itemFeaturedWidth) / 2;
                    $('.featured-slider').find('.owl-next, .owl-prev').css('width', setOwlNavWidth);
                }, 100);
            }).trigger('resize');
        }

        if ($('.images-slider').length > 0)
        {
            var $imgSlider = $('.images-slider');
            $imgSlider.owlCarousel({
                autoPlay: false,
                smartSpeed: 300,
                nav: false,
                loop: true,
                dots: true,
                items: 1,
                autoHeight: true,
                navText: navslider
            });

            $imgSlider.on('changed.owl.carousel', function(event) {
                var el   = $(event.target); 
                el.magnificPopup({
                    delegate: 'a',
                    type: 'image',
                    closeOnContentClick: false,
                    closeBtnInside: false,
                    mainClass: 'pp-gallery mfp-with-zoom mfp-img-mobile',
                    image: {
                        verticalFit: true,
                    },
                    gallery: {
                        enabled: true
                    },
                    zoom: {
                        enabled: true,
                        duration: 300, // don't foget to change the duration also in CSS
                        opener: function(element) {
                            return element.find('img');
                        }
                    },
                });
            })
        }

        if ($('.widget-slider').length > 0)
        {
            $('.widget-slider').owlCarousel({
                autoPlay: false,
                smartSpeed: 300,
                nav: true,
                dots: false,
                items: 1,
                autoHeight: true,
                navText: navslider,
                loop: true
            });
        }
    }

    function tiledGallery()
    {
        if ($('.tiled-gallery').length)
        {
            var tiledItemSpacing = 10;
            $('.tiled-gallery').wrap('<div class="tiled-gallery-row"></div>');
            $('.tiled-gallery').parent().css('margin', -tiledItemSpacing);
            $('.tiled-gallery').justifiedGallery({
                rowHeight: 230,
                lastRow : 'justify',
                margins: tiledItemSpacing,
                waitThumbnailsLoad: false
            });
        }
    }

    function popup() {
        $('.tiled-gallery').magnificPopup({
            delegate: 'a',
            type: 'image',
            closeOnContentClick: false,
            closeBtnInside: false,
            mainClass: 'pp-gallery mfp-with-zoom mfp-img-mobile',
            image: {
                verticalFit: true,
            },
            gallery: {
                enabled: true
            },
            zoom: {
                enabled: true,
                duration: 300, // don't foget to change the duration also in CSS
                opener: function(element) {
                    return element.find('img');
                }
            },
        });
    }

    function socialAndsearch() {
        $('.toggle-social').on('click', function() {
            $('.page-social').fadeIn(500);
        });

        $('.page-social').on('click', function() {
            $('.page-social').fadeOut(500);
        });
        $('.page-social .tb-cell div').on('click', function(e) {
            e.stopPropagation();
        });

        $('.toggle-search').on('click', function() {
            $('.page-search').fadeIn(500);
            $('.page-search input').focus();
        });

        $('.page-search').on('click', function() {
            $('.page-search').fadeOut(500);
        });
        $('.page-search .tb-cell form').on('click', function(e) {
            e.stopPropagation();
        });
    }

    function piCheckSearchSocial()
    {
        var i = 0;
        if ( $(".page-social").length == 0 )
        {
            $(".toggle-social.item").remove();
            i =  i+1;
        }
        if ( $(".page-search").length == 0 )
        {
            $(".toggle-search.item").remove();
            i = i + 1;
        }

        if ( i == 2 )
        {
            $('.header-right').remove();
        }
    }

    function piAddFullScreen()
    {
        var selectors = [
            'iframe[src*="player.vimeo.com"]',
            'iframe[src*="youtube.com"]',
            'iframe[src*="youtube-nocookie.com"]',
            'iframe[src*="kickstarter.com"][src*="video.html"]',
            'object',
            'embed'
        ];

        $("article.post").each(function(){
            var $allVideos = $(this).find(selectors.join(','));

            $allVideos.each(function()
            {

                if ( !$(this).hasClass('embed-responsive-item') )
                {
                    $(this).addClass("embed-responsive-item");
                    if ( !$(this).parent().hasClass("embed-responsive") )
                    {
                        $(this).wrap('<div class="embed-responsive embed-responsive-16by9"></div>');
                    }
                }
            })
        })
    }

    function piRemoveEmpty()
    {
        if ( $("#comments .comments-inner-wrap").children().length == 0 )
        {
            $("#comments").remove();
        }

        var _i = 1;
        $(".footer-content").children().each(function(){
            if ( $(this).children().length == 0 )
            {
                $(this).remove();
                _i++;
            }

            if ( _i == 4 )
            {
                $('.footer-content').remove();
            }
        })
    }

    function subToggle()
    {
        if ($('.pi-menulist').find('.submenu-toggle').length === 0) {
            $('.menu-item-has-children')
                .children('a')
                .after('<span class="submenu-toggle"><i class="fa fa-angle-right"></i></span>');
            $('.pi-menulist').on('click', '.submenu-toggle', function(evt) {
                evt.preventDefault();
                $(this)
                    .siblings('.sub-menu')
                    .addClass('sub-menu-active');
                $(this).closest('ul').addClass('overflow-hidden');
            });
        }
    }

    function submenuBack() {
        $('.pi-menulist .sub-menu').each(function() {
            var $this = $(this);
            if ($this.find('.back-mb').length === 0) {
                $this
                    .prepend('<li class="back-mb"><a href="#">Back</a></li>');
            }
            $('.pi-menulist').on('click', '.back-mb a', function(evt) {
                evt.preventDefault();
                $(this)
                    .parent()
                    .parent()
                    .removeClass('sub-menu-active');
                $(this).parent().parent().parent().parent().removeClass('overflow-hidden');
            });
        });
    }

    function responsiveMenu()
    {
        $('.toggle-menu').on('click', function() {
            $(this).toggleClass('toggle-active');
            $('.pi-navigation').toggleClass('pi-navigation-active');
        });

        $(window).resize(function() {
            var windowWidth = window.innerWidth;
            if (windowWidth <= 991) {
                subToggle();
                submenuBack();
            } else {
                $('.submenu-toggle, .back-mb').remove();
            }
        }).trigger("resize");
    }

    $.fn.numberLine = function(opts)
    {
        $(this).each( function () {
            var $this = $(this),
                defaults = {
                    numberLine: 0
                },
                data = $this.data(),
                dataTemp = $.extend(defaults, opts),
                options = $.extend(dataTemp, data);

            if (!options.numberLine)
                return false;

            $this.bind('customResize', function(event) {
                event.stopPropagation();
                reInit();
            }).trigger('customResize');
            $(window).resize( function () {
                $this.trigger('customResize');
            })
            function reInit() {
                var fontSize = parseInt($this.css('font-size')),
                    lineHeight = parseInt($this.css('line-height')),
                    overflow = fontSize * (lineHeight / fontSize) * options.numberLine;

                $this.css({
                    'display': 'block',
                    'max-height': overflow,
                    'overflow': 'hidden'
                });
            }
        })
    }

    function piLazyLoad()
    {
        $("img.lazy").lazyload({
            effect : "fadeIn"
        });
    }

    function movePageTitle() 
    {
        if( $('.page-template .no-sidebar .category-page-title').length ) 
        {
            if( $('.page-template .no-sidebar .pi-content').length ) 
            {
                var $page_title = $('.page-template .no-sidebar .category-page-title').clone();
                $('.page-template .no-sidebar .category-page-title').remove();
                $('.page-template .no-sidebar .pi-content').prepend($page_title)
            }
        }
     }
    
    // Fix menu screen < 600
    
    function fixMenu() {    

        var window_width;

        $(window).on('resize', function(event) {
            event.preventDefault();
            window_width = $(window).innerWidth();

            if( window_width <= 600 && $('#wpadminbar').length ) {
                $('#wpadminbar').css('position', 'fixed');
            }  else {
                $('#wpadminbar').css('position', '');
            }
        }).trigger('resize');
    }

    $(window).load(function() {
        inputPlaceholder();
        $('.image-cover, .images-slider .item, .about-author .image, .related-post-item .image-wrap, .pi-grid .pi-content .images, .pi-list .pi-content .images, .post-link ~ .images').imageCover();
    });

    $(window).resize(function() {
        if ($('.pi-sidebar').length == 0) 
        {
            if (window.innerWidth >= 1230) {
                if ( !$('.main-content').hasClass('pi-grid-first-large') ) 
                {
                    $('.pi-grid').find('.pi-grid-item:nth-child(2n+1)').css('clear', 'none');
                    $('.pi-grid').find('.pi-grid-item:nth-child(3n+1)').css('clear', 'both');
                } 
                if ( $('.main-content').hasClass('pi-grid-first-large') )  {
                    $('.pi-grid').find('.pi-grid-item:nth-child(2n)').css('clear', 'none');
                    $('.pi-grid').find('.pi-grid-item:nth-child(3n+2)').css('clear', 'both');
                }
            } else {
                if (!$('.main-content').hasClass('pi-grid-first-large')) {
                    $('.pi-grid').find('.pi-grid-item:nth-child(3n+1)').css('clear', 'none');
                    $('.pi-grid').find('.pi-grid-item:nth-child(2n+1)').css('clear', 'both');
                } 
                if ($('.main-content').hasClass('pi-grid-first-large')) {
                    $('.pi-grid').find('.pi-grid-item:nth-child(3n+2)').css('clear', 'none');
                    $('.pi-grid').find('.pi-grid-item:nth-child(2n)').css('clear', 'both');
                }
            }

        }
        // Sticky sidebar
        if (window.innerWidth >= 992) {
            var headerHeight = $('.pi-header-fixed').outerHeight();
            if ($('.pi-nav-page').length > 0) {
                $('.pi-sidebar').css('padding-bottom', $('.pi-nav-page').outerHeight() + 20);
            } else if ($('.pi-pagination').length > 0) {
                $('.pi-sidebar').css('padding-bottom', $('.pi-pagination').outerHeight());
            } else {
                $('.pi-sidebar .widget:last-child').css('margin-bottom', 0);
            }

            if ( $('.pi-sidebar.is-sidebarsticky').length  )
            {
                $('.pi-sidebar.is-sidebarsticky, .pi-content').theiaStickySidebar({
                    updateSidebarHeight: true,
                    additionalMarginTop: headerHeight
                }); 
            }
        }
    }).trigger('resize');
    
    $(document).ready(function()
    {
        fixMenu();
        responsiveMenu();
        $('.pi-grid').find('.pi-grid-item, .pi-nav-page').wrapAll('<div class="pi-row"></div>');

        if ($('.pi-sidebar').length) 
        {
            if (!$('.main-content').hasClass('pi-grid-first-large')) {
                $('.pi-grid').find('.pi-grid-item:nth-child(2n+1)').css('clear', 'both');
            } else {
                $('.pi-grid').find('.pi-grid-item:nth-child(2n)').css('clear', 'both');
            }
        }

        owlCarouselSlider();
        piCheckSearchSocial();
        backgroundImage();
        piAddFullScreen();
        piRemoveEmpty();
        tiledGallery();
        socialAndsearch();
        popup();
        if ( isMobile.any() )
        {
            $(".tiled-gallery").addClass("tiled-gallery-mobile");
        }

        $('[data-number-line]').numberLine();

        $('.pi-grid .post-entry p').numberLine(
        {
            numberLine: 4
        });
        $('.pi-list .post-entry p').numberLine(
        {
            numberLine: 3
        });

        if (window.innerWidth > 768) {
            $('.pi-grid.right-sidebar .pi-grid-item:nth-child(odd), .pi-grid.left-sidebar .pi-grid-item:nth-child(odd)').each(function() {
                var $this = $(this),
                    postTitle = $this.find('.post-title'),
                    postTitleNext = $this.next().find('.post-title'),
                    postTitlePrev = $this.prev().find('.post-title'),
                    postTitleHeight = postTitle.innerHeight(),
                    postTitleNextHeight = postTitleNext.innerHeight(),
                    postTitlePrevHeight = postTitlePrev.innerHeight(),
                    postEntry = $this.find('.post-entry'),
                    postEntryNext = $this.next().find('.post-entry'),
                    postEntryPrev = $this.prev().find('.post-entry'),
                    postEntryHeight = postEntry.innerHeight(),
                    postEntryNextHeight = postEntryNext.innerHeight(),
                    postEntryPrevHeight = postEntryPrev.innerHeight();

                if ($('.pi-grid').hasClass('pi-grid-first-large') == true) {
                    if (postTitleHeight > postTitlePrevHeight) {
                        postTitlePrev.append('<div class="fix-post" style="height:' + (postTitleHeight - postTitlePrevHeight) + 'px"></div>')
                    } else {
                        postTitle.append('<div class="fix-post" style="height:' + (postTitlePrevHeight - postTitleHeight) + 'px"></div>')
                    }
                    if (postEntryHeight > postEntryPrevHeight) {
                        postEntryPrev.append('<div class="fix-post" style="height:' + (postEntryHeight - postEntryPrevHeight) + 'px"></div>')
                    } else {
                        postEntry.append('<div class="fix-post" style="height:' + (postEntryPrevHeight - postEntryHeight) + 'px"></div>')
                    } 
                } else {
                    if (postTitleHeight > postTitleNextHeight) {
                        postTitleNext.append('<div class="fix-post" style="height:' + (postTitleHeight - postTitleNextHeight) + 'px"></div>')
                    } else {
                        postTitle.append('<div class="fix-post" style="height:' + (postTitleNextHeight - postTitleHeight) + 'px"></div>')
                    }
                    if (postEntryHeight > postEntryNextHeight) {
                        postEntryNext.append('<div class="fix-post" style="height:' + (postEntryHeight - postEntryNextHeight) + 'px"></div>')
                    } else {
                        postEntry.append('<div class="fix-post" style="height:' + (postEntryNextHeight - postEntryHeight) + 'px"></div>')
                    } 
                }

            });
        }
        if (window.innerWidth >= 1230) {
            $('.pi-grid.no-sidebar .pi-grid-item:nth-child(3n+1)').each(function() {
                var $this = $(this),
                    postTitle = $this.find('.post-title'),
                    postTitleNext = $this.next().find('.post-title'),
                    postTitleNextNext = $this.next().next().find('.post-title'),
                    postTitleNextNextNext = $this.next().next().next().find('.post-title'),
                    postTitleHeight = postTitle.innerHeight(),
                    postTitleNextHeight = postTitleNext.innerHeight(),
                    postTitleNextNextHeight = postTitleNextNext.innerHeight(),
                    postTitleNextNextNextHeight = postTitleNextNextNext.innerHeight(),
                    postEntry = $this.find('.post-entry'),
                    postEntryNext = $this.next().find('.post-entry'),
                    postEntryNextNext = $this.next().next().find('.post-entry'),
                    postEntryNextNextNext = $this.next().next().next().find('.post-entry'),
                    postEntryHeight = postEntry.innerHeight(),
                    postEntryNextHeight = postEntryNext.innerHeight(),
                    postEntryNextNextHeight = postEntryNextNext.innerHeight(),
                    postEntryNextNextNextHeight = postEntryNextNextNext.innerHeight();

                if ($('.pi-grid').hasClass('pi-grid-first-large') == true) {
                    if (postTitleNextHeight > postTitleNextNextHeight) {
                        postTitleNextNext.append('<div class="fix-post" style="height:' + (postTitleNextHeight - postTitleNextNextHeight) + 'px"></div>')
                    } else {
                        postTitleNext.append('<div class="fix-post" style="height:' + (postTitleNextNextHeight - postTitleNextHeight) + 'px"></div>')
                    }
                    if (postTitleNextHeight > postTitleNextNextNextHeight) {
                        postTitleNextNextNext.append('<div class="fix-post" style="height:' + (postTitleNextHeight - postTitleNextNextNextHeight) + 'px"></div>')
                    } else {
                        postTitleNext.append('<div class="fix-post" style="height:' + (postTitleNextNextNextHeight - postTitleNextHeight) + 'px"></div>')
                    }
                    if (postTitleNextNextHeight > postTitleNextNextNextHeight) {
                        postTitleNextNextNext.append('<div class="fix-post" style="height:' + (postTitleNextNextHeight - postTitleNextNextNextHeight) + 'px"></div>')
                    } else {
                        postTitleNextNext.append('<div class="fix-post" style="height:' + (postTitleNextNextNextHeight - postTitleNextNextHeight) + 'px"></div>')
                    }
                    if (postEntryNextHeight > postEntryNextNextHeight) {
                        postEntryNextNext.append('<div class="fix-post" style="height:' + (postEntryNextHeight - postEntryNextNextHeight) + 'px"></div>')
                    } else {
                        postEntryNext.append('<div class="fix-post" style="height:' + (postEntryNextNextHeight - postEntryNextHeight) + 'px"></div>')
                    }
                    if (postEntryNextHeight > postEntryNextNextNextHeight) {
                        postEntryNextNextNext.append('<div class="fix-post" style="height:' + (postEntryNextHeight - postEntryNextNextNextHeight) + 'px"></div>')
                    } else {
                        postEntryNext.append('<div class="fix-post" style="height:' + (postEntryNextNextNextHeight - postEntryNextHeight) + 'px"></div>')
                    }
                    if (postEntryNextNextHeight > postEntryNextNextNextHeight) {
                        postEntryNextNextNext.append('<div class="fix-post" style="height:' + (postEntryNextNextHeight - postEntryNextNextNextHeight) + 'px"></div>')
                    } else {
                        postEntryNextNext.append('<div class="fix-post" style="height:' + (postEntryNextNextNextHeight - postEntryNextNextHeight) + 'px"></div>')
                    }
                } else {
                    if (postTitleHeight > postTitleNextHeight) {
                        postTitleNext.append('<div class="fix-post" style="height:' + (postTitleHeight - postTitleNextHeight) + 'px"></div>')
                    } else {
                        postTitle.append('<div class="fix-post" style="height:' + (postTitleNextHeight - postTitleHeight) + 'px"></div>')
                    }
                    if (postTitleHeight > postTitleNextNextHeight) {
                        postTitleNextNext.append('<div class="fix-post" style="height:' + (postTitleHeight - postTitleNextNextHeight) + 'px"></div>')
                    } else {
                        postTitle.append('<div class="fix-post" style="height:' + (postTitleNextNextHeight - postTitleHeight) + 'px"></div>')
                    }
                    if (postTitleNextHeight > postTitleNextNextHeight) {
                        postTitleNextNext.append('<div class="fix-post" style="height:' + (postTitleNextHeight - postTitleNextNextHeight) + 'px"></div>')
                    } else {
                        postTitleNext.append('<div class="fix-post" style="height:' + (postTitleNextNextHeight - postTitleNextHeight) + 'px"></div>')
                    }
                    if (postEntryHeight > postEntryNextHeight) {
                        postEntryNext.append('<div class="fix-post" style="height:' + (postEntryHeight - postEntryNextHeight) + 'px"></div>')
                    } else {
                        postEntry.append('<div class="fix-post" style="height:' + (postEntryNextHeight - postEntryHeight) + 'px"></div>')
                    }
                    if (postEntryHeight > postEntryNextNextHeight) {
                        postEntryNextNext.append('<div class="fix-post" style="height:' + (postEntryHeight - postEntryNextNextHeight) + 'px"></div>')
                    } else {
                        postEntry.append('<div class="fix-post" style="height:' + (postEntryNextNextHeight - postEntryHeight) + 'px"></div>')
                    }
                    if (postEntryNextHeight > postEntryNextNextHeight) {
                        postEntryNextNext.append('<div class="fix-post" style="height:' + (postEntryNextHeight - postEntryNextNextHeight) + 'px"></div>')
                    } else {
                        postEntryNext.append('<div class="fix-post" style="height:' + (postEntryNextNextHeight - postEntryNextHeight) + 'px"></div>')
                    }
                }
            });
        } else {
            $('.pi-grid.no-sidebar .pi-grid-item:nth-child(odd)').each(function() {
                var $this = $(this),
                    postTitle = $this.find('.post-title'),
                    postTitleNext = $this.next().find('.post-title'),
                    postTitlePrev = $this.prev().find('.post-title'),
                    postTitleHeight = postTitle.innerHeight(),
                    postTitleNextHeight = postTitleNext.innerHeight(),
                    postTitlePrevHeight = postTitlePrev.innerHeight(),
                    postEntry = $this.find('.post-entry'),
                    postEntryNext = $this.next().find('.post-entry'),
                    postEntryPrev = $this.prev().find('.post-entry'),
                    postEntryHeight = postEntry.innerHeight(),
                    postEntryNextHeight = postEntryNext.innerHeight(),
                    postEntryPrevHeight = postEntryPrev.innerHeight();

                if ($('.pi-grid').hasClass('pi-grid-first-large') == true || $('.pi-list').hasClass('pi-list-first-large') == true) {
                    if (postTitleHeight > postTitlePrevHeight) {
                        postTitlePrev.append('<div class="fix-post" style="height:' + (postTitleHeight - postTitlePrevHeight) + 'px"></div>')
                    } else {
                        postTitle.append('<div class="fix-post" style="height:' + (postTitlePrevHeight - postTitleHeight) + 'px"></div>')
                    }
                    if (postEntryHeight > postEntryPrevHeight) {
                        postEntryPrev.append('<div class="fix-post" style="height:' + (postEntryHeight - postEntryPrevHeight) + 'px"></div>')
                    } else {
                        postEntry.append('<div class="fix-post" style="height:' + (postEntryPrevHeight - postEntryHeight) + 'px"></div>')
                    } 
                } else {
                    if (postTitleHeight > postTitleNextHeight) {
                        postTitleNext.append('<div class="fix-post" style="height:' + (postTitleHeight - postTitleNextHeight) + 'px"></div>')
                    } else {
                        postTitle.append('<div class="fix-post" style="height:' + (postTitleNextHeight - postTitleHeight) + 'px"></div>')
                    }
                    if (postEntryHeight > postEntryNextHeight) {
                        postEntryNext.append('<div class="fix-post" style="height:' + (postEntryHeight - postEntryNextHeight) + 'px"></div>')
                    } else {
                        postEntry.append('<div class="fix-post" style="height:' + (postEntryNextHeight - postEntryHeight) + 'px"></div>')
                    } 
                }

            });
        }

        $('.toggle-social').hover(function() {
            var text = $(this).data('text');
            $('.wrap-item-menu-name').addClass('active');
            $('.wrap-item-menu-name .text').text(text);
        }, function() {
            $('.wrap-item-menu-name').removeClass('active');
        });

        $('.toggle-search').hover(function() {
            var text = $(this).data('text');
            $('.wrap-item-menu-name').addClass('active');
            $('.wrap-item-menu-name .text').text(text);
        }, function() {
            $('.wrap-item-menu-name').removeClass('active');
        });

        $('.pi-promo').prepend('<div class="pi-promo-bg"></div>');
        $('.pi-promo-item').hover(function() {
            var $item = $(this),
                itemImage = $('.image', $item).css('background-image');
            $('.pi-promo-bg')
                .addClass('active')
                .css('background-image', itemImage);
        }, function() {
            $('.pi-promo-bg')
                .removeClass('active');
        });

        $("#pi-mailchimp-subscribe").on('click', function(event) {
            event.preventDefault();
            var $self = $(this);
            if ( $("input.pi-subscribe-email").val() != '' )
            {
                $self.html('<i class="fa fa-cloud-upload"></i>');
                $.post(
                    PI_OB.ajaxurl,
                    {
                        action : 'pi_subscribe',
                        // send the nonce along with the request
                        subscribeNonce : $self.data('nonce'),
                        email: jQuery("input.pi-subscribe-email").val()
                    },
                    function( response ) {
                        var data = JSON.parse(response);
                        if(data.type=='error')
                        {
                            jQuery(".subscribe-status").html(data.msg).addClass("alert-error").removeClass("alert-done").fadeIn();
                            $self.html('Subscribe');
                        }
                        else{
                            jQuery(".subscribe-status").html(data.msg).addClass("alert-done").removeClass("alert-error").fadeIn();
                            jQuery("form.pi_subscribe").find(".form-remove").remove();
                        }
                    }
                );
            }else{
                jQuery(".subscribe-status").html("Please enter your e-mail").addClass("alert-error").removeClass("alert-done").fadeIn();
            }
        })

        
        if(!$('.about-author .author-content').length){
            $('.about-author').remove();
        }

        if ( !$('.related-post .pi-row').children().length ) {
            $('.related-post').remove();
        }
    });

    piLazyLoad();

})(jQuery);