<?php
/**
 * Upload favicon for your website
 * @since 1.0
 */

$wp_customize->add_section(
    'pi_favicon',
    array(
        'title'     => esc_html__('Favicon', 'sunrise'),
        'panel'     => 'sunrise_basic_settings_panel',
        'priority'  => $this->piSectionPriority++
    )
);

$wp_customize->add_setting(
    'pi_options[basic_settings][favicon]',
    array(
        'type'              => 'option',
        'default'           => '',
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => array($this, 'sunrise_sanitize_data')
    )
);

$wp_customize->add_control(
    new WP_Customize_Image_Control(
        $wp_customize,
        'pi_options[basic_settings][favicon]',
        array(
            'label'     => esc_html__('Upload favicon', 'sunrise'),
            'section'   => 'pi_favicon',
            'settings'  => 'pi_options[basic_settings][favicon]',
            'priority'  => $this->piControlPriority++
        )
    )
);
