<?php
/**
 * Custom Js
 * @since 1.0
 */
$wp_customize->add_section('pi_footer_custom_js', array(
    'title'         => esc_html__('Custom js', 'sunrise'),
    'panel'         => 'pi_footer_panel',
    'priority'      =>  $this->piSectionPriority++,
    'description'   => esc_html__('Note: Enter your javascript code without &lt;script> tag', 'sunrise')
));

$wp_customize->add_setting(
    "pi_options[footer][custom_js]",
    array(
        'default'       =>  esc_textarea(parent::$piOptions['footer']['custom_js']),
        'type'          => 'option',
        'capability'    => 'edit_theme_options',
        'sanitize_callback' => array($this, 'sunrise_sanitize_data')
    )
);

$wp_customize->add_control( new piTextarea(
    $wp_customize,
    'pi_options[footer][custom_js]',
    array(
        'label'      => esc_html__( 'Custom js', 'sunrise'),
        'priority'   => $this->piControlPriority++,
        'section'    => 'pi_footer_custom_js',
        'settings'   => 'pi_options[footer][custom_js]'
    )
));

?>