<?php
/**
 * Render preloader
 * @since 1.0
 */

function sunrise_render_preloader()
{
    $status  = SunriseBlogCustomize::sunrise_refresh_in_customize("pi_options[basic_settings][preloader]")  ? SunriseBlogCustomize::sunrise_refresh_in_customize("pi_options[basic_settings][preloader]") : SunriseBlogFramework::$piOptions['basic_settings']['preloader'];

    $status  = $status == "disable" || $status == '0' ? 0 : $status;

    if ( !empty($status) ) :
        /*It allows to create other preloader*/
        ?>
        <div class="preloader">
            <span><?php esc_html_e('Loading', 'sunrise'); ?></span>
        </div>
<?php
    endif;
}
