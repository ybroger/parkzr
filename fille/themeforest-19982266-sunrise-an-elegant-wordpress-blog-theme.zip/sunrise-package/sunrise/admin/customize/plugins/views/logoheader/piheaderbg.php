<?php
/**
 * Created by Next-theme
 * @since 1.0
 */
function sunrise_get_headerbg()
{
    return SunriseBlogCustomize::sunrise_refresh_in_customize('pi_options[logoheader][headerbg]') ? SunriseBlogCustomize::sunrise_refresh_in_customize('pi_options[logoheader][headerbg]') : SunriseBlogFramework::$piOptions['logoheader']['headerbg'];
}
