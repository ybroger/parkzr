<!doctype html>
<html <?php language_attributes(); ?> class="no-js">
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="format-detection" content="telephone=no">
    <link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
    <?php 
    if ( !function_exists('wp_site_icon') && !has_site_icon() )
    {
        sunrise_render_favicon(); 
    }

    if ( is_single() )
    {
        global $post;

        if ( has_post_thumbnail($post->ID) ) :
        ?>
        <meta property="og:image" content="<?php echo esc_url(wp_get_attachment_url(get_post_thumbnail_id($post->ID))); ?>"/>
        <?php
        endif;
        ?>
        <meta property="og:site_name" content="<?php echo esc_attr(get_option('blogname')); ?>"/>
        <meta property="og:type" content="blog"/>
        <meta property="og:title" content="<?php echo esc_attr(get_the_title($post->ID)); ?>"/>
        <meta property="og:description" content="<?php echo esc_attr(sunrise_cut_string($post->post_content, 100)); ?>"/>
        <?php
    }

    ?>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <meta name="description" content="<?php bloginfo('description'); ?>">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
    <div id="wrapper">
        <?php
        /* Preloader */
        sunrise_render_preloader();
        ?>
        <!-- Header -->
        <?php
            $headerBg = sunrise_get_headerbg();
            $classAdditional = !empty($headerBg) ?  'background-image' : 'no-background';
        ?>
        <header id="pi-header" class="<?php echo esc_attr($classAdditional); ?>" data-background-image="<?php echo esc_attr($headerBg); ?>">
            <div class="header-top">
                <div class="pi-header-fixed">
                    <?php
                    if( has_nav_menu('pi_menu') )
                    {
                        ?>
                        <!-- Toggle menu -->
                        <div class="toggle-menu">
                            <span class="item item-1"></span>
                            <span class="item item-2"></span>
                            <span class="item item-3"></span>
                        </div>
                        <!-- / Toggle menu -->
                        <?php
                        wp_nav_menu(
                            array(
                                'menu'              => 'pi_menu',
                                'container'         => 'nav',
                                'container_class'   => 'pi-navigation',
                                'container_id'      => '',
                                'menu_class'        => 'pi-menulist',
                                'menu_id'           => 'pi_menu',
                                'items_wrap'        => '<ul id="%1$s" class="%2$s">%3$s</ul>',
                            )
                        );
                    }
                    ?>

                    
                    <div class="header-right">
                        <?php if ( pi_render_toggle_follow()  ) : ?>
                        <div class="toggle-social item" data-text="<?php echo esc_html(sunrise_render_follow_me_description()); ?>">
                            <i class="fa fa-share-alt"></i>
                        </div>
                        <?php endif; ?>
                        <div class="toggle-search item" data-text="<?php echo esc_html(pi_render_search_description()); ?>">
                            <i class="fa fa-search"></i>
                        </div>
                    </div>
                    
                </div>

                <div class="wrap-item-menu-name">
                    <div class="tb">
                        <div class="tb-cell">
                            <div class="text"></div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Logo -->
            <?php sunrise_render_logo(); ?>
            <!-- / Logo -->
        </header>
        <!-- / Header -->

        <?php
            /*Render Follow*/
            if ( pi_render_toggle_follow() )
            {
                sunrise_render_follow(true);
            }

            /*Render Search*/
            pi_render_search();

            /* Featured Slider */
            if ( is_home() || is_page_template('page-template.php') )
            {
                sunrise_render_featured_slider();

                $html = sunrise_promo_first_block() . sunrise_promo_second_block() . sunrise_promo_third_block();

                if ( !empty($html) )
                {
                    echo '<div class="pi-promo"><div class="pi-container"><div class="pi-row"><div class="tb">';
                    echo sunrise_promo_first_block() . sunrise_promo_second_block() . sunrise_promo_third_block();
                    echo '</div></div></div></div>';
                }
            }
        ?>
