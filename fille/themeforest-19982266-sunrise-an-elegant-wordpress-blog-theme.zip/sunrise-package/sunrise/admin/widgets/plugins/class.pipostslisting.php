<?php
/**
 * Created by Next-theme
 */
class piPostsListing extends WP_Widget
{
    public $aDef = array('title'=>'', 'number_of_posts'=>4, 'display'=>'latest_posts');
    public function __construct()
    {
        parent::__construct('pi_postslisting', SUNRISE_THEMENAME . 'Posts Listing', array('classname'=>'postslisting'));
    }

    public function form($aInstance)
    {
        $aInstance = wp_parse_args($aInstance, $this->aDef);
        piWidgets::pi_text_field( 'Title', $this->get_field_id('title'), $this->get_field_name('title'), $aInstance['title']);
        piWidgets::pi_text_field( 'Number of posts', $this->get_field_id('number_of_posts'), $this->get_field_name('number_of_posts'), $aInstance['number_of_posts']);
        piWidgets::pi_select_field( 'Display', $this->get_field_id('display'), $this->get_field_name('display'), array('latest_posts'=>'Latest posts', 'popular_posts'=>'Popular Posts'), $aInstance['display']);
    }

    public function update($aNewinstance, $aOldinstance)
    {
        $aInstance = $aOldinstance;
        foreach ( $aNewinstance as $key => $val )
        {
            if ( $key == 'number_of_posts' )
            {
                $aInstance[$key] = (int)$val;
            }else{
                $aInstance[$key] = strip_tags($val);
            }
        }
        return $aInstance;
    }

    public function widget($atts, $aInstance)
    {
        $aInstance = wp_parse_args($aInstance, $this->aDef);
        $args = array('post_type'=>'post', 'post_status'=>'publish', 'posts_per_page'=>$aInstance['number_of_posts'], 'ignore_sticky_posts'=>1);

        if ( $aInstance['display'] == 'popular_posts' )
        {
            $args['meta_key']   = 'pi_post_views_count';
            $args['orderby']    = 'meta_value_num';
            $args['order']      = 'DESC';
        }

        $query = new WP_Query($args);

        sunrise_wp_kses($atts['before_widget']);

        if ( !empty($aInstance['title']) )
        {
            echo sunrise_wp_kses($atts['before_title'], false) . esc_html($aInstance['title']) . sunrise_wp_kses($atts['after_title'], false);
        }

        echo '<div class="widget-list">';
            if ( $query->have_posts() ) :
                $i = 0;
                while ( $query->have_posts() ) : $query->the_post();
                    $size = $i == 0 ? 'sunrise-postlisting' : 'medium';
                    $i++;
                    $link = get_permalink($query->post->ID);
                    ?>
                    <div class="item">
                        <div class="item-image">
                            <div class="image-cover">
                                <?php if ( has_post_thumbnail($query->post->ID) ) : ?>
                                <a href="<?php echo esc_url($link); ?>">
                                    <?php echo get_the_post_thumbnail($query->post->ID, $size); ?>
                                </a>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="item-content">
                            <h3 class="item-title" data-number-line="2">
                                <a href="<?php echo esc_url($link); ?>"><?php echo get_the_title($query->post->ID); ?></a>
                            </h3>
                            <span class="item-meta"><?php echo sunrise_get_the_date($query->post->ID); ?></span>
                        </div>
                    </div>
                    <?php
                endwhile;
            else :
                echo '<p>'.esc_html__('There are no posts yet', 'sunrise').'</p>';
            endif;wp_reset_postdata();
        echo '</div>';

        sunrise_wp_kses($atts['after_widget']);
    }
}