;(function($){
	'use strict'

	$(document).ready(function(){
		$('[data-customize-setting-link="pi_options[featuredposts][toggle]"]').change(function(){
			var current = $(this).find('option:selected').attr('value');

			if ( current == 2 ) {
				$('#customize-control-pi_options-featuredposts-shortcode').fadeIn();
				$('#customize-control-pi_options-featuredposts-layout, #customize-control-pi_options-featuredposts-type, #customize-control-pi_options-featuredposts-category, #customize-control-pi_options-featuredposts-number_of_posts, #customize-control-pi_options-featuredposts-exclude_featured_posts, #customize-control-pi_options-featuredposts-des_exclude_posts').fadeOut();
			}else{
				$('#customize-control-pi_options-featuredposts-shortcode').fadeOut();
				$('#customize-control-pi_options-featuredposts-layout, #customize-control-pi_options-featuredposts-type, #customize-control-pi_options-featuredposts-category, #customize-control-pi_options-featuredposts-number_of_posts, #customize-control-pi_options-featuredposts-exclude_featured_posts, #customize-control-pi_options-featuredposts-des_exclude_posts').fadeIn();
			}
		}).trigger('change');
	});

})(jQuery)