;(function($){
	"use strict";

	$(window).load(function(){
		$('.preloader').fadeOut(1200);
	})
})(jQuery)