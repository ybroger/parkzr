<?php

define('SUNRISE_THEMENAME', 'Sunrise ');
define('SUNRISE_PATH', get_template_directory() . '/');
define('SUNRISE_URI', get_template_directory_uri() . '/');
define('SUNRISE_A_PATH', get_template_directory() . '/admin/');
define('SUNRISE_A_URI', get_template_directory_uri() . '/admin/');
define('SUNRISE_LIB_PATH', SUNRISE_A_PATH . 'lib/');
define('SUNRISE_FE_CSS_URI', get_template_directory_uri() . '/css/');
define('SUNRISE_FE_JS_URI', get_template_directory_uri() . '/js/');

require_once SUNRISE_A_PATH . "class.piConfigs.php";
require_once SUNRISE_A_PATH . "class.piblogframework.php";
require_once SUNRISE_A_PATH . "customize/func.views.php";
require_once SUNRISE_A_PATH . "help/func.help.php";
require_once SUNRISE_A_PATH . "post/func.post.php";
require_once SUNRISE_A_PATH . "page/func.page.php";
require_once SUNRISE_A_PATH . "user/piuser.php";
require_once SUNRISE_A_PATH . "widgets/class.piwidgets.php";
require_once SUNRISE_A_PATH . "plugins/plugin-activation.php";

/*Header Scripts*/
add_action('wp_head', 'sunrise_add_header_code');
function sunrise_add_header_code()
{
    sunrise_render_header_custom_code();
}

/*Footer Scripts*/
add_action('wp_footer', 'sunrise_add_footer_code');
function sunrise_add_footer_code()
{
    sunrise_render_footer_custom_code();
}

/*Add theme support*/

function sunrise_setup()
{
    add_theme_support('html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption',));
    add_theme_support('title-tag' );
    add_theme_support('menus');
    add_theme_support('widgets');
    add_theme_support('post-thumbnails');
    add_theme_support('post-formats', piConfigs::$aConfigs['configs']['post_formats']);
    add_theme_support('automatic-feed-links');

    add_image_size('sunrise-postlisting', 425, 255, true);
    add_image_size('sunrise-listlayout', 320, 256, true);

    load_theme_textdomain('sunrise', get_template_directory() . '/languages');

    if (!isset($content_width))
    {
        $content_width = 1200;
    }

}
add_action('after_setup_theme', 'sunrise_setup');

/*Sanatize data before update*/
function sunrise_sanitize_data_before_update($data)
{
    $data =  ( is_array($data) ) ? array_map('sunrise_sanitize_data_before_update', $data) : sanitize_text_field($data);
    return $data;
}

/**
 * the useful functions of wiloke
 */

/*Get date*/
function sunrise_get_the_date($postID, $format='')
{
    $format     = $format ? $format : get_option('date_format');
    $date       = get_the_date($format, $postID);
    return $date;
}

/*Post views*/
function sunrise_set_post_views($postID)
{
    $count_key = 'pi_post_views_count';
    $count = get_post_meta($postID, $count_key, true);
    if( !$count )
    {
        delete_post_meta($postID, $count_key);
        add_post_meta($postID, $count_key, 1);
    }else{
        $count = (int)$count + 1;
        update_post_meta($postID, $count_key, $count);
    }
}

function sunrise_get_post_views($postID)
{
    $count_key = 'pi_post_views_count';
    return get_post_meta($postID, $count_key, true);
}

/*Get the post format*/
function sunrise_get_the_post_format($postID, $postFormat=null)
{
    if ( !empty($postFormat) || has_post_format(piConfigs::$aConfigs['configs']['post_formats'], $postID) )
    {
        $postFormat = !empty($postFormat) ? $postFormat : get_post_format($postID);
        $icon = '';
        switch ($postFormat)
        {
            case 'image':
                $icon = 'fa fa-image';
                break;

            case 'gallery':
                $icon = 'fa fa-picture-o';
                break;

            case 'video';
                $icon = 'fa fa-youtube-play';
                break;

            case 'audio':
                $icon = 'fa fa-music';
                break;

            case 'quote':
                $icon = 'fa fa-quote-right';
                break;

            case 'link':
                $icon = 'fa fa-link';
                break;
            default:
                $icon = '';
                break;
        }

        return $icon;
    }
}

/*Get author page*/
function pi_get_author_page()
{
    return get_author_posts_url( get_the_author_meta('ID') );
}

/*Check email*/
function sunrise_is_valid_email($email)
{
    $isValid = true;
    $atIndex = strrpos($email, "@");
    if (is_bool($atIndex) && !$atIndex)
    {
        $isValid = false;
    }
    else
    {
        $domain = substr($email, $atIndex+1);
        $local = substr($email, 0, $atIndex);
        $localLen = strlen($local);
        $domainLen = strlen($domain);
        if ($localLen < 1 || $localLen > 64)
        {
            // local part length exceeded
            $isValid = false;
        }
        else if ($domainLen < 1 || $domainLen > 255)
        {
            // domain part length exceeded
            $isValid = false;
        }
        else if ($local[0] == '.' || $local[$localLen-1] == '.')
        {
            // local part starts or ends with '.'
            $isValid = false;
        }
        else if (preg_match('/\\.\\./', $local))
        {
            // local part has two consecutive dots
            $isValid = false;
        }
        else if (!preg_match('/^[A-Za-z0-9\\-\\.]+$/', $domain))
        {
            // character not valid in domain part
            $isValid = false;
        }
        else if (preg_match('/\\.\\./', $domain))
        {
            // domain part has two consecutive dots
            $isValid = false;
        }
        else if(!preg_match('/^(\\\\.|[A-Za-z0-9!#%&`_=\\/$\'*+?^{}|~.-])+$/',
            str_replace("\\\\","",$local)))
        {
            // character not valid in local part unless
            // local part is quoted
            if (!preg_match('/^"(\\\\"|[^"])+"$/',
                str_replace("\\\\","",$local)))
            {
                $isValid = false;
            }
        }
        if ($isValid && !(checkdnsrr($domain,"MX") || checkdnsrr($domain,"A")))
        {
            // domain not found in DNS
            $isValid = false;
        }
    }
    return $isValid;
}

/*Parse Video*/
function sunrise_parse_video($link)
{
    $getId  = "";
    $type   = "";
    if ( preg_match("#youtube#", $link) )
    {
        $parse = strpos($link, '=');
        $getId = substr($link, $parse);
        $getId = str_replace("=", "", $getId);
        $type  = "youtube";
    }elseif (preg_match("#vimeo#", $link)) {
        $getId = preg_replace("/https?:\/\/vimeo.com\//", "", $link);
        $type  = "vimeo";
    }

    return array('type'=>$type, 'id'=>$getId);
}

/*Is Page Template*/
function sunrise_is_page_template()
{
    if ( has_action('customize_controls_init') )
    {
        $pageTemplate = SunriseBlogFramework::sunrise_get_page_template_slug();
        if ( isset($pageTemplate['template']) && $pageTemplate['template'] == 'page-template.php' )
        {
            return true;
        }
    }else{
        if ( is_page_template('page-template.php') )
        {
            return true;
        }
    }

    return false;
}

/**
 * Post Meta
 */
function sunrise_post_meta($postFormat, $link, $postID, $postDate=false)
{
    if ( $postFormat && $postFormat != 'standard' ) :
    ?>
    <div class="post-format item">
        <a href="<?php echo esc_url($link); ?>"><i class="<?php echo esc_attr( sunrise_get_the_post_format($postID, $postFormat) ); ?>"></i></a>
    </div>
    <?php endif; ?>
    <div class="post-author item">
        <span><?php esc_html_e('By ', 'sunrise');?><a href="<?php echo esc_url(pi_get_author_page($postID)); ?>"><?php echo esc_html(ucfirst(get_the_author())); ?></a></span>
    </div>
    <?php if ( $postDate ) : ?>
    <div class="post-date item">
        <span><?php echo sunrise_get_the_date($postID); ?></span>
    </div>
    <?php endif; ?>
    <div class="post-comment item">
        <a href="<?php echo esc_url($link); ?>"><?php echo sunrise_get_comments_number($postID); ?></a>
    </div>
    <?php
}

/*is static front page*/
function sunrise_is_static_front_page($postID)
{
    if ( get_option('show_on_front') == 'page' )
    {
        if ( get_option('page_on_front') == $postID )
        {
            return true;
        }
    }

    return false;
}

/**
 * Get post link
 */
function sunrise_get_post_link($postID, $postFormat)
{
    $isGetLink = true;
    $link      = "";
    if ( $postFormat == 'link' )
    {
        $content = get_the_content($postID);
        if ( $content == '' )
        {
            $aData = get_post_meta($postID, 'pi_post', true);
            $link  = $aData['link'];
            $isGetLink = false;
        }
    }

    if ( $isGetLink )
    {
        $link = get_permalink($postID);
    }
    return $link;
}

/**
 * Render the post head option
 * @param $postID : the id of post
 * $getFormat: the post format, which you want to get it.
 */
function sunrise_render_post_head_options($postID,  $getFormat='', $title='', $link='', $layout='')
{
    global $piCurrentLayout;

    if ( empty($getFormat) || $piCurrentLayout == 'special'  )
    {
        if ( !has_action('pi_show_featured_image') && empty($piCurrentLayout) )
        {
            $getFormat = get_post_format($postID);
        }

        if ( empty($getFormat) ) {
            $getFormat = 'image';
            $aFormatData['get_image_by'] = 'featured_image';
        }
    }

    $aFormatData = get_post_meta($postID, 'pi_post', true);
    $link        = $link ? $link : get_permalink($postID);
    $title       = $title ? $title : get_the_title($postID);
    $render      = '';
    $blankGif    = SUNRISE_URI . 'images/blank.gif';

    switch ( $getFormat )
    {
        case 'gallery':
            if ( isset($aFormatData['slideshow']) && !empty($aFormatData['slideshow']) )
            {
                if ( isset($aFormatData['display_as']) && $aFormatData['display_as'] == 'tiled_gallery' )
                {
                    $class = 'tiled-gallery lazy';
                    $size  = 'large';
                }else{
                    $class = 'images-slider owl-carousel owl-theme';
                    $size  = 'large';
                }

                $render .= '<div class="'.esc_attr($class).'">';
                $aSlideData = explode(",", $aFormatData['slideshow']);
                foreach ( $aSlideData as $id )
                {
                    $aImg    = wp_get_attachment_image_src($id, $size);

                    $render .= '<a class="item" href="'.esc_url($aImg[0]).'">';
                    $render .= '<img src="'.esc_url($aImg[0]).'" width="'.esc_attr($aImg[1]).'" height="'.esc_attr($aImg[2]).'" alt="'.esc_attr($title).'">';

                    $render .= '</a>';
                }
                $render .= '</div>';
            }
            break;
        case 'image':
                $img = "";
                if( isset($aFormatData['get_image_by']) && $aFormatData['get_image_by'] != 'featured_image' )
                {
                    if ( !empty($aFormatData['static']) )
                    {
                        $img = '<img class="lazy" src="'.esc_url($blankGif).'" data-original="'.esc_url($aFormatData['static']).'" alt="'.esc_attr(get_the_title($postID)).'">';
                    }
                }else{
                    if ( has_post_thumbnail($postID) )
                    {
                        $img = get_the_post_thumbnail($postID, 'large');
                    }
                }
                if ( !empty($img) )
                {
                    $render .= '<div class="images">';
                    $render .= apply_filters('sunrise_filter_wrapper_image_in_the_post_media', $img, $link, $postID);
                    $render .= '</div>';
                }

            break;
        case 'video':
            if ( isset($aFormatData['video']) && !empty($aFormatData['video']) )
            {
                $render .= '<div class="embed-responsive embed-responsive-16by9">';
                if ( !preg_match('/^<(iframe|object)/', $aFormatData['video']) )
                {
                    $parseVideo = sunrise_parse_video($aFormatData['video']);
                    $protocal = is_ssl() ? 'https://' : 'http://';
                    
                    if ($parseVideo['type'] == "youtube")
                    {
                        $url     = $protocal.'www.youtube.com/embed/'.$parseVideo['id'];
                        $render .= '<iframe class="embed-responsive-item" src="'.esc_url($url).'"></iframe>';
                    }else{
                        $url     = $protocal.'player.vimeo.com/video/'.$parseVideo['id'].'?title=0&amp;byline=0&amp;portrait=0';
                        $render .= '<iframe class="embed-responsive-item" src="'.esc_url($url).'"></iframe>';
                    }
                }else{
                    $render     .= $aFormatData['video'];
                }
                $render .= '</div>';
            }
            break;
        case 'quote':
            if ( isset($aFormatData['quote']) && !empty($aFormatData['quote']) )
            {
                $render .=  '<div class="post-quote">';
                    $render .=  '<blockquote>';
                        $render .=  '<span class="quote-icon">&rdquo;</span>';
                        if ( isset($aFormatData['quote']) && !empty($aFormatData['quote']) )
                        {
                            $render .= sprintf("<p>%s</p>", wp_unslash($aFormatData['quote']));
                        }
                        if ( isset($aFormatData['quote_author']) && !empty($aFormatData['quote_author']) )
                        {
                            $render .= sprintf("<footer>%s</footer>", wp_unslash($aFormatData['quote_author']));
                        }
                    $render .=  '</blockquote>';
                    if ( current_user_can('edit_theme_options', $postID) )
                    {
                        $render .= '<a href="'.get_edit_post_link($postID).'" class="post-edit-link">'.esc_html__('Edit This', 'sunrise').'</a>';
                    }
                $render .=  '</div>';
            }
            break;
        case 'audio':
            if ( isset($aFormatData['audio']) && !empty($aFormatData['audio']) )
            {

                if ( $aFormatData['audio_bg_by'] != 'disable' )
                {
                    $bg = '';
                    if ( $aFormatData['audio_bg_by'] == 'featured_image' )
                    {
                        if ( has_post_thumbnail($postID) )
                        {
                            $bg = get_the_post_thumbnail($postID, 'large');
                        }
                    }else{
                        $bg = isset($aFormatData['audio_bg']) && !empty($aFormatData['audio_bg']) ? '<img src="'.esc_url($aFormatData['audio_bg']).'" alt="'.esc_attr($title).'">' : '';
                    }

                    if ( !empty($bg) )
                    {
                        $render .= '<div class="images">';
                            if ( is_single() )
                            {
                                $render .= $bg;
                            }else{
                                $render .= '<a href="'.esc_url($link).'">'.$bg.'</a>';
                            }

                        $render .= '</div>';
                    }
                }
                $render .= '<div class="post-audio">';
                    if ( preg_match('/(iframe|object|embed)/', $aFormatData['audio']) )
                    {
                        $render .= wp_kses($aFormatData['audio'], array('iframe'=>array('src'=>array()), 'object'=>array('src'=>array()), 'embed'=>array('src'=>array())));
                    }else{
                        $render .= do_shortcode('[audio src="'.esc_url($aFormatData['audio']).'"]');
                    }
                $render .= '</div>';
            }
            break;
        case 'link':
            if ( isset($aFormatData['link']) && !empty($aFormatData['link']) )
            {
                $content = get_the_content($postID);

                if ( $content == '' || is_single($postID) )
                {
                    $link   = $aFormatData['link'];
                    $target = 'target="_blank"';
                }else{
                    $target = '';
                }

                $render .= '<div class="post-link"><div class="tb"><div class="tb-cell"><i class="fa fa-link"></i>';
                    $render .= '<h2><a '.$target.' href="'.esc_url($link).'">'.$title.'</a></h2>';
                    $render .= '<a '.$target.' href="'.esc_url($link).'">'.$aFormatData['link'].'</a>';
                $render .= '</div></div></div>';

                if ( $aFormatData['link_bg_by'] !='disable'  )
                {
                    $render .= '<div class="images">';
                    if ( $aFormatData['link_bg_by'] == 'featured_image' )
                    {
                        if ( has_post_thumbnail($postID) )
                        {
                            $render .= get_the_post_thumbnail($postID, 'large');
                        }
                    }else{
                        $render .= '<img src="'.esc_url($aFormatData['linkbg']).'" alt="'.esc_attr($title).'">';
                    }

                    $render .= '</div>';
                }
                if ( current_user_can('edit_theme_options', $postID) )
                {
                    $render .= '<a href="'.get_edit_post_link($postID).'" class="post-edit-link">'.esc_html__('Edit This', 'sunrise').'</a>';
                }
            }
            break;
    }

    if ( !empty($render) )
    {
        $render = '<div class="post-media">'.$render.'</div>';
    }

    return $render;
}

function sunrise_studio_fonts_url($customFont='Questrial:400|Poppins:400,700|Shadows Into Light') {
    $font_url = '';
    
    if ( strpos($customFont, 'http') !== false ) {
        $customFont = preg_replace_callback('/http(?<=http)(.*)family=/', function(){
            return '';
        }, $customFont);
        $customFont = preg_replace_callback('/\+/', function(){
            return ' ';
        }, $customFont);
    }

    /*
    Translators: If there are characters in your language that are not supported
    by chosen font(s), translate this to 'off'. Do not translate into your own language.
     */
    if ( 'off' !== _x( 'on', 'Google font: on or off', 'sunrise') ) {
        $font_url = add_query_arg( 'family', urlencode($customFont), "//fonts.googleapis.com/css" );
    }
    return $font_url;
}


/*Front-end scripts*/
add_action('wp_enqueue_scripts', 'sunrise_front_end_scripts');
function sunrise_front_end_scripts()
{
    $min = defined('SCRIPT_DEBUG') && SCRIPT_DEBUG ? '.' : '.min.';
    /*Css*/
    wp_enqueue_style('fontawesome', SUNRISE_FE_CSS_URI . 'lib/font-awesome.min.css');
    wp_enqueue_style('googlefont', sunrise_studio_fonts_url());
    wp_enqueue_style('justifiedGallery', SUNRISE_FE_CSS_URI . 'lib/justifiedGallery.min.css');
    wp_enqueue_style('magnific', SUNRISE_FE_CSS_URI . 'lib/magnific-popup.css');
    wp_enqueue_style('owlcarousel2', SUNRISE_FE_CSS_URI . 'lib/owl.carousel.css');
    wp_enqueue_style('owltheme2', SUNRISE_FE_CSS_URI . 'lib/owl.theme.default.min.css');
    wp_enqueue_style('pi-sp-main', SUNRISE_FE_CSS_URI . 'style'.$min.'css');
    wp_enqueue_style('pi-sp-stylesheet', get_stylesheet_uri());

    $headerCss = sunrise_render_header_custom_css();
    if ( !empty($headerCss) )
    {
        wp_add_inline_style('pi-sp-stylesheet', $headerCss);
    }

    /*Js*/
    $detectscript = WP_DEBUG ? 'scripts.min.js' : 'scripts.js';
    
    if ( is_singular() ) {
        wp_enqueue_script( "comment-reply" );
    }

    wp_enqueue_script('jquerylazyload', SUNRISE_FE_JS_URI . 'lib/jquery.lazyload.min.js', array('jquery'), null, true);
    if ( !defined('PI_IFG_SO_AS') ) {
        wp_enqueue_script('justifiedgallery', SUNRISE_FE_JS_URI . 'lib/jquery.justifiedgallery.min.js', array('jquery'), null, true);
        wp_enqueue_script('magnific-popup', SUNRISE_FE_JS_URI . 'lib/jquery.magnific-popup.min.js', array('jquery'), null, true);
        wp_enqueue_script('owlcarousel2', SUNRISE_FE_JS_URI . 'lib/jquery.owl.carousel.min.js', array('jquery'), null, true);
    }
    
    wp_enqueue_script('theiastickysidebar', SUNRISE_FE_JS_URI . 'lib/theia-sticky-sidebar.min.js', array('jquery'), null, true);
    wp_enqueue_script('pi-sp-main', SUNRISE_FE_JS_URI . $detectscript, array('jquery'), null, true);
    wp_enqueue_script('pi-sp-preloader', SUNRISE_FE_JS_URI . 'preloader.js', array('jquery'), null, true);

    ob_start();
    ?>
    window.PI_OB  = {};
    PI_OB.ajaxurl = "<?php echo esc_js(admin_url('admin-ajax.php')); ?>";
    PI_OB.imageuri = "<?php echo esc_js(SUNRISE_URI.'images/'); ?>";
    <?php
    $inlineScript = ob_get_contents();
    ob_end_clean();

    wp_add_inline_script('jquery-migrate', $inlineScript);

    $footerJs = sunrise_render_footer_custom_js();
    $headerJs = sunrise_render_header_custom_js();

    if ( !empty($footerJs) )
    {
        wp_add_inline_script('pi-sp-main', $footerJs);
    }

    if ( !empty($headerJs) )
    {
        wp_add_inline_script('jquery-migrate', $headerJs);
    }
    
    $typography = sunrise_render_typography();
    if ( !empty($typography) )
    {
        wp_enqueue_style('sunrise_yourgooglefont',  sunrise_studio_fonts_url(get_option('pi_fontsrc')));
        wp_add_inline_style('pi-sp-stylesheet', $typography);
    }

    $customColor = sunrise_get_custom_color();

    if ( $customColor !='default' && !empty($customColor) && $customColor != 'custom' )
    {
        wp_enqueue_style( 'sunrise_custom_color', SUNRISE_FE_CSS_URI . 'colors/' . $customColor . '.css', array(), '1.0' );
    }elseif ( $customColor == 'custom' ){
        ob_start();
        include get_template_directory() . '/css/colors/default.css';
        $color = ob_get_clean();

        $color = str_replace('#9182da', sunrise_get_my_color(), $color);

        wp_add_inline_style('pi-sp-stylesheet', $color);
    }
}


/*get comments number*/
function sunrise_get_comments_number($postID)
{
    $num = get_comments_number($postID);

    if ( $num == 0 )
    {
        return esc_html__('No Comment', 'sunrise');
    }elseif($num == 1)
    {
        return esc_html__('01 Comment', 'sunrise');
    }elseif($num < 10){
        return 0 . $num . esc_html__(' Comments', 'sunrise');
    }else{
        return $num . esc_html__(' Comments', 'sunrise');
    }
}


/*Create a sidebar*/
add_action('widgets_init', 'sunrise_register_sidebar');
function sunrise_register_sidebar()
{
    register_sidebar(
        array(
            'name'          => esc_html__('Sidebar', 'sunrise'),
            'description'   => esc_html__('Displaying your sidebar', 'sunrise'),
            'id'            => 'pi_sidebar',
            'before_widget' => '<div id="%1$s" class="widget %2$s">',
            'after_widget'  => '</div>',
            'before_title'  => '<h4 class="widget-title">',
            'after_title'   => '</h4>'
        )
    );
    register_sidebar(
        array(
            'name'          => esc_html__('Footer1', 'sunrise'),
            'id'            => 'pi_footer1',
            'before_widget' => '<div id="%1$s" class="widget %2$s">',
            'after_widget'  => '</div>',
            'before_title'  => '<h4 class="widget-title">',
            'after_title'   => '</h4>'
        )
    );
    register_sidebar(
        array(
            'name'          => esc_html__('Footer2', 'sunrise'),
            'id'            => 'pi_footer2',
            'before_widget' => '<div id="%1$s" class="widget %2$s">',
            'after_widget'  => '</div>',
            'before_title'  => '<h4 class="widget-title">',
            'after_title'   => '</h4>'
        )
    );
    register_sidebar(
        array(
            'name'          => esc_html__('Footer3', 'sunrise'),
            'id'            => 'pi_footer3',
            'before_widget' => '<div id="%1$s" class="widget %2$s">',
            'after_widget'  => '</div>',
            'before_title'  => '<h4 class="widget-title">',
            'after_title'   => '</h4>'
        )
    );
}

/* Register menu */
add_action('init', 'sunrise_register_nav_menu');
function sunrise_register_nav_menu()
{
    register_nav_menus( array('pi_menu' => esc_html__('Sunrise Menu', 'sunrise')) );
}

function sunrise_sanitize_data($data)
{
   return $data;
}

/**
 * The list of categories
 */
function sunrise_get_list_of_categories($postID)
{
    $aCats = get_the_category($postID);
    $list  = '';

    if ( !empty($aCats) )
    {
        foreach ( $aCats as $cat )
        {
            $list .="<li><a href='".get_category_link( $cat->term_id )."'>".esc_html($cat->name)."</a></li>";
        }
    }

    if ( !empty($list) )
    {
        $list = '<ul>'.$list.'</ul>';
    }

    return $list;
}

/* Logo */
add_action('sunrise_before_logo', 'sunrise_open_logo_wrapper');
add_action('sunrise_after_logo', 'sunrise_close_logo_wrapper');

function sunrise_open_logo_wrapper()
{
    echo '<div class="header-logo text-center">';
}

function sunrise_close_logo_wrapper()
{
    echo '</div>';
}

/*Comment*/
if ( ! function_exists( 'sunrise_comment' ) )
{
    function sunrise_comment( $comment, $args, $depth )
    {
        $GLOBALS['comment'] = $comment;

        switch ( $comment->comment_type ) :
            case 'pingback' :
            case 'trackback' :
                // Display trackbacks differently than normal comments.
                ?>
                <li <?php comment_class(); ?> id="li-comment-<?php comment_ID(); ?>">
                    <p><?php esc_html_e( 'Pingback:', 'sunrise'); ?> <?php comment_author_link(); ?></p>
                <?php
                break;
            default :
                // Proceed with normal comments.
                global $post;
                ?>
                <li <?php comment_class(); ?> id="li-comment-<?php comment_ID(); ?>">
                    <div id="comment-<?php comment_ID(); ?>" class="comment-box">
                        <div class="comment-author">
                            <?php
                            $image = '';
                            $commentID    = get_comment_ID();
                            $authorInfo   = get_comment($commentID);

                            if (  isset($authorInfo->user_id) )
                            {
                                $userData = get_user_meta($authorInfo->user_id);
                                if ( isset($userData['pi_user_info'][0]) )
                                {
                                    $aAuthorData = unserialize($userData['pi_user_info'][0]);
                                    $image = isset($aAuthorData['avatar']) && !empty($aAuthorData['avatar']) ? $aAuthorData['avatar'] : '';
                                    if ( !empty($image) )
                                    {
                                        echo '<img src="'.esc_url($image).'" class="pi-comment-avatar"  alt="'. esc_attr( $userData['nickname'][0] ) .'">';
                                    }
                                }
                            }
                            if ( empty($image) )
                            {
                                echo get_avatar( $comment, 100 );
                            }
                            ?>
                        </div><!-- .comment-meta -->
                        <div class="comment-body">
                            <?php
                            printf( '<cite class="fn">%1$s</cite>',ucfirst(get_comment_author_link()));
                            ?>
                            <?php
                            printf( '<div class="comment-meta"><span>%1$s</span></div>',
                                /* translators: 1: date, 2: time */
                                sunrise_wp_kses(sprintf( __( '%1$s at %2$s', 'sunrise'), get_comment_date(), get_comment_time() ), false)
                            );
                            ?>


                            <?php if ( '0' == $comment->comment_approved ) : ?>
                                <p class="comment-awaiting-moderation"><?php esc_html_e( 'Your comment is awaiting moderation.', 'sunrise'); ?></p>
                            <?php endif; ?>

                            <?php comment_text(); ?>

                            <div class="comment-edit-reply">
                                <?php edit_comment_link( esc_html__( 'Edit', 'sunrise'), '', '' ); ?>
                                <?php comment_reply_link( array_merge( $args, array( 'reply_text' => esc_html__( 'Reply', 'sunrise'), 'after' => '', 'depth' => $depth, 'max_depth' => $args['max_depth'] ) ) ); ?>
                            </div><!-- .reply -->
                        </div>
                    </div><!-- #comment-## -->
                <?php
                break;
        endswitch; // end comment_type check
    }
}
if ( ! function_exists( 'sunrise_comment_nav' ) )
{
    /**
     * Display navigation to next/previous comments when applicable.
     *
     */
    function sunrise_comment_nav() {
        // Are there comments to navigate through?
        if ( get_comment_pages_count() > 1 && get_option( 'page_comments' ) ) :
            ?>
            <nav class="navigation comment-navigation" role="navigation">
                <h2 class="screen-reader-text"><?php esc_html_e( 'Comment navigation', 'sunrise'); ?></h2>
                <div class="nav-links">
                    <?php
                    if ( $prev_link = get_previous_comments_link( esc_html__( 'Older Comments', 'sunrise') ) ) :
                        printf( '<div class="nav-previous">%s</div>', $prev_link );
                    endif;

                    if ( $next_link = get_next_comments_link( esc_html__( 'Newer Comments', 'sunrise') ) ) :
                        printf( '<div class="nav-next">%s</div>', $next_link );
                    endif;
                    ?>
                </div><!-- .nav-links -->
            </nav><!-- .comment-navigation -->
        <?php
        endif;
    }
}

/* Follow */
add_filter('sunrise_filter_panel_of_follow', 'sunrise_change_the_panel_of_follow', 10, 1);
add_filter('sunrise_filter_follow_wrapper_class', 'sunrise_change_follow_wrapper_class', 10, 1);
add_filter('sunrise_filter_render_follow', 'sunrise_change_render_follow_structure', 10, 1);

function sunrise_change_the_panel_of_follow($panel)
{
    return 'sunrise_basic_settings_panel';
}

function sunrise_change_follow_wrapper_class($class)
{
    return 'page-social';
}

function sunrise_change_render_follow_structure($follow)
{
    $newStructure = "";
    $newStructure .= '<div class="tb"><div class="tb-cell">';
    $newStructure .= $follow;
    $newStructure .= '</div></div>';

    return $newStructure;
}

/*Filter sharingbox wrapper*/
add_filter('sunrise_filter_before_sharingbox_wrapper', 'sunrise_change_before_sharingbox_wrapper', 10, 1);
function sunrise_change_before_sharingbox_wrapper($div)
{
    return '<div class="post-social tb-cell">';
}

/*Remove readmore button*/
add_filter('sunrise_more_link', 'sunrise_remove_readmore_button', 10, 1);
function sunrise_remove_readmore_button($button)
{
    return;
}

/*Filter Next & Prev post link*/
add_filter('next_posts_link_attributes', 'sunrise_add_a_class_to_next_posts_link', 10, 1);
add_filter('previous_posts_link_attributes', 'sunrise_add_a_class_to_previous_posts_link', 10, 1);

function sunrise_add_a_class_to_next_posts_link($atts) {
    return 'class="old-post"';
}

function sunrise_add_a_class_to_previous_posts_link($atts) {
    return 'class="new-post"';
}

/*Excerpt*/
function sunrise_excerpt_more( $more ) {
    return '';
}
add_filter('excerpt_more', 'sunrise_excerpt_more', 10, 1);

/*Filter image wrapper in the post media*/
add_filter('sunrise_filter_wrapper_image_in_the_post_media', 'sunrise_wrapper_or_no', 10, 3);
function sunrise_wrapper_or_no($img, $link, $postID)
{
    if ( !is_single($postID) )
    {
        $img = '<a href="'.esc_url($link).'">'.$img.'</a>';
    }

    return $img;
}

/*Removing Some Customizers*/
add_action( 'customize_register', 'sunrise_remove_customizer' );

function sunrise_remove_customizer($wp_customize)
{
    // Remove Sections
    $wp_customize->remove_section( 'title_tagline');
    $wp_customize->remove_section( 'nav');
    $wp_customize->remove_section( 'static_front_page');
    $wp_customize->remove_section( 'colors');
    $wp_customize->remove_section( 'background_image');
}


/**
 * Hook into Customize
 */
add_action('init', 'sunrise_hook_into_customize');

function sunrise_hook_into_customize()
{
    $isCustomize = has_action('customize_controls_init') ? true : false;
    if ( isset(piConfigs::$aConfigs['configs']['hooks']) && !empty(piConfigs::$aConfigs['configs']['hooks']) )
    {
        foreach ( piConfigs::$aConfigs['configs']['hooks'] as $section => $aFolder )
        {
            foreach ( $aFolder as $folder )
            {
                if ( $isCustomize )
                {
                    include SUNRISE_PATH . 'next-theme/'.$section.'/'.$folder.'/setting.php';
                }
                include SUNRISE_PATH . 'next-theme/'.$section.'/'.$folder.'/view.php';
            }
        }
    }
}

/**
 * Enqueue script for custom customize control.
 */
function sunrise_custom_customize_enqueue()
{
    wp_enqueue_style( 'custom-customize', SUNRISE_URI . 'next-theme/source/css/customize.css');
    wp_enqueue_script( 'custom-customize', SUNRISE_URI . 'next-theme/source/js/customize.js', array('jquery'), null, true );
}
add_action( 'customize_controls_enqueue_scripts', 'sunrise_custom_customize_enqueue' );


function sunrise_cut_string($content, $length = 100)
{
    $content  = strip_tags($content);
    $content  = substr($content, 0, $length);
    $lpos     = strripos($content, ' ');
    $content  = substr($content, 0, $lpos);

    return $content;
}
   

function sunrise_add_edit_page_template_on_admin_bar()
{
    global $wp_admin_bar, $wp_the_query;
    
    $current_object = $wp_the_query->get_queried_object();

    if ( empty( $current_object ) )
    {
        return;
    }

    if ( ! empty( $current_object->post_type )
        && ( $post_type_object = get_post_type_object( $current_object->post_type ) )
        && current_user_can( 'edit_post', $current_object->ID )
        && $post_type_object->show_in_admin_bar
        && $edit_post_link = get_edit_post_link( $current_object->ID ) )
    {
        $getTemplateName = get_page_template_slug($current_object->ID);

        if ($getTemplateName == 'page-template.php') 
        {
            $pageUrl = admin_url('post.php') . '?post=' . $current_object->ID . '&amp;action=edit';
            $pageUrl = urlencode($pageUrl);
            $url = admin_url('customize.php') . '?return=' . $pageUrl;
            $wp_admin_bar->add_menu(array('id' => 'edit-sunrise-template', 'title' => esc_html__('Edit Template', 'sunrise'), 'href' => $url));
        }
    } 

}

add_action( 'admin_bar_menu', 'sunrise_add_edit_page_template_on_admin_bar', 10 );

function sunrise_wp_kses($content, $echo=true)
{
    $content = wp_kses(
        $content,
        array(
            'a' => array(
                'href'=>array(),
                'class'=>array(),
                'target'=>array(),
                'style'=>array()
            ),
            'div' => array(
                'class'=>array(),
                'style'=>array(
                    'background'=>array(),
                    'background-color'=>array(),
                    'background-image'=>array()
                )
            ),
            'strong' => array('class'=>array()),
            'br' => array('class'=>array()),
            'h1'=>array('class'=>array()),
            'h2'=>array('class'=>array()),
            'h3'=>array('class'=>array()),
            'h4'=>array('class'=>array()),
            'h5'=>array('class'=>array()),
            'h6'=>array('class'=>array()),
            'i'=>array('class'=>array()),
            'code'=>array('class'=>array()),
            'p'=>array('class'=>array()),
            'img'=>array('class'=>array(), 'src'=>array(), 'alt'=>array(), 'data-original'=>array(), 'height'=>array(), 'width'=>array()),
            'script'=>array('type'=>array()),
            'style'=>array('type'=>array()),
        )
    );

    if ( $echo )
    {
        echo $content;
    }

    return $content;
}

function sunrise_unslashed_before_update($data)
{
    $data = is_array($data) ? array_map('sunrise_unslashed_before_update', $data) : wp_unslash($data);
    return $data;
}

add_action('sunrise_render_sharing_post', 'sunrise_render_sharing_post');
function sunrise_render_sharing_post()
{
  if ( class_exists('WilokeSharingPost') ) 
  { 
    echo '<div class="post-social tb-cell">' . do_shortcode('[wiloke_sharing_post]') . '</div>'; 
  }
}

add_action('autoptimize_filter_js_defer', 'sunrise_add_cfasync_attr', 10);
function sunrise_add_cfasync_attr($defer)
{
    return " data-cfasync='true' ";
}

add_filter('autoptimize_filter_js_exclude', 'sunrise_exclude_js');
function sunrise_exclude_js($excludes){
    return $excludes.',js/preloader.js';
}

add_action('script_loader_tag', 'sunrise_add_attributes_to_scripts', 10, 3);

function sunrise_add_attributes_to_scripts($tag, $handle, $src)
{
    if ( $handle === 'pi-sp-preloader' || $handle === 'jquery-core' || $handle === 'jquery-migrate' || $handle === 'jquerylazyload' )
    {
        $tag = str_replace( array(' src', ' href'), array(" data-cfasync='false' src", " data-cfasync='false' href"), $tag );
    }else{
        $tag = str_replace( array(' src', ' href'), array(" data-cfasync='true' src", " data-cfasync='true' href"), $tag );
    }

    return $tag;
}
