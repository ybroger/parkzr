<?php
/**
 * Render Logo
 * @since 1.0
 */
function sunrise_render_logo()
{
    $logo = SunriseBlogCustomize::sunrise_refresh_in_customize('pi_options[logoheader][logo]') ? SunriseBlogCustomize::sunrise_refresh_in_customize('pi_options[logoheader][logo]') : SunriseBlogFramework::$piOptions['logoheader']['logo'];

    do_action('sunrise_before_logo');

    if ( !empty($logo) && $logo !== 'disable' )
    {
        if ( has_filter('sunrise_render_logo') )
        {
            $logo = apply_filters('sunrise_render_logo', $logo);
        }else{
            $logo = '<a class="pi-logo logo" href="'.esc_url(home_url('/')).'"><img src="'.esc_url($logo).'" alt="'.get_option('blogname').'"></a>';
        }
        sunrise_wp_kses($logo);
    }else{
        sunrise_wp_kses('<h1 class="text-center"><a class="pi-logo logo" href="'.esc_url(home_url('/')).'">'.get_option('blogname').'</a></h1>');
    }

    do_action('sunrise_after_logo');
}
