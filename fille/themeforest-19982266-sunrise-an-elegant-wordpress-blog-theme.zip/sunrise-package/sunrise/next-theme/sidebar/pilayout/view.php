<?php
function sunrise_get_sidebar_layout()
{
    return SunriseBlogCustomize::sunrise_refresh_in_customize('pi_options[sidebar_layout]') ? SunriseBlogCustomize::sunrise_refresh_in_customize('pi_options[sidebar_layout]') : SunriseBlogFramework::$piOptions['sidebar_layout'];
}

function sunrise_get_sidebar_sticky()
{
    return SunriseBlogCustomize::sunrise_refresh_in_customize('pi_options[sidebar_sticky]') ? SunriseBlogCustomize::sunrise_refresh_in_customize('pi_options[sidebar_sticky]') : SunriseBlogFramework::$piOptions['sidebar_sticky'];
}