<?php
/**
 * Render custom css
 */
function sunrise_render_header_custom_css()
{
	if ( SunriseBlogCustomize::sunrise_refresh_in_customize('pi_options[logoheader][custom_css]') ) {
		$customCss = $code;
	}else if ( isset(SunriseBlogFramework::$piOptions['logoheader']['custom_css']) ){
		$customCss = SunriseBlogFramework::$piOptions['logoheader']['custom_css'];
	}else{
		$customCss = '';
	}
    return $customCss;
}
