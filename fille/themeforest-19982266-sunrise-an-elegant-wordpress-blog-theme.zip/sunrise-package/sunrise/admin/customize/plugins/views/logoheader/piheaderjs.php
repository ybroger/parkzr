<?php
/**
 * Render custom js
 */
function sunrise_render_header_custom_js()
{
	if ( SunriseBlogCustomize::sunrise_refresh_in_customize('pi_options[logoheader][custom_js]') ) {
		$customJs = SunriseBlogCustomize::sunrise_refresh_in_customize('pi_options[logoheader][custom_js]');
	}else if ( isset(SunriseBlogFramework::$piOptions['logoheader']['custom_js']) ){
		$customJs = SunriseBlogFramework::$piOptions['logoheader']['custom_js'];
	}else{
		$customJs = '';
	}
    return $customJs;
}
