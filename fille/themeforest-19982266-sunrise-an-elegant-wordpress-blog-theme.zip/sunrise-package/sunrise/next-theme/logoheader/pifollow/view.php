<?php
function pi_render_toggle_follow($showingTitle = false)
{
    $status = SunriseBlogCustomize::sunrise_refresh_in_customize("pi_options[follow][toggle]") ? SunriseBlogCustomize::sunrise_refresh_in_customize("pi_options[follow][toggle]") : '';

    if ( empty($status) && isset(SunriseBlogFramework::$piOptions['follow']['toggle']) )
    {
        $status = SunriseBlogFramework::$piOptions['follow']['toggle'];
    }

    if ( empty($status) || $status == 'disable' )
    {
        $status = false;
    }

    return $status;
}

function sunrise_render_follow_me_description($showingTitle = false)
{
    $content = SunriseBlogCustomize::sunrise_refresh_in_customize("pi_options[follow][description]") ? SunriseBlogCustomize::sunrise_refresh_in_customize("pi_options[follow][description]") : '';
    
    if ( empty($content) && isset(SunriseBlogFramework::$piOptions['follow']['description']) )
    {
        $content = SunriseBlogFramework::$piOptions['follow']['description'];
    }

    if ( empty($content) )
    {
        $content = 'Click The Icon To Show Fanpage';
    }

    return $content;
}
