<div id="comments">
    <div class="comments-inner-wrap">
        <?php if (post_password_required()) : ?>
        <p><?php esc_html_e( 'Post is password protected. Enter the password to view any comments.', 'sunrise'); ?></p>
    </div>
</div>
<?php return; endif; ?>
<?php if (have_comments()) : ?>
    <h3 id="comments-title"><?php comments_number( esc_html__('No Comment', 'sunrise'), esc_html__('One Comment', 'sunrise'), '<span>%</span> '.esc_html__('Comments', 'sunrise')); ?></h3>
    <ul class="commentlist">
        <?php wp_list_comments('callback=sunrise_comment&max_depth=2'); // Custom callback in functions.php ?>
    </ul>
    <?php sunrise_comment_nav(); ?>
<?php endif; ?>
<?php if ( !comments_open() && ! is_page() && post_type_supports( get_post_type(), 'comments' ) ) : ?>
    <p class="pi-comment-closed"><?php esc_html_e( 'Comments are closed here.', 'sunrise'); ?></p>
    </div>
    </div>
<?php else : ?>
    <!-- LEAVER YOUR COMMENT -->
    <?php
    $commenter = wp_get_current_commenter();
    $commenter['comment_author'] = $commenter['comment_author'] == '' ? '': $commenter['comment_author'];
    $commenter['comment_author_email'] = $commenter['comment_author_email'] == '' ? '': $commenter['comment_author_email'];
    $commenter['comment_author_url'] = $commenter['comment_author_url'] == '' ? '': $commenter['comment_author_url'];

    $req = get_option( 'require_name_email' );
    $aria_req = ( $req ? " aria-required='true'" : '' );
    $sao      = ( $req ? " *" : '' );
    $comment_args = array(
        'title_reply'       => esc_html__( 'Leave a comment', 'sunrise'),
        'fields' => apply_filters( 'comment_form_default_fields', array(
            'author' => '<div class="form-item form-name"><label for="author">'.esc_html__('Your name', 'sunrise') . $sao.'</label><input type="text" id="author" name="author" tabindex="1" value="'.esc_attr($commenter['comment_author']).'" ' . $aria_req . ' /></div>',
            'email'  => '<div class="form-item form-email"><label for="email">'.esc_html__('Your email', 'sunrise').$sao.'</label><input type="text" id="email" name="email" tabindex="2" value="'.esc_attr($commenter['comment_author_email']).'" ' . $aria_req . ' /></div>',
            'url'    => '<div class="form-item form-website"><label for="url">'.esc_html__('Your webiste', 'sunrise').'</label><input type="text" id="url" name="url"  tabindex="3" value="" ' . $aria_req . ' /></div>' )),
        'comment_field' => '<div class="form-item form-textarea"><label for="comment">'.esc_html__('Comment', 'sunrise').'</label><textarea id="comment" name="comment"  tabindex="4"	class="tb-eff"></textarea></div>',
        'comment_notes_after' => '',
        'comment_notes_before' => '',
        'logged_in_as'         => '<div class="form-item form-login-logout">' . sunrise_wp_kses(sprintf( __( 'Logged in as <a href="%1$s">%2$s</a>. <a href="%3$s" title="Log out of this account">Log out?</a>', 'sunrise'), get_edit_user_link(), $user_identity, wp_logout_url( apply_filters( 'the_permalink', get_permalink( $post->ID ) ) ) ), false) . '</div>'
    );
    ?>
    </div>
    </div>
    <?php
        comment_form($comment_args, $post->ID);
    ?>

    <!-- END / LEAVER YOUR COMMENT -->
<?php endif; ?>