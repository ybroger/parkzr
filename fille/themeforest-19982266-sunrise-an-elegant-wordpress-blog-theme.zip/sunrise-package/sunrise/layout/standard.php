<?php
/**
 * Standard layout
 */
global $piCurrentLayout;
$postFormat = get_post_format($post->ID);
$link       = get_permalink();
$title      = get_the_title();


?>
<!-- Post -->
<article <?php post_class('post'); ?>>
    <!-- Post Media -->
    <?php echo sunrise_render_post_head_options($post->ID, $postFormat, $title, $link, $sidebar="large"); ?>
    <!-- / Post Media -->

    <!-- Post Body -->

    <?php if ( ($postFormat !='link' && $postFormat != 'quote') || ($piCurrentLayout != 'special') ) : ?>
    <div class="post-body <?php echo esc_attr($piCurrentLayout) ?>">
        <div class="post-cat">
           <?php echo sunrise_get_list_of_categories($post->ID); ?>
        </div>

        <div class="post-title">
            <h2><a href="<?php echo esc_url($link); ?>"><?php echo esc_html($title); ?></a></h2>
        </div>

        <div class="post-date">
            <span><?php echo sunrise_get_the_date($post->ID); ?></span>
        </div>


        <div class="post-entry">
            <?php sunrise_content_limit(); ?>
        </div>

        <div class="post-foot">
            <div class="tb">
                <div class="post-meta tb-cell">
                    <?php sunrise_post_meta($postFormat, $link, $post->ID); ?>
                </div>

                <div class="post-more tb-cell">
                    <a href="<?php echo esc_url($link); ?>"><?php esc_html_e('Read more', 'sunrise'); ?></a>
                </div>

                <?php 
                do_action('sunrise_render_sharing_post');
                ?>

            </div>
        </div>
        <?php edit_post_link(); ?>
    </div>
    <?php endif; ?>
    <!-- / Post Body -->

</article>
<!-- / Post -->
