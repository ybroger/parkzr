<?php
add_action('pi_hook_before_logo', 'pi_add_follow_section_to_logoheader_panel', 10, 3);

function pi_add_follow_section_to_logoheader_panel($wp_customize, $piSectionPriority, $piControlPriority)
{
	$wp_customize->add_section(
	    'pi_logoheader_follow',
	    array(
	        'title'     => esc_html__('Follow', 'sunrise'),
	        'panel'     => 'pi_logoheader_panel',
	        'priority'  => $piSectionPriority,
	        'description'=>esc_html__('This setting will be displayed at the topbar menu and footer', 'sunrise')
	    )
	);

	$wp_customize->add_setting(
	    "pi_options[follow][toggle]",
	    array(
	        'default'       => 'disable',
	        'type'          => 'option',
	        'capability'    => 'edit_theme_options',
	        'sanitize_callback' => 'sunrise_sanitize_data'
	    )
	);

	$wp_customize->add_control(
	    'pi_options[follow][toggle]',
	    array(
	        'label'     => esc_html__('Enable/Disable', 'sunrise'),
	        'type'      => 'select',
	        'settings'  => 'pi_options[follow][toggle]',
	        'section'   => 'pi_logoheader_follow',
	        'priority'  => $piControlPriority++,
	        'choices'   => array(
	                        'enable'  => 'Enable',
	                        'disable' => 'Disable'
	                    )
	    )
	);

	$wp_customize->add_setting(
	    "pi_options[follow][description]",
	    array(
	        'default'       =>  'Click The Icon To Show Fanpage',
	        'type'          => 'option',
	        'capability'    => 'edit_theme_options',
	        'sanitize_callback' => 'sunrise_sanitize_data'
	    )
	);

	$wp_customize->add_control('pi_options[follow][description]',
	    array(
	        'label'     => esc_html__('Description', 'sunrise'),
	        'section'   => 'pi_logoheader_follow',
	        'settings'  => 'pi_options[follow][description]',
	        'priority'  => $piControlPriority++,
	        'type'      => 'text'
	    )
	);
}