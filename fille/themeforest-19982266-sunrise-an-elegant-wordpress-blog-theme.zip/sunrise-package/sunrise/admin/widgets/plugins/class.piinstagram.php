<?php
/**
 * Instagram Feed
 * Created by Next-theme
 */

class piInstagram extends WP_Widget
{
    public $aDef = array( 'title' =>'Instagram', 'user_id'=>'', 'username'=>'', 'number_of_photos' => 9, 'access_token' => '', 'cache_interval'=>3000);
    public function __construct()
    {
        $args = array('classname'=>'widget widget_instagram', 'description'=>'');
        parent::__construct("nexttheme_instagram", SUNRISE_THEMENAME . 'Instagram Feed ', $args);
    }

    public function form($aInstance)
    {
        $aInstance            = wp_parse_args( $aInstance, $this->aDef );
        $aInstagramSettings   = get_option('_pi_instagram_settings');

        $aInstance['cache_interval'] = !empty($aInstance['cache_interval']) ? $aInstance['cache_interval'] : $aInstagramSettings['cache_interval'];
       
        if ( isset($aInstagramSettings['access_token']) && !empty($aInstagramSettings['access_token']) )
        {
            ?>
            <p>
                <label for="<?php echo esc_attr($this->get_field_id( 'title' )); ?>"><?php esc_html_e('Title', 'sunrise'); ?></label>
                <input id="<?php echo esc_attr($this->get_field_id( 'title' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'title' )); ?>" value="<?php echo esc_attr($aInstance['title']); ?>" class="widefat" type="text" />
            </p>

            <p>
                <label for="<?php echo esc_attr($this->get_field_id( 'username' )); ?>"><?php esc_html_e('Instagram user name', 'sunrise'); ?></label>
                <input id="<?php echo esc_attr($this->get_field_id( 'username' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'username' )); ?>" value="<?php echo esc_attr($aInstance['username']); ?>" class="widefat" type="text" />
            </p>
            
            <p>
               <code class="next-theme-help"><?php echo esc_html__('Leave empty username to display your instagram, which was configured in Settings->Sunrise Instagram', 'sunrise'); ?></code>
            </p>

            <p>
                <label for="<?php echo esc_attr($this->get_field_id( 'number_of_photos' )); ?>"><?php esc_html_e('Number Of Posts', 'sunrise'); ?></label>
                <input id="<?php echo esc_attr($this->get_field_id( 'number_of_photos' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'number_of_photos' )); ?>" value="<?php echo esc_attr($aInstance['number_of_photos']); ?>" class="widefat" type="text" />
            </p>
            <p>
                <label for="<?php echo esc_attr($this->get_field_id( 'cache_interval' )); ?>"><?php esc_html_e('Cache interval', 'sunrise'); ?></label>
                <input id="<?php echo esc_attr($this->get_field_id( 'cache_interval' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'cache_interval' )); ?>" value="<?php echo esc_attr($aInstance['cache_interval']); ?>" class="widefat" type="text" />
            </p>

            <p>
               <code class="next-theme-help"><?php echo esc_html__('Leave empty to clear cache', 'sunrise'); ?></code>
            </p>
            <?php
        }else{
            echo '<p>';
                echo '<code class="next-theme-help">'.esc_html__('Instagram Access Token is required. Please ', 'sunrise').'<a target="_blank" href="'.esc_url(admin_url('options-general.php?page=nexttheme-instagram')).'">'.esc_html__('click me to provide your instagram information.', 'sunrise').'</a></code>';
            echo '</p>';
        }

    }

    public function update($aNewinstance, $aOldinstance)
    {
        $aInstance = $aOldinstance;
        foreach ( $aNewinstance as $key => $val )
        {
            if ( $key == 'number_of_photos' )
            {
                $aInstance[$key] = (int)$val;
            }else{
                $aInstance[$key] = strip_tags($val);
            }
        }

        if ( !array_key_exists('cache_interval', $aNewinstance) )
        {
            $aInstance['cache_interval'] = 0;
        }

        return $aInstance;
    }

    public function widget( $atts, $aInstance )
    {
        $aInstance                  = wp_parse_args($aInstance, $this->aDef);
        $aInstagramSettings         = get_option('_pi_instagram_settings');
        $aInstance['access_token']  = isset($aInstagramSettings['access_token']) ? $aInstagramSettings['access_token'] : '';
        $cacheInstagram = null;

        sunrise_wp_kses($atts['before_widget']);

        if ( !empty($aInstance['title']) )
        {
            print $atts['before_title'] . esc_html($aInstance['title']) . $atts['after_title'];
        }

        $protocal = is_ssl() ? 'https://' : 'http://';
        
        if ( empty($aInstance['access_token']) )
        {
            if ( current_user_can('edit_theme_options') )
            {
                esc_html_e('Please config your instagram', 'sunrise');
            }
        }else{
            if ( !empty($aInstance['username']) )
            {
                $type = 'username';
                $info = $aInstance['username'];
            }else{
                $type = 'self';
                $info = $aInstagramSettings['userid'];
            }

            if ( !empty($aInstance['cache_interval']) )
            {
                $cacheInstagram = get_transient('pi_cache_instagram_'.$info);
            }


            if ( !empty($cacheInstagram) )
            {
                sunrise_wp_kses($cacheInstagram);
            }else{
                $content = $this->pi_handle_instagram_feed($info, $aInstance['access_token'], $aInstance['number_of_photos'], $type, $protocal);

                sunrise_wp_kses($content);

                if ( !empty($aInstance['cache_interval']) )
                {
                    set_transient('pi_cache_instagram_'.$info, $content, absint($aInstance['cache_interval']));
                }   
            }
        }

        sunrise_wp_kses($atts['after_widget']);
    }

    public function pi_get_instagram_userid($info, $accessToken, $args, $protocal)
    {

        $url =  $protocal . 'api.instagram.com/v1/users/search?q='.$info.'&access_token='.$accessToken;
        $oSearchProfile = wp_remote_get( esc_url_raw( $url ), $args);
        if ( !empty($oSearchProfile) && !is_wp_error($oSearchProfile) )
        {
            $oSearchProfile = wp_remote_retrieve_body($oSearchProfile);
            $oSearchProfile = json_decode($oSearchProfile);

            if ( $oSearchProfile->meta->code === 200 )
            {
               foreach ( $oSearchProfile->data as $oInfo )
               {
                    if ( $oInfo->username === $info )
                    {
                        return $oInfo->id;
                    }
               }
            }
        }

        return;
    }

    public function pi_handle_instagram_feed($info, $accessToken, $count=6, $type='self', $protocal)
    {
        $args = array( 'decompress' => false, 'timeout' => 30, 'sslverify'   => true );
        if ( $type == 'self' )
        {
            return $this->pi_get_instagram_images($info, $accessToken, $count, $args, $protocal);
        }else{
            $userID = $this->pi_get_instagram_userid($info, $accessToken, $args, $protocal);

            if ( !empty($userID) )
            {
                return $this->pi_get_instagram_images($userID, $accessToken, $count, $args, $protocal);
            }
        }
        
    }

    public function pi_get_instagram_images($info, $accessToken, $count, $args, $protocal)
    {
        $url   = $protocal . 'api.instagram.com/v1/users/'.$info.'/media/recent?access_token='.$accessToken.'&count='.$count;

        $getInstagram = wp_remote_get( esc_url_raw( $url ), $args);
            
        if ( !is_wp_error($getInstagram) )
        {
            $getInstagram = wp_remote_retrieve_body($getInstagram);
            $getInstagram = json_decode($getInstagram);

            if ( $getInstagram->meta->code === 200 )
            {
                $out = '';
                $out .= '<div id="pi-instagram-widget" class="pi-instagram-feed widget-grid">';
                    for ( $i=0; $i<$count; $i++ )
                    {
                        $caption = isset($getInstagram->data[$i]->caption->text) ? $getInstagram->data[$i]->caption->text : 'Instagram';
                        $out .= '<div class="item"><a href="'.esc_url($getInstagram->data[$i]->link).'" target="_blank"><img class="lazy" data-original="'.esc_url($getInstagram->data[$i]->images->thumbnail->url).'" alt="'.esc_attr($caption).'" width="'.esc_attr($getInstagram->data[$i]->images->thumbnail->width).'" height="'.esc_attr($getInstagram->data[$i]->images->thumbnail->height).'" src="'.esc_url(get_template_directory_uri() . '/images/blank.gif').'" /></a></div>';
                    }
                $out .= '</div>';
                return $out;
            }
        }

        return;  
    }
}