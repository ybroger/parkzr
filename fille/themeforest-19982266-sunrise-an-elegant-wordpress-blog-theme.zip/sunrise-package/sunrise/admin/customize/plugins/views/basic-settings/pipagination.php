<?php

function sunrise_render_pagination($query='')
{
    global $post;

    $piPagiStyle  = SunriseBlogCustomize::sunrise_refresh_in_customize("pi_options[basic_settings][pagination]") ? SunriseBlogCustomize::sunrise_refresh_in_customize("pi_options[basic_settings][pagination]") : SunriseBlogFramework::$piOptions['basic_settings']['pagination'];

    do_action('pi_before_render_pagination');
    switch (  $piPagiStyle )
    {
        case 'navigation':
            echo '<div class="pi-nav-page"><div class="prev">';
            previous_posts_link( esc_html__('Previous Entries', 'sunrise') );
            echo '</div><div class="next">';
            next_posts_link( esc_html__('Next Entries', 'sunrise'), '' );
            echo '</div></div>';
            break;

        default:
            if ( empty($query) )
            {
                global $wp_query;
            }else{
                $wp_query = $query;
            }
            $big = 999999999; // need an unlikely integer
            $aConfig = array(
                'prev_text'          => esc_html__('Previous', 'sunrise'),
                'next_text'          => esc_html__('Next', 'sunrise'),
                'before_page_number' => '',
                'after_page_number'  => '',

            );
            if ( has_filter('pi_filter_pagination_style_number') )
            {
                $aConfig = apply_filters("pi_filter_pagination_style_number", $aConfig);
            }
            $aRequires = array(
                'base' 		=> str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
                'format' 	=> is_front_page() && 'page' == get_option( 'show_on_front' ) ? '?page=%#%' : '?paged=%#%',
                'current' 	=> max( 1, get_query_var('paged') ),
                'total' 	=> $wp_query->max_num_pages,
                'prev_text' => '<i class="fa fa-angle-left"></i>',
                'next_text' => '<i class="fa fa-angle-right"></i>'
            );
            $aConfig = array_merge($aConfig, $aRequires);
            echo '<div class="pi-pagination">';
            echo paginate_links( $aConfig );
            echo '</div>';


            break;
    }
    do_action('pi_after_render_pagination');
}