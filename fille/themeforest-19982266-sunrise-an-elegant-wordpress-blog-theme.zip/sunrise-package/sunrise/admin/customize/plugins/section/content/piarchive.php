<?php
/**
 * Created by Next-theme.
 */

$wp_customize->add_section(
    'pi_archive_layout',
    array(
        'title'     => esc_html__('Archive Layout', 'sunrise'),
        'panel'     => 'pi_content_panel',
        'priority'  => $this->piSectionPriority++
    )
);

$wp_customize->add_setting(
    "pi_options[content][archive_layout]",
    array(
        'default'       =>  parent::$piOptions['content']['archive_layout'],
        'type'          => 'option',
        'capability'    => 'edit_theme_options',
        'sanitize_callback' => array($this, 'sunrise_sanitize_data')
    )
);

$wp_customize->add_control('pi_options[content][archive_layout]',
    array(
        'label'     => '',
        'section'   => 'pi_archive_layout',
        'settings'  => 'pi_options[content][archive_layout]',
        'priority'  => $this->piControlPriority++,
        'type'      => 'select',
        'choices'   => array(
            'standard'              => esc_html__('Standard', 'sunrise'),
            'grid' 	                => esc_html__('Grid', 'sunrise'),
            'grid_first-large' 	    => esc_html__('Grid - 1st large', 'sunrise'),
            'list'                  => esc_html__('List', 'sunrise'),
            'list_first-large'      => esc_html__('List - 1st large', 'sunrise')
        )
    )
);