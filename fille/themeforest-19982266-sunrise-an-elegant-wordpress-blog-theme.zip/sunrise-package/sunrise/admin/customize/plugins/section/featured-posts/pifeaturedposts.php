<?php
/**
 * Created by Next-theme
 */

$wp_customize->add_section('pi_featured_posts', array(
    'title'     => esc_html__('Settings', 'sunrise'),
    'panel'     => 'pi_featured_posts_panel',
    'priority'  => $this->piSectionPriority++
));


/*Toggle*/
$wp_customize->add_setting(
    "pi_options[featuredposts][toggle]",
    array(
        'default'       =>  self::$piOptions['featuredposts']['toggle'],
        'type'          => 'option',
        'capability'    => 'edit_theme_options',
        'sanitize_callback' => array($this, 'sunrise_sanitize_data')
    )
);
$wp_customize->add_control('pi_options[featuredposts][toggle]',
    array(
        'label' 	=> esc_html__('Choosing Slider Mode', 'sunrise'),
        'section' 	=> 'pi_featured_posts',
        'settings' 	=> 'pi_options[featuredposts][toggle]',
        'priority'  => $this->piControlPriority++,
        'type' 		=> 'select',
        'choices' 	=> array(
                        1 => esc_html__('Enable', 'sunrise'),
                        0 => esc_html__('Disable', 'sunrise'),
                        2 => esc_html__('Using A Shortcode', 'sunrise')
                    )
    )
);

/*Layout*/
$wp_customize->add_setting(
    "pi_options[featuredposts][layout]",
    array(
        'default'           =>  parent::$piOptions['featuredposts']['layout'],
        'type'              => 'option',
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => array($this, 'sunrise_sanitize_data')
    )
);

$wp_customize->add_control("pi_options[featuredposts][layout]",
    array(
        'label'     => esc_html__('Layout', 'sunrise'),
        'section'   => 'pi_featured_posts',
        'settings'  => 'pi_options[featuredposts][layout]',
        'priority'  => $this->piControlPriority++,
        'type'      => 'select',
        'choices'   => array(
            'pi-fullwidth'     => esc_html__('Fullwidth', 'sunrise'),
            'pi-container'     => esc_html__('Boxed', 'sunrise')
        ),
    )
);

/*Type*/
$wp_customize->add_setting(
    "pi_options[featuredposts][type]",
    array(
        'default'           =>  parent::$piOptions['featuredposts']['type'],
        'type'              => 'option',
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => array($this, 'sunrise_sanitize_data')
    )
);

$wp_customize->add_control("pi_options[featuredposts][type]",
    array(
        'label'     => esc_html__('Get By', 'sunrise'),
        'section'   => 'pi_featured_posts',
        'settings'  => 'pi_options[featuredposts][type]',
        'priority'  => $this->piControlPriority++,
        'type'      => 'select',
        'choices'   => array(
            'latest'     => esc_html__('Latest Posts', 'sunrise'),
            'sticky'     => esc_html__('Sticky Posts', 'sunrise'),
            'category'   => esc_html__('Category', 'sunrise'),
            'rand'       => esc_html__('Random', 'sunrise')
        ),
    )
);

/*category listing*/
$wp_customize->add_setting(
    "pi_options[featuredposts][category]",
    array(
        'default'           => -1,
        'type'              => 'option',
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => array($this, 'sunrise_sanitize_data')
    )
);

$wp_customize->add_control('pi_options[featuredposts][category]',
    array(
        'label'    => esc_html__('Choose Category', 'sunrise'),
        'section'  => 'pi_featured_posts',
        'settings' => 'pi_options[featuredposts][category]',
        'priority' => $this->piControlPriority++,
        'type'     => 'select',
        'choices'  => parent::sunrise_get_categories()
    )
);

/*Number of posts*/
$wp_customize->add_setting(
    "pi_options[featuredposts][number_of_posts]",
    array(
        'default'       => parent::$piOptions['featuredposts']['number_of_posts'],
        'type'          => 'option',
        'capability'    => 'edit_theme_options',
        'sanitize_callback' => array($this, 'sunrise_sanitize_data')
    )
);

$wp_customize->add_control('pi_options[featuredposts][number_of_posts]',
    array(
        'label'    => esc_html__('Number Of Posts', 'sunrise'),
        'section'  => 'pi_featured_posts',
        'settings' => 'pi_options[featuredposts][number_of_posts]',
        'priority' => $this->piControlPriority++,
        'type'     => 'text',
    )
);


/*Exclude featured slider*/
$wp_customize->add_setting(
    "pi_options[featuredposts][exclude_featured_posts]",
    array(
        'default'       => parent::$piOptions['featuredposts']['exclude_featured_posts'],
        'type'          => 'option',
        'capability'    => 'edit_theme_options',
        'sanitize_callback' => array($this, 'sunrise_sanitize_data')
    )
);
$wp_customize->add_control('pi_options[featuredposts][exclude_featured_posts]',
    array(
        'label'     => esc_html__('Exclude Featured Posts', 'sunrise'),
        'section'   => 'pi_featured_posts',
        'settings'  => 'pi_options[featuredposts][exclude_featured_posts]',
        'priority'  => $this->piControlPriority++,
        'type'      => 'select',
        'choices'   => array(
                        0 => esc_html__('Disable', 'sunrise'),
                        1 => esc_html__('Enable', 'sunrise')
                    )
    )
);

/*Description for featured slider*/
$wp_customize->add_setting(
    "pi_options[featuredposts][des_exclude_posts]",
    array(
        'default'       =>  '',
        'type'          => 'option',
        'capability'    => 'edit_theme_options',
        'sanitize_callback' => array($this, 'sunrise_sanitize_data')
    )
);

$wp_customize->add_control( new piDescription(
        $wp_customize,
        "pi_options[featuredposts][des_exclude_posts]",
        array(
            "priority"  => $this->piControlPriority++,
            "type"       => "description",
            "label"      => esc_html__( 'Toggle the featured posts on the content area', 'sunrise'),
            "section"    => "pi_featured_posts",
            "settings"   => "pi_options[featuredposts][des_exclude_posts]"
        )
    )
);

$wp_customize->add_setting(
    "pi_options[featuredposts][shortcode]",
    array(
        'default'       => '',
        'type'          => 'option',
        'capability'    => 'edit_theme_options',
        'sanitize_callback' => array($this, 'sunrise_sanitize_data')
    )
);
$wp_customize->add_control('pi_options[featuredposts][shortcode]',
    array(
        'label'     => esc_html__('Enter Your Shortcode here', 'sunrise'),
        'section'   => 'pi_featured_posts',
        'settings'  => 'pi_options[featuredposts][shortcode]',
        'priority'  => $this->piControlPriority++,
        'type'      => 'text'
    )
);