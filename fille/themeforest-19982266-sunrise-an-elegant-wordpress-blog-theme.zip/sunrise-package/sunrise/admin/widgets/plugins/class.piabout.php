<?php
/**
 * Customize about me
 * @since 1.0
 * Created by Next-theme
 */

class piAbout extends WP_Widget
{
    public $aDef = array('title'=>'About me', 'image'=>'', 'description'=>'', 'name'=>'Richars Winters');
    public function __construct()
    {
        parent::__construct('pi_about', SUNRISE_THEMENAME . 'About', array('class'=>'pi_about'));
    }

    public function form($aInstance)
    {
        $aInstance = wp_parse_args($aInstance, $this->aDef);

        piWidgets::pi_text_field('Title', $this->get_field_id('title'), $this->get_field_name('title'), $aInstance['title']);
        piWidgets::pi_upload_field('Image', $this->get_field_id('image'), $this->get_field_id('upload_button'), $this->get_field_name('image'), false, $aInstance['image']);
        piWidgets::pi_text_field('Name', $this->get_field_id('name'), $this->get_field_name('name'), $aInstance['name']);
        piWidgets::pi_textarea_field('Description', $this->get_field_id('description'), $this->get_field_name('description'), $aInstance['description'], 'Allows the html tags: &lt;strong>, &lt;i>, &lt;a>');
    }

    public function update($aNewinstance, $aOldinstance)
    {
        $aInstance = $aOldinstance;
        foreach ( $aNewinstance as $key => $val )
        {
            if ( $key == 'description' )
            {
                $aInstance[$key] = strip_tags($val, '<a><strong><i>');
            }else{
                $aInstance[$key] = strip_tags($val);
            }
        }
        return $aInstance;
    }

    public function widget($atts, $aInstance)
    {
        $aInstance = wp_parse_args($aInstance, $this->aDef);

        sunrise_wp_kses($atts['before_widget']);
            if ( !empty($aInstance['title']) )
            {
                echo sunrise_wp_kses($atts['before_title'], false) . esc_html($aInstance['title']) . sunrise_wp_kses($atts['after_title'], false);
            }
            ?>
                <div class="widget-about-content">
                    <?php if ( !empty($aInstance['image']) ) : ?>
                    <div class="images" style="background-image: url('<?php echo esc_url($aInstance['image']); ?>')" title="<?php echo esc_attr($aInstance['name']); ?>">
                    </div>
                    <?php endif; ?>
                    <h4><?php echo esc_html($aInstance['name']); ?></h4>
                    <?php if ( !empty($aInstance['description']) ) : ?>
                    <p><?php echo wp_kses( wp_unslash($aInstance['description']), array( 'a'=>array('href'=>array(), 'title'=>array()), 'strong'=>array(''), 'i'=>array() ) ); ?></p>
                    <?php endif; ?>
                </div>
            <?php
        sunrise_wp_kses($atts['after_widget']);
    }
}
