<?php
/**
 * Created by Next-theme
 * @since 1.0
 */
function pi_get_content_layout()
{
    $layout = SunriseBlogCustomize::sunrise_refresh_in_customize('pi_options[content][layout]') ? SunriseBlogCustomize::sunrise_refresh_in_customize('pi_options[content][layout]') : SunriseBlogFramework::$piOptions['content']['layout'];

    $layout = !empty($layout) ? $layout : 'standard';
    return $layout;
}

function sunrise_get_categories()
{
    return SunriseBlogCustomize::sunrise_refresh_in_customize('pi_options[content][page_template][categories][]') ? SunriseBlogCustomize::sunrise_refresh_in_customize('pi_options[content][page_template][categories][]') : SunriseBlogFramework::$piOptions['content']['page_template']['categories'][''];
}