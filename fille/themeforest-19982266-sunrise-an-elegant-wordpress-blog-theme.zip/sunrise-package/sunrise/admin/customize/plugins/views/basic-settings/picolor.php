<?php

/**
 * get custom color
 * @since 1.0
 */
function sunrise_get_custom_color()
{
    return SunriseBlogCustomize::sunrise_refresh_in_customize('pi_options[basic_settings][custom_color]') ? SunriseBlogCustomize::sunrise_refresh_in_customize('pi_options[basic_settings][custom_color]') : SunriseBlogFramework::$piOptions['basic_settings']['custom_color'];
}

function sunrise_get_my_color()
{
    return SunriseBlogCustomize::sunrise_refresh_in_customize('pi_options[basic_settings][custom_yourcolor]') ? SunriseBlogCustomize::sunrise_refresh_in_customize('pi_options[basic_settings][custom_yourcolor]') : SunriseBlogFramework::$piOptions['basic_settings']['custom_yourcolor'];
}

