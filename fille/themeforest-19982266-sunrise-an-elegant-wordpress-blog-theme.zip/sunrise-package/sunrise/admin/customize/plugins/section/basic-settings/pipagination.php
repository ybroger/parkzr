<?php
$wp_customize->add_section('pi_pagination', array(
   'title'     => esc_html__('Pagination', 'sunrise'),
   'panel'     => 'sunrise_basic_settings_panel',
   'priority'  => $this->piSectionPriority++
));

$wp_customize->add_setting(
   'pi_options[basic_settings][pagination]',
   array(
       'default'           =>  parent::$piOptions['basic_settings']['pagination'],
       'type'              =>  'option',
       'capability'        =>  'edit_theme_options',
       'sanitize_callback' =>  array($this, 'sunrise_sanitize_data')
   )
);
$wp_customize->add_control(
   'pi_options[basic_settings][pagination]',
   array(
       'label'         => esc_html__('Style', 'sunrise'),
       'section'       => 'pi_pagination',
       'settings'      => 'pi_options[basic_settings][pagination]',
       'priority'      => $this->piControlPriority++,
       'type'          => 'select',
       'choices'       => array(
                           'navigation' => esc_html__('Next &amp; Prev', 'sunrise'),
                           'number'     => esc_html__('Number', 'sunrise')
                       )
   )
);