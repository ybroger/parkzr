<?php
/**
 * In the case of page template
 */

function sunrise_posts_per_page_of_page_template()
{

    if ( SunriseBlogCustomize::sunrise_refresh_in_customize("pi_options[basic_settings][posts_per_page]") )
    {
        $postPerPages = SunriseBlogCustomize::sunrise_refresh_in_customize("pi_options[basic_settings][posts_per_page]");

    }else{
        if ( isset(SunriseBlogFramework::$piOptions['basic_settings']['posts_per_page']) )
        {
            $postPerPages = SunriseBlogFramework::$piOptions['basic_settings']['posts_per_page'];
        }else{
            $postPerPages = get_option('posts_per_page');
        }
    }
    return $postPerPages;
}
