<?php
/**
 * Render favicon
 */
function sunrise_render_favicon()
{
    $source  =  SunriseBlogCustomize::sunrise_refresh_in_customize('pi_options[basic_settings][favicon]') ? SunriseBlogCustomize::sunrise_refresh_in_customize('pi_options[basic_settings][favicon]') : SunriseBlogFramework::$piOptions['basic_settings']['favicon'];

    if ( !empty($source) )
    {
        echo '<link rel="icon" type="image/x-icon" href="'.esc_url($source).'">';
    }
}
