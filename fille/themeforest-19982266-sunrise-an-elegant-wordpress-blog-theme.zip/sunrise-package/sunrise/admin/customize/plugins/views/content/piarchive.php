<?php
/**
 * Created by Next-theme
 * @since 1.0
 */
function sunrise_get_archive_layout()
{
    return SunriseBlogCustomize::sunrise_refresh_in_customize('pi_options[content][archive_layout]') ? SunriseBlogCustomize::sunrise_refresh_in_customize('pi_options[content][archive_layout]') : SunriseBlogFramework::$piOptions['content']['archive_layout'];
}
