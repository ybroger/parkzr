;(function($){
	"use strict"

	var steps = [{
			element: '#page_template',
			intro: 'If you wanna create a page template, please set the page as Page Template mode.',
			position: 'left'
		},
		{
			element: '#publish',
			intro: 'Next, Click Publish/Update button',
			position: 'left'
		},
		{
			element: '.pi-page-templates-button',
			intro: 'Now, click on Content Builder button. After you have clicked on it, the browser will redirect to Customize area. Here you can create a page template with a lot of settings',
			position: 'right'
		}
      ];

    function startIntro(){
        var intro = introJs();
          intro.setOptions({
            steps: steps,
            showBullets: true,
            showButtons: true,
            showProgress: true,
            exitOnOverlayClick: true,
            showStepNumbers: true,
            keyboardNavigation: true
          });

          intro.start();
  	}
})(jQuery)