<?php
/**
 * Standard layout
 */
global $piOrder, $isFirstLarge, $piCurrentLayout;
$postFormat = get_post_format($post->ID);
$link       = sunrise_get_post_link($post->ID, $postFormat);

?>
<div class="pi-grid-item">
    <?php
    if ( $piOrder == 1 && $isFirstLarge ) :
        $piCurrentLayout = 'special';
        get_template_part('layout/standard');
    else:
    ?>
    <!-- Post -->
    <article <?php post_class('post'); ?>>
        <!-- Post Media -->

        <div class="post-media">
            <?php if ( has_post_thumbnail($post->ID) ) : ?>
            <div class="images">
                <a href="<?php echo esc_url($link); ?>"><?php the_post_thumbnail('sunrise-listlayout'); ?></a>
            </div>
            <?php endif; ?>
        </div>
        <!-- / Post Media -->

        <!-- Post Body -->
        <div class="post-body">
            <div class="post-cat">
                <?php echo sunrise_get_list_of_categories($post->ID); ?>
            </div>


            <div class="post-title">
                <h2><a href="<?php echo esc_url($link); ?>"><?php the_title(); ?></a></h2>
            </div>

            <div class="post-date">
                <span><?php echo sunrise_get_the_date($post->ID); ?></span>
            </div>

            <div class="post-entry">
                <?php sunrise_content_limit(); ?>
            </div>

            <div class="post-foot">
                <div class="tb">
                    <div class="post-meta tb-cell">
                        <?php sunrise_post_meta($postFormat, $link, $post->ID); ?>
                    </div>
                </div>
            </div>
            <?php edit_post_link(); ?>
        </div>
        <!-- / Post Body -->

    </article>
    <?php
    endif;
    ?>
    <!-- / Post -->
</div>

