<?php
/**
 * It allows custom color
 */
$wp_customize->add_section('pi_custom_color', array(
    'title'     => esc_html__('Custom Color', 'sunrise'),
    'panel'     => 'sunrise_basic_settings_panel',
    'priority'  => $this->piSectionPriority++
));

$wp_customize->add_setting(
    'pi_options[basic_settings][custom_color]',
    array(
        'default'           =>  parent::$piOptions['basic_settings']['custom_color'],
        'type'              =>  'option',
        'capability'        =>  'edit_theme_options',
        'sanitize_callback' =>  array($this, 'sunrise_sanitize_data')
    )
);
$wp_customize->add_control(
    'pi_options[basic_settings][custom_color]',
    array(
        'label'         => esc_html__('Color mode', 'sunrise'),
        'section'       => 'pi_custom_color',
        'settings'      => 'pi_options[basic_settings][custom_color]',
        'priority'      => $this->piControlPriority++,
        'type'          => 'select',
        'choices'       => piConfigs::$aConfigs['configs']['basic_settings']['custom_color']['colors']
    )
);

$wp_customize->add_setting(
    'pi_options[basic_settings][custom_yourcolor]',
    array(
        'default'           =>  '#FFF',
        'type'              =>  'option',
        'capability'        =>  'edit_theme_options',
        'sanitize_callback' =>  array($this, 'sunrise_sanitize_data')
    )
);

$wp_customize->add_control(
    new WP_Customize_Color_Control(
        $wp_customize,
        'pi_options[basic_settings][custom_yourcolor]',
        array(
            'label'         => esc_html__('Custom Color. Switch to Custom Color mode before.', 'sunrise'),
            'section'       => 'pi_custom_color',
            'settings'      => 'pi_options[basic_settings][custom_yourcolor]',
            'priority'      => $this->piControlPriority++
        )
    )
);