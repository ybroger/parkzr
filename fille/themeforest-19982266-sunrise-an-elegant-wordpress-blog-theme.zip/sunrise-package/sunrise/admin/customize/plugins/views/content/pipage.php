<?php
/**
 * Created by Next-theme
 */

/* Page Sidebar */
function sunrise_get_sidebar_on_page()
{
    $sidebar = SunriseBlogCustomize::sunrise_refresh_in_customize("pi_options[content][sidebar_on_page]")  ? SunriseBlogCustomize::sunrise_refresh_in_customize("pi_options[sidebar_on_page]") : SunriseBlogFramework::$piOptions['content']['sidebar_on_page'];
    if ( $sidebar == 'default' )
    {
        $sidebar = sunrise_get_sidebar_layout();
    }
    return $sidebar;
}
/* End / Page Sidebar */