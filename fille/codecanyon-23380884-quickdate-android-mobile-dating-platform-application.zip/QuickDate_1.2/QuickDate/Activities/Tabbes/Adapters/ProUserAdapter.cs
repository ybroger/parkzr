﻿using System;
using System.Collections.ObjectModel;
using Android.Content;
using Android.Graphics;
using Android.Support.V7.Widget;
using Android.Views;
using Android.Widget;
using Qintong.Library;
using QuickDate.Helpers.CacheLoaders;
using QuickDate.Helpers.Fonts;
using QuickDate.Helpers.Utils;
using QuickDateClient.Classes.Global;

namespace QuickDate.Activities.Tabbes.Adapters
{
    public class ProUserAdapter : RecyclerView.Adapter
    {
        public event EventHandler<ProUserAdapterClickEventArgs> OnItemClick;
        public event EventHandler<ProUserAdapterClickEventArgs> OnItemLongClick;
        public Context ActivityContext;
        public ObservableCollection<UserInfoObject> ProUserList = new ObservableCollection<UserInfoObject>();

        public ProUserAdapter(Context context)
        {
            try
            {
                ActivityContext = context;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        // Create new views (invoked by the layout manager)
        public override RecyclerView.ViewHolder OnCreateViewHolder(ViewGroup parent, int viewType)
        {
            try
            {
                //Setup your layout here >> Style_StoryView
                View itemView = LayoutInflater.From(parent.Context).Inflate(Resource.Layout.Style_StoryView, parent, false);
                var vh = new ProUserAdapterViewHolder(itemView, LongClick);
                return vh;
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
                return null;
            }
        }

        // Replace the contents of a view (invoked by the layout manager)
        public override void OnBindViewHolder(RecyclerView.ViewHolder viewHolder, int position)
        {
            try
            {

                if (viewHolder is ProUserAdapterViewHolder holder)
                {
                    var item = ProUserList[position];
                    if (item != null)
                    {
                        //Dont Remove this code #####
                        FontUtils.SetFont(holder.Name, Fonts.SfRegular);
                        //#####
                        try
                        {
                            holder.Circleindicator.Status = InsLoadingView.Statuses.Loading;
                            holder.Circleindicator.SetStartColor(Color.ParseColor(AppSettings.StartColor));
                            holder.Circleindicator.SetEndColor(Color.ParseColor(AppSettings.EndColor));

                            if (holder.Circleindicator.Tag?.ToString() != "Loaded")
                            {
                                ImageCacheLoader.LoadImage(item.Avater, holder.Circleindicator, true, false);

                                holder.Circleindicator.Tag = "Loaded";
                            }
                             
                            holder.Name.Text = QuickDateTools.GetNameFinal(item);

                            if (item.Type != "Your")
                            {
                                holder.Circleindicator.Status = InsLoadingView.Statuses.Unclicked;
                                holder.IconCircle.Visibility = ViewStates.Gone;
                                holder.IconStory.Visibility = ViewStates.Gone;
                            }

                            if (!holder.Circleindicator.HasOnClickListeners)
                                holder.Circleindicator.Click += (sender, e) => Click(new ProUserAdapterClickEventArgs{View = holder.MainView, Position = position , Image = holder.Circleindicator });

                        }
                        catch (Exception e)
                        {
                            Console.WriteLine(e);
                        }
                    }
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }


        public void Clear()
        {
            try
            {
                ProUserList.Clear();
                NotifyDataSetChanged();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public override int ItemCount
        {
            get
            {
                if (ProUserList != null)
                {
                    return ProUserList.Count;
                }
                else
                {
                    return 0;
                }
            }
        }

        public UserInfoObject GetItem(int position)
        {
            return ProUserList[position];
        }

        public override long GetItemId(int position)
        {
            try
            {
                return position;
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
                return 0;
            }
        }

        public override int GetItemViewType(int position)
        {
            try
            {
                return position;
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
                return 0;
            }
        }

        public void Click(ProUserAdapterClickEventArgs args) => OnItemClick?.Invoke(this, args);

        void LongClick(ProUserAdapterClickEventArgs args) => OnItemLongClick?.Invoke(this, args);
    }

    public class ProUserAdapterViewHolder : RecyclerView.ViewHolder
    {
        #region Variables Basic

        public View MainView { get; private set; }

        public TextView Name { get; set; }
        public InsLoadingView Circleindicator { get; set; }
        public View IconCircle { get; set; }
        public TextView IconStory { get; set; }

        #endregion

        public ProUserAdapterViewHolder(View itemView, Action<ProUserAdapterClickEventArgs> longClickListener) :base(itemView)
        {
            try
            {
                MainView = itemView;

                Name = MainView.FindViewById<TextView>(Resource.Id.Txt_Username);
                Circleindicator = MainView.FindViewById<InsLoadingView>(Resource.Id.profile_indicator);
                IconCircle = MainView.FindViewById<View>(Resource.Id.IconCircle);
                IconStory = MainView.FindViewById<TextView>(Resource.Id.IconStory);

                //Event
                //itemView.Click += (sender, e) => clickListener(new ProUserAdapterClickEventArgs { View = itemView, Position = AdapterPosition }); 
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
            }
        }
    }

    public class ProUserAdapterClickEventArgs : EventArgs
    {
        public View View { get; set; }
        public int Position { get; set; }
        public ImageView Image { get; set; }
    }
}