<?php
/**
 * The settings of logo & header panel
 * @since 1.0
 */

$wp_customize->add_section('pi_logo', array(
    'title'     => esc_html__('Logo', 'sunrise'),
    'panel'     => 'pi_logoheader_panel',
    'priority'  => $this->piSectionPriority++
));

do_action('pi_before_customize_logo', $wp_customize, $this->piControlPriority);

$wp_customize->add_setting(
    "pi_options[logoheader][logo]",
    array(
        'default'       =>  parent::$piOptions['logoheader']['logo'],
        'type'          => 'option',
        'capability'    => 'edit_theme_options',
        'sanitize_callback' => array($this, 'sunrise_sanitize_data')
    )
);
$wp_customize->add_control( new WP_Customize_Image_Control(
    $wp_customize,
    'pi_options[logoheader][logo]',
    array(
        'label'      => esc_html__( 'Upload Logo', 'sunrise'),
        'section'    => 'pi_logo',
        'settings'   => 'pi_options[logoheader][logo]',
        'priority'   => $this->piControlPriority++
    )
));

$wp_customize->add_setting(
    "pi_options[logoheader][retina_logo]",
    array(
        'default'       =>  parent::$piOptions['logoheader']['retina_logo'],
        'type'          => 'option',
        'capability'    => 'edit_theme_options',
        'sanitize_callback' => array($this, 'sunrise_sanitize_data')
    )
);
$wp_customize->add_control( new WP_Customize_Image_Control(
    $wp_customize,
    'pi_options[logoheader][retina_logo]',
    array(
        'label'      => esc_html__( 'Upload Retina Logo', 'sunrise'),
        'section'    => 'pi_logo',
        'settings'   => 'pi_options[logoheader][retina_logo]',
        'priority'   => $this->piControlPriority++
    )
));

do_action('pi_after_customize_logo', $wp_customize, $this->piControlPriority);