<?php
/* Template Name: About */

get_header();
?>
    <div class="main-content pi-page no-sidebar pi-about">
        <div class="pi-container">
            <div class="pi-row">
                <div class="pi-content">
                        <?php
                        if ( have_posts() ) :
                          $aSettings = get_post_meta($post->ID, '_pi_special_page', true);
                        ?>
                            <div class="category-page-title">
                                <div class="wrap-title">
                                    <?php if ( isset($aSettings['sup_title']) ) : ?>
                                    <span><?php echo esc_html($aSettings['sup_title']); ?></span>
                                    <?php endif; ?>
                                    <h1><?php the_title(); ?></h1>
                                </div>
                            </div>
                        <?php
                            while ( have_posts() ) : the_post();
                                ?>
                                <article class="post">
                                    <!-- Post Media -->
                                    <?php if ( has_post_thumbnail($post->ID) ) : ?>
                                    <div class="post-media">
                                        <div class="images">
                                            <?php the_post_thumbnail('large'); ?>
                                        </div>
                                    </div>
                                    <?php endif; ?>
                                    <!-- / Post Media -->

                                    <div class="post-body">
                                        <!--Content-->
                                        <div class="post-entry">
                                            <?php
                                            the_content();
                                            ?>
                                        </div>
                                        <!--End/Content-->

                                        <!--Foot-->
                                        <div class="post-foot">
                                            <div class="tb">
                                                <?php 
                                                do_action('sunrise_render_sharing_post');
                                                ?>
                                            </div>
                                        </div>
                                        <!--End/Foot-->

                                    </div>
                                </article>
                            <?php
                            endwhile;
                        else:
                            get_template_part("content", "none");
                        endif; wp_reset_postdata();
                        ?>
                </div>
            </div>
        </div>
    </div>
<?php
get_footer();
?>