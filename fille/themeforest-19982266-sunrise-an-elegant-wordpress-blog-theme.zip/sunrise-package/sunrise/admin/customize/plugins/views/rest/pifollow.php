<?php
/**
 * Render Follow us on social networks
 * @since 1.0
 */

function sunrise_render_before_social_icon($showingTitle = false)
{
    $content = SunriseBlogCustomize::sunrise_refresh_in_customize("pi_options[follow][before_social_icon]") ? SunriseBlogCustomize::sunrise_refresh_in_customize("pi_options[follow][before_social_icon]") : '';
    if ( empty($content) && isset(SunriseBlogFramework::$piOptions['follow']['before_social_icon']) )
    {
        $content = SunriseBlogFramework::$piOptions['follow']['before_social_icon'];
    }

    return $content;
}

function sunrise_render_follow($showingTitle = false)
{
    $follow = "";

    foreach ( piConfigs::$aConfigs['configs']['rest']['follow'] as $key => $aInfo )
    {
        $social = SunriseBlogCustomize::sunrise_refresh_in_customize("pi_options[follow][$key]") ? SunriseBlogCustomize::sunrise_refresh_in_customize("pi_options[follow][$key]") :
            SunriseBlogFramework::$piOptions['follow'][$key];

        if ( !empty($social) )
        {
            $follow .= '<a href="'.esc_url($social).'" target="_blank">';
                if ( $showingTitle )
                {
                    $follow .= ' ' . $aInfo[1];
                }
            $follow .= '</a>';
        }
    }

    if ( empty($follow) )
    {
        return;
    }

    $follow = '<div>' . sunrise_render_before_social_icon() . $follow . '</div>';

    do_action('pi_before_render_follow');
        echo '<div class="'.apply_filters('sunrise_filter_follow_wrapper_class', 'pi-follow').'">';
            if ( has_filter('sunrise_filter_render_follow') )
            {
                echo apply_filters('sunrise_filter_render_follow', $follow, array('classes'=>'pi-follow', 'id'=>''));
            }else{
                sunrise_wp_kses($follow);
            }
        echo '</div>';
    do_action('pi_after_render_follow');
}

function sunrise_render_footer_social()
{
    $follow = "";
    foreach ( piConfigs::$aConfigs['configs']['rest']['follow'] as $key => $aInfo )
    {
        $social = SunriseBlogCustomize::sunrise_refresh_in_customize("pi_options[follow][$key]") ? SunriseBlogCustomize::sunrise_refresh_in_customize("pi_options[follow][$key]") :
            SunriseBlogFramework::$piOptions['follow'][$key];

        if ( !empty($social) )
        {
            $follow .= '<a href="'.esc_url($social).'" target="_blank"><i class="'.esc_attr($aInfo[0]).'"></i></a>';
        }
    }

    if ( !empty($follow) )
    {
        $follow = '<div class="footer-social text-center"><div class="pi-social-rotate">'.$follow.'</div></div>';
    }

    print $follow;
}
