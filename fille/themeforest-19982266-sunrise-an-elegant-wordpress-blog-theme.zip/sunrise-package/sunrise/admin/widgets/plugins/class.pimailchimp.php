<?php
/**
 * Created by Next-theme
 */
class piMailchimp extends WP_Widget
{
    public $aDef  = array('title' => 'Mailchimp', 'description'=>'', 'list_id'=>'');
    public function __construct()
    {
        $args = array('classname'=>'pi_mailchimp widget_newsletter', 'description'=>'');
        parent::__construct('pi_mailchimp', SUNRISE_THEMENAME.'Mailchimp', $args);
    }

    public function form($aInstance)
    {
        if ( !class_exists('sunriseFunctionality') )
        {
            echo '<p><code>'.esc_html__('Sunrise Functionality plugin is required', 'sunrise').'</code></p>';
            return;
        }

        $aInstance = wp_parse_args($aInstance, $this->aDef);

        piWidgets::pi_text_field( 'Title', $this->get_field_id('title'), $this->get_field_name('title'), $aInstance['title']);
        piWidgets::pi_textarea_field( 'Description', $this->get_field_id('description'), $this->get_field_name('description'), $aInstance['description']);

        if ( !get_option('pi_mailchimp_api_key') )
        {
            echo '<p><code>'.sprintf( (__('You haven\'t configured your mailchimp yet. Please go <a href="%s" target="_blank">here</a> to do it.', 'sunrise')), admin_url('themes.php?page=pi-config-mailchimp') ).'</code></p>';
        }
    }

    public function update($new_instance, $old_instance)
    {
        $instance = $old_instance;
        foreach ($new_instance as $key => $value)
        {
            $instance[$key] = strip_tags($value);
        }

        update_option("pi_mailchimp_api_key", $instance['api_key']);
        update_option("pi_mailchimp_listid", $instance['list_id']);

        return $instance;
    }

    public function widget($atts, $aInstance)
    {
        if ( !class_exists('sunriseFunctionality') )
        {
            return false;
        }
        
        $aInstance = wp_parse_args($aInstance, $this->aDef);

        sunrise_wp_kses($atts['before_widget']);
            if ( !empty($aInstance['title']) )
            {
                echo sunrise_wp_kses($atts['before_title'], false) . esc_html($aInstance['title']) . sunrise_wp_kses($atts['after_title'], false);
            }
            if ( !empty($aInstance['description']) )
            {
                echo '<div class="text-italic">';
                    echo '<p>'.esc_html($aInstance['description']).'</p>';
                echo '</div>';
            }

            if ( !get_option('pi_mailchimp_api_key') )
            {
                if ( is_user_logged_in() && current_user_can('edit_theme_options') )
                {
                    printf( (__('<p>Please <a href="%s" target="_blank" style="color:#ff0771">config</a> your mailchimp</p>', 'sunrise')), admin_url('themes.php?page=pi-config-mailchimp') );
                }
            }else{
            ?>
            <form class="pi_subscribe">
                <div class="form-item form-remove">
                    <input type="email" class="pi-subscribe-email" value="<?php esc_html_e('Your mail...', 'sunrise'); ?>" required />
                </div>
                <div class="form-actions form-remove form-submit">
                    <button id="pi-mailchimp-subscribe" type="submit" data-nonce="<?php echo esc_attr(wp_create_nonce( "pi_subscribe_nonce" )); ?>" class="pi-btn pi-subscribe"><?php esc_html_e('Subscribe', 'sunrise'); ?></button>
                </div>
                <p class="subscribe-status alert-done" style="display: none"><?php esc_html_e('Submit success - Bigs thank for you','sunrise');?></p>
            </form>
            <?php
            }
        sunrise_wp_kses($atts['after_widget']);
    }
}