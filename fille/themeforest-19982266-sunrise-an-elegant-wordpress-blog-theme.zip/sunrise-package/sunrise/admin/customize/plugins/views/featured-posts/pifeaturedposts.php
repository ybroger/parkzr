<?php
/**
 * Created by Next-theme
 */

function sunrise_render_featured_slider()
{
    $toggle = false;

    $toggle = SunriseBlogCustomize::sunrise_refresh_in_customize('pi_options[featuredposts][toggle]') ? SunriseBlogCustomize::sunrise_refresh_in_customize('pi_options[featuredposts][toggle]') : SunriseBlogFramework::$piOptions['featuredposts']['toggle'];


    $toggle = $toggle == 'disable' || $toggle == '0' ? false : $toggle;

    if ( !$toggle ) {
        return;
    }

    if ( $toggle != 2 )
    {
        do_action('pi_before_featured_posts');

        $layout         = SunriseBlogCustomize::sunrise_refresh_in_customize('pi_options[featuredposts][layout]') ? SunriseBlogCustomize::sunrise_refresh_in_customize('pi_options[featuredposts][layout]') : SunriseBlogFramework::$piOptions['featuredposts']['layout'];
        $type           = SunriseBlogCustomize::sunrise_refresh_in_customize('pi_options[featuredposts][type]') ? SunriseBlogCustomize::sunrise_refresh_in_customize('pi_options[featuredposts][type]') : SunriseBlogFramework::$piOptions['featuredposts']['type'];
        $exclude        = SunriseBlogCustomize::sunrise_refresh_in_customize('pi_options[featuredposts][exclude_featured_posts]') ? SunriseBlogCustomize::sunrise_refresh_in_customize('pi_options[featuredposts][exclude_featured_posts]') : SunriseBlogFramework::$piOptions['featuredposts']['exclude_featured_posts'];
        $numberOfPosts  = SunriseBlogCustomize::sunrise_refresh_in_customize('pi_options[featuredposts][number_of_posts]') ? SunriseBlogCustomize::sunrise_refresh_in_customize('pi_options[featuredposts][number_of_posts]') : SunriseBlogFramework::$piOptions['featuredposts']['number_of_posts'];
        $numberOfPosts  = empty($numberOfPosts) ? 5 : $numberOfPosts;

        $args = array(
            'posts_per_page'        => (int)$numberOfPosts,
            'post_type'             => 'post',
            'post_status'           => 'publish',
            'order'                 => 'DESC',
            'orderby'               => 'post_date',
            'ignore_sticky_posts'   => 1
        );

        if ( $type == 'category' ) {
            $catID =  SunriseBlogCustomize::sunrise_refresh_in_customize('pi_options[featuredposts][category]') ? SunriseBlogCustomize::sunrise_refresh_in_customize('pi_options[featuredposts][category]') : SunriseBlogFramework::$piOptions['featuredposts']['category'];
            $args['cat'] = (int)$catID;
        } elseif ($type=='sticky') {
            $args['post__in'] = get_option( 'sticky_posts' );
        } elseif ($type=='rand') {
            $args['orderby'] =  'rand';
        }

        $query = new WP_Query($args); ?>

        <div class="owl-carousel owl-theme featured-slider <?php echo esc_attr($layout); ?>">

            <?php
                if ( $query->have_posts() ) :  while ( $query->have_posts() ) : $query->the_post();

                    SunriseBlogFramework::$piFeaturedPostsId[] = $query->post->ID;

                    $postFormat = get_post_format($query->post->ID);

                    $isGetLink = true;

                    if ( isset($postFormat) && $postFormat == 'link' )
                    {
                        $content = get_the_content($query->post->ID);
                        if ( $content == '' )
                        {
                            $aPostMeta = get_post_meta($query->post->ID, 'pi_post', true);
                            $link      = isset($aPostMeta['link']) ? $aPostMeta['link'] : '';
                            $isGetLink = false;
                            $target    = 'target="_blank"';
                        }
                    }

                    if ( $isGetLink )
                    {
                        $link   = get_permalink($query->post->ID);
                        $target = '';
                    }
                
                    $postThumbnail = has_post_thumbnail($query->post->ID) ? get_the_post_thumbnail_url( $query->post->ID, 'large') : ''; ?>

                        <div class="item">

                            <div class="background-image" data-background-image="<?php echo esc_url($postThumbnail); ?>"></div>

                            <div class="item-content">

                                <div class="item-cat">
                                    <?php echo sunrise_get_list_of_categories($query->post->ID); ?>
                                </div>

                                <div class="item-title">
                                    <h2><a <?php echo esc_attr($target); ?> href="<?php echo esc_url($link); ?>"><?php echo get_the_title($query->post->ID); ?></a></h2>
                                </div>

                                <hr class="pi-divider pi-divider-white">

                                <div class="item-more">
                                    <a <?php echo esc_attr($target); ?> href="<?php echo esc_url($link); ?>"><?php esc_html_e('Read more', 'sunrise'); ?></a>
                                </div>

                            </div>

                        </div>

                    <?php endwhile; 

                    wp_reset_postdata();

                endif;

                if ( $exclude != '1' ) {
                    SunriseBlogFramework::$piFeaturedPostsId = array();
                }
            ?>

        </div>

        <?php do_action('pi_after_featured_posts');

    } else {
        $shortcode  = SunriseBlogCustomize::sunrise_refresh_in_customize('pi_options[featuredposts][shortcode]') ? SunriseBlogCustomize::sunrise_refresh_in_customize('pi_options[featuredposts][shortcode]') : SunriseBlogFramework::$piOptions['featuredposts']['shortcode'];
        echo do_shortcode($shortcode);
    }
}
