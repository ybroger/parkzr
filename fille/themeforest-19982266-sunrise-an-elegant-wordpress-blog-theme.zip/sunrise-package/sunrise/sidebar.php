<?php
/**
 * Created by Next-theme
 */
?>
<!-- Sidebar -->
<?php if ( is_active_sidebar('pi_sidebar') ) : ?>
<div class="pi-sidebar <?php echo esc_attr(sunrise_get_sidebar_sticky()); ?>">
    <?php dynamic_sidebar('pi_sidebar'); ?>
</div>
<?php endif; ?>
<!-- / Sidebar -->