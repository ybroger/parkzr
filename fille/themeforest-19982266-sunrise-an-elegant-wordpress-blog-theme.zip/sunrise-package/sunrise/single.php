<?php
get_header();

$sectionClass   =  sunrise_get_sidebar_layout();
?>
    <div class="main-content pi-single <?php echo esc_attr($sectionClass); ?>">
        <div class="pi-container">
            <div class="pi-row">
                <div class="pi-content">
                   <?php
                   while ( have_posts() ) : the_post();
                       $postFormat = get_post_format($post->ID);
                       $link       = get_permalink();
                       $title      = get_the_title();
                   ?>
                   <article <?php post_class(); ?>>
                       <!--Post media-->
                       <?php echo sunrise_render_post_head_options($post->ID, $postFormat, $title, $link); ?>
                       <!--End/Post media-->
                       <div class="post-body">

                           <!--Post meta-->
                           <div class="post-cat">
                               <?php echo sunrise_get_list_of_categories($post->ID); ?>
                           </div>
                           <div class="post-title">
                               <h1><?php the_title(); ?></h1>
                           </div>
                           <div class="post-date">
                               <span><?php echo sunrise_get_the_date($post->ID); ?></span>
                           </div>
                           <!--End/Post meta-->

                            <?php 
                              if ( class_exists('WilokeSharingPost') ) 
                              { 
                                echo '<div class="post-social tb-cell"><div class="single-share">' . do_shortcode('[wiloke_sharing_post]') . '</div></div>'; 
                              }
                            ?>

                           <!--Content-->
                           <div class="post-entry">
                                <?php
                                    the_content();
                                    wp_link_pages(
                                        array(
                                       'before'      => '<div class="page-links"><span class="page-links-title">' . esc_html__( 'Pages:', 'sunrise') . '</span>',
                                       'after'       => '</div>',
                                       'link_before' => '<span>',
                                       'link_after'  => '</span>',
                                       'separator'   => '<span class="screen-reader-text">, </span>',
                                       )
                                    );
                                ?>
                           </div>
                           <!--End/Content-->

                           <!--Tags-->
                           <?php if ( has_tag() ) : ?>
                           <div class="tag-box">
                               <?php the_tags(); ?>
                           </div>
                            <?php endif; ?>
                           <!--End/Tags-->

                           <!--Foot-->
                            <div class="post-foot">
                                <div class="tb">
                                    <div class="post-meta tb-cell">
                                        <?php sunrise_post_meta($postFormat, $link, $post->ID); ?>
                                    </div>
                                    <?php 
                                    do_action('sunrise_render_sharing_post');
                                    ?>
                                </div>
                            </div>
                           <!--End/Foot-->

                       </div>
                   </article>
                    <?php get_template_part("author-bio"); ?>
                    <?php sunrise_render_related_posts(); ?>
                    <?php comments_template(); ?>
                    <?php endwhile; wp_reset_postdata(); ?>
                </div>
                <?php
                if ( $sectionClass != 'no-sidebar' )
                {
                    get_sidebar();
                }
                ?>
            </div>
        </div>
    </div>
<?php get_footer(); ?>