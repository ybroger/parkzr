<?php
/**
 * Follow us
 * It allows filter panel
 * @since 1.0
 */

$wp_customize->add_section(
    'pi_follow',
    array(
        'title'      => esc_html__('Follow Me', 'sunrise'),
        'priority'   => $this->piSectionPriority,
        'panel'      => 'sunrise_basic_settings_panel',
        'description'=> esc_html__('Displaying the search form at the top menu or no', 'sunrise'),
    )
);

$wp_customize->add_setting(
    "pi_options[follow][before_social_icon]",
    array(
        'default'       =>  'Follow me on',
        'type'          => 'option',
        'capability'    => 'edit_theme_options',
        'sanitize_callback' => array($this, 'sunrise_sanitize_data')
    )
);

$wp_customize->add_control('pi_options[follow][before_social_icon]',
    array(
        'label'     => esc_html__('Before Social Icon', 'sunrise'),
        'section'   => 'pi_follow',
        'settings'  => 'pi_options[follow][before_social_icon]',
        'priority'  => $this->piControlPriority++,
        'type'      => 'text'
    )
);

/**
 * @param $aInfo: $aInfo[0] the fontawesome code. $aInfo[1] the name of this social
 */
foreach ( piConfigs::$aConfigs['configs']['rest']['follow'] as $name => $aInfo )
{
    $wp_customize->add_setting(
        "pi_options[follow][$name]",
        array(
            'type'              => 'option',
            'capability'        => 'edit_theme_options',
            'default'           => esc_url(parent::$piOptions['follow'][$name]),
            'sanitize_callback' => array($this, 'sunrise_sanitize_data')
        )
    );

    $wp_customize->add_control(
        "pi_options[follow][$name]",
        array(
            'type'      => 'url',
            'priority'  => $this->piControlPriority++,
            'label'     => $aInfo[1],
            'section'   => 'pi_follow',
            'settings'  => "pi_options[follow][$name]"
        )
    );
}
