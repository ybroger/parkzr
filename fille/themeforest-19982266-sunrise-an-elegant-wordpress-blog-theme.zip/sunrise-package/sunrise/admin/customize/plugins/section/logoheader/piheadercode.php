<?php
/**
 * Header code
 * @since 1.0
 */
$wp_customize->add_section('pi_header_custom_code', array(
    'title'     => esc_html__('Custom Code', 'sunrise'),
    'panel'     => 'pi_logoheader_panel',
    'priority'  => $this->piSectionPriority++
));

$wp_customize->add_setting(
    'pi_options[logoheader][header_code]',
    array(
        'default'       =>  esc_textarea(parent::$piOptions['logoheader']['header_code']),
        'type'          => 'option',
        'capability'    => 'edit_theme_options',
        'sanitize_callback' => array($this, 'sunrise_sanitize_data')
    )
);

$wp_customize->add_control( new piTextarea(
    $wp_customize,
    'pi_options[logoheader][header_code]',
    array(
        'label'      => '',
        'section'    => 'pi_header_custom_code',
        'priority'   => $this->piControlPriority++,
        'settings'   => 'pi_options[logoheader][header_code]'
    )
));