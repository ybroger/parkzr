<?php
function sunrise_promo_second_block()
{
    $link = SunriseBlogCustomize::sunrise_refresh_in_customize("pi_options[pi_promo][secondblock][link]") ? SunriseBlogCustomize::sunrise_refresh_in_customize("pi_options[pi_promo][secondblock][link]") : '';
    $link = empty($link) && isset(SunriseBlogFramework::$piOptions['pi_promo']['secondblock']['link']) ? SunriseBlogFramework::$piOptions['pi_promo']['secondblock']['link'] : $link;

    if ( empty($link) )
    {
        return;
    }

    $heading = SunriseBlogCustomize::sunrise_refresh_in_customize("pi_options[pi_promo][secondblock][heading]") ? SunriseBlogCustomize::sunrise_refresh_in_customize("pi_options[pi_promo][secondblock][heading]") : '';
    $heading = empty($heading) && isset(SunriseBlogFramework::$piOptions['pi_promo']['secondblock']['heading']) ? SunriseBlogFramework::$piOptions['pi_promo']['secondblock']['heading'] : $heading;

    $desc = SunriseBlogCustomize::sunrise_refresh_in_customize("pi_options[pi_promo][secondblock][description]") ? SunriseBlogCustomize::sunrise_refresh_in_customize("pi_options[pi_promo][secondblock][description]") : '';
    $desc = empty($desc) && isset(SunriseBlogFramework::$piOptions['pi_promo']['secondblock']['description']) ? SunriseBlogFramework::$piOptions['pi_promo']['secondblock']['description'] : $desc;

    $bgImg = SunriseBlogCustomize::sunrise_refresh_in_customize("pi_options[pi_promo][secondblock][bg_img]") ? SunriseBlogCustomize::sunrise_refresh_in_customize("pi_options[pi_promo][secondblock][bg_img]") : '';
    $bgImg = empty($bgImg) && isset(SunriseBlogFramework::$piOptions['pi_promo']['secondblock']['bg_img']) ? SunriseBlogFramework::$piOptions['pi_promo']['secondblock']['bg_img'] : $bgImg;

    $target = SunriseBlogCustomize::sunrise_refresh_in_customize("pi_options[pi_promo][secondblock][target]") ? SunriseBlogCustomize::sunrise_refresh_in_customize("pi_options[pi_promo][secondblock][target]") : '';
    $target = empty($target) && isset(SunriseBlogFramework::$piOptions['pi_promo']['secondblock']['target']) ? SunriseBlogFramework::$piOptions['pi_promo']['secondblock']['target'] : $target;
    $target = !empty($target) ? $target : '_self';
    ob_start();
    ?>
    <div class="tb-cell">
        <div class="pi-promo-item">
            <a href="<?php echo esc_url($link); ?>" target="<?php echo esc_attr($target); ?>">
                <div class="image" style="background-image: url(<?php echo esc_url($bgImg); ?>);"></div>
                <div class="text">
                    <h3><?php echo esc_html($heading); ?></h3>
                    <span><?php sunrise_wp_kses($desc); ?></span>
                </div>
            </a>
            <div class="promo-overlay"></div>
        </div>
    </div>
    <?php
    $html = ob_get_contents();
    ob_end_clean();
    return $html;
}