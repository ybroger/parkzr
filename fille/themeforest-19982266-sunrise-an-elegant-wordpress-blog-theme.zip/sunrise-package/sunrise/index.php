<?php
get_header();
global $piOrder, $isFirstLarge;
$layout          = pi_get_content_layout();
$layout = empty($layout) ? 'standard' : $layout;
$isFirstLarge    = false;
if ( strpos($layout, "_") !== false )
{
    $parseLayout  = explode("_", $layout);
    $layout       = $parseLayout[0];
    $isFirstLarge = true;
    $sectionClass = 'pi-'.$layout. ' pi-'.$layout.'-'.$parseLayout[1] . ' ';
}else{
    $sectionClass = 'pi-'.$layout. ' ';
}

$sidebar         =  sunrise_get_sidebar_layout();
$sectionClass   .= $sidebar;


if ( sunrise_is_page_template() )
{
    $args = array(
        'post_type'       => 'post',
        'posts_per_page'  =>  sunrise_posts_per_page_of_page_template(),
        'post_status'     => 'publish',
        'paged'           => $paged
    );

    $cats = sunrise_get_categories();

    if ( !empty($cats) )
    {
        $args['category__in'] = $cats;
    }
}
if ( !empty(SunriseBlogFramework::$piFeaturedPostsId) )
{
    $args['post__not_in'] = SunriseBlogFramework::$piFeaturedPostsId;
}

?>
<div class="main-content <?php echo esc_attr($sectionClass); ?>">
    <div class="pi-container">
        <div class="pi-row">
            <div class="pi-content">
                <?php
                if ( isset($args) )
                {
                    if ( sunrise_is_static_front_page($post->ID) )
                    {
                        $paged =  get_query_var('page');
                    }else{
                        $paged =  get_query_var('paged');
                    }
                    $paged =  $paged ? $paged : 1;
                    $args['paged'] = $paged;

                    /**/
                    query_posts($args);
                }

                $piOrder = 1;
                if ( have_posts() ) : while ( have_posts() ) : the_post();
                    get_template_part("layout/".$layout);
                    $piOrder++;
                endwhile;
                    get_template_part("navigation");
                else:
                    get_template_part("content", "none");
                endif;
                wp_reset_postdata();
                ?>
            </div>
            <?php
            if ( $sidebar != 'no-sidebar' )
            {
                get_sidebar();
            }
            ?>
        </div>
    </div>
</div>
<?php get_footer(); ?>