<?php
/**
 * Search
 * Created by Next-theme
 * @since 1.0
 */

add_action('pi_hook_before_logo', 'pi_add_search_section_to_logoheader_panel', 15, 3);
function pi_add_search_section_to_logoheader_panel($wp_customize, $piSectionPriority, $piControlPriority)
{
	$wp_customize->add_section(
		'pi_logoheader_search',
		array(
			'title' 	 => esc_html__('Search', 'sunrise'),
			'priority'	 => $piSectionPriority,
			'panel'		 => 'pi_logoheader_panel',
            'description'=> esc_html__('Displaying the search form at the top menu or no', 'sunrise'),
		)
	);

	$wp_customize->add_setting(
        'pi_options[logoheader][search]',
        array(
            'default'           =>  1,
            'type'              => 'option',
            'capability'        => 'edit_theme_options',
            'sanitize_callback' => 'sunrise_sanitize_data'
        )
    );

    $wp_customize->add_control(
        'pi_options[logoheader][search]',
        array(
            'label'     => esc_html__('Enable/Disable', 'sunrise'),
            'type'      => 'select',
            'priority'  => $piControlPriority,
            'section'   => 'pi_logoheader_search',
            'settings'  => 'pi_options[logoheader][search]',
            'choices'   => array(
                1 => esc_html__('Enable', 'sunrise'),
                0 => esc_html__('Disable', 'sunrise')
            )
        )
    );

    $wp_customize->add_setting(
        "pi_options[logoheader][description]",
        array(
            'default'       =>  'Click The Icon To Show Search',
            'type'          => 'option',
            'capability'    => 'edit_theme_options',
            'sanitize_callback' => 'sunrise_sanitize_data'
        )
    );

    $wp_customize->add_control('pi_options[logoheader][description]',
        array(
            'label'     => esc_html__('Description', 'sunrise'),
            'section'   => 'pi_logoheader_search',
            'settings'  => 'pi_options[logoheader][description]',
            'priority'  => $piControlPriority++,
            'type'      => 'text'
        )
    );
}