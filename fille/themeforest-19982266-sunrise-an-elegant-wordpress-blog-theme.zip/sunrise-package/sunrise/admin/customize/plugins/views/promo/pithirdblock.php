<?php
function sunrise_promo_third_block()
{
    $link = SunriseBlogCustomize::sunrise_refresh_in_customize("pi_options[pi_promo][thirdblock][link]") ? SunriseBlogCustomize::sunrise_refresh_in_customize("pi_options[pi_promo][thirdblock][link]") : '';
    $link = empty($link) && isset(SunriseBlogFramework::$piOptions['pi_promo']['thirdblock']['link']) ? SunriseBlogFramework::$piOptions['pi_promo']['thirdblock']['link'] : $link;

    if ( empty($link) )
    {
        return;
    }

    $heading = SunriseBlogCustomize::sunrise_refresh_in_customize("pi_options[pi_promo][thirdblock][heading]") ? SunriseBlogCustomize::sunrise_refresh_in_customize("pi_options[pi_promo][thirdblock][heading]") : '';
    $heading = empty($heading) && isset(SunriseBlogFramework::$piOptions['pi_promo']['thirdblock']['heading']) ? SunriseBlogFramework::$piOptions['pi_promo']['thirdblock']['heading'] : $heading;

    $desc = SunriseBlogCustomize::sunrise_refresh_in_customize("pi_options[pi_promo][thirdblock][description]") ? SunriseBlogCustomize::sunrise_refresh_in_customize("pi_options[pi_promo][thirdblock][description]") : '';
    $desc = empty($desc) && isset(SunriseBlogFramework::$piOptions['pi_promo']['thirdblock']['description']) ? SunriseBlogFramework::$piOptions['pi_promo']['thirdblock']['description'] : $desc;

    $bgImg = SunriseBlogCustomize::sunrise_refresh_in_customize("pi_options[pi_promo][thirdblock][bg_img]") ? SunriseBlogCustomize::sunrise_refresh_in_customize("pi_options[pi_promo][thirdblock][bg_img]") : '';
    $bgImg = empty($bgImg) && isset(SunriseBlogFramework::$piOptions['pi_promo']['thirdblock']['bg_img']) ? SunriseBlogFramework::$piOptions['pi_promo']['thirdblock']['bg_img'] : $bgImg;

    $target = SunriseBlogCustomize::sunrise_refresh_in_customize("pi_options[pi_promo][thirdblock][target]") ? SunriseBlogCustomize::sunrise_refresh_in_customize("pi_options[pi_promo][thirdblock][target]") : '';
    $target = empty($target) && isset(SunriseBlogFramework::$piOptions['pi_promo']['thirdblock']['target']) ? SunriseBlogFramework::$piOptions['pi_promo']['thirdblock']['target'] : $target;
    $target = !empty($target) ? $target : '_self';
    ob_start();
    ?>
    <div class="tb-cell">
        <div class="pi-promo-item">
            <a href="<?php echo esc_url($link); ?>" target="<?php echo esc_attr($target); ?>">
                <div class="image" style="background-image: url(<?php echo esc_url($bgImg); ?>);"></div>
                <div class="text">
                    <h3><?php echo esc_html($heading); ?></h3>
                    <span><?php sunrise_wp_kses($desc); ?></span>
                </div>
            </a>
            <div class="promo-overlay"></div>
        </div>
    </div>
    <?php
    $html = ob_get_contents();
    ob_end_clean();
    return $html;
}