<?php
/**
 * Archive Header
 * Created by Next-theme
 * @since 1.0
 */
$title = '';

if ( is_search() )
{
    $title = esc_html__('Search Results For', 'sunrise');
    $des   = get_search_query();
}elseif( is_category() )
{
    $title = esc_html__('Browsing category', 'sunrise');
    $des   = single_cat_title( '', false );
}elseif(is_tag())
{
    $title = esc_html__('Browsing tag', 'sunrise');
    $des   = single_tag_title('', false);
}elseif( is_author() )
{
    $title = esc_html__('All posts by', 'sunrise');
    $des   = get_the_author();
}elseif( is_archive() )
{
    if ( is_day() ) :
        $title = esc_html__('Daily Archives', 'sunrise');
        $des   = get_the_date();
    elseif ( is_month() ) :
        $title = esc_html__('Monthly Archives', 'sunrise');
        $des   = get_the_date( _x( 'F Y', 'monthly archives date format', 'sunrise') );
    elseif ( is_year() ) :
        $title = esc_html__('Yearly Archives', 'sunrise');
        $des   = get_the_date( _x( 'Y', 'yearly archives date format', 'sunrise')  );
    else :
        $title = esc_html__( 'Archives', 'sunrise');
    endif;
}

if ( !empty($des) )
{
    $title =  '<span>' . $title . '</span>' . '<h1>' . $des . '</h1>';
}

if ( !empty($title) ) :
    ?>
    <!-- BLOG HEADING -->
    <div class="category-page-title">
        <div class="container">
            <div class="wrap-title"><?php sunrise_wp_kses($title); ?></div>
        </div>
    </div>
    <!-- END / BLOG HEADING -->
<?php
endif;
