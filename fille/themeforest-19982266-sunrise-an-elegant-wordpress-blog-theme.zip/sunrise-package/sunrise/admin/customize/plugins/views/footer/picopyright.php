<?php
/**
 * Created by Next-theme
 */

function sunrise_render_copyright()
{
    $copyright = SunriseBlogCustomize::sunrise_refresh_in_customize("pi_options[footer][copyright]") ? SunriseBlogCustomize::sunrise_refresh_in_customize("pi_options[footer][copyright]") : SunriseBlogFramework::$piOptions['footer']['copyright'];

    if ( $copyright )
    {
        do_action('pi_before_copyright');
        if ( has_filter('sunrise_render_copyright') )
        {
            $copyright = apply_filters('sunrise_render_copyright', $copyright);
        }else{
            $copyright = '<div class="pi-copyright copyright text-center"><p>'.esc_html($copyright).'</p></div>';
        }
        sunrise_wp_kses($copyright);
        do_action('pi_after_copyright');
    }

}