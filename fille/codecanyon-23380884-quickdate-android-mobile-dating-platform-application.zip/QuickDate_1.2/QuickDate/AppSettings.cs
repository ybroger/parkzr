﻿//###############################################################
// Author >> Elin Doughouz 
// Copyright (c) PixelPhoto 15/07/2018 All Right Reserved
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
// Follow me on facebook >> https://www.facebook.com/Elindoughous
//=========================================================

namespace QuickDate
{
    public class AppSettings
    {
        public AppSettings()
        {
            TripleDesAppServiceProvider = "IbxeixrTQTIbjj2d58d1xaCBtkmMIouSbpvxhv2w9P4tm2nP94+yDXPrOSeBAbGWZEfmKfOjkpfVj5JpyG5CRXiFjjDhllJgUYMbpPSx6QgknYwzHPH9phNTIS2x7ppmTHfzqtvnuAsODc+9pBWxeIppvJSIDxr5zNdmL50k32yZYpRi5sWMn0wRpjSFzuye4dt+9YvbzHI3p4EtpaXEe+drVf2JYrssOCsIEigbOrk=";
        }

        //Main Settings >>>>>
        //*********************************************************
        public string TripleDesAppServiceProvider;

        public string Version = "1.1";
        public static string ApplicationName = "QuickDate";

        //Main Colors >>
        //*********************************************************
        public static string MainColor = "#a33596";
        public static string StartColor = MainColor;
        public static string EndColor = "#63245c";

        //Language Settings >> For next update versions 
        //*********************************************************
        public static bool FlowDirectionRightToLeft = false;
        public static string Lang = ""; //Default language

        //Notification Settings >>
        //*********************************************************
        public static bool ShowNotification = true;
        public static int RefreshDataSeconds = 10000; // 10 Seconds

        //*********************************************************

        //Add Animation Image User
        //*********************************************************
        public static bool EnableAddAnimationImageUser = false;
         
        //Set Theme Full Screen App
        //*********************************************************
        public static bool EnableFullScreenApp = false;

        //Set In App Billing Google
        //*********************************************************
        public static bool EnableInAppBillingGoogle = false; // Next Version

        //Social Logins >>
        //If you want login with facebook or google you should change id key in the String.xml file or AndroidManifest.xml
        //Facebook >> ../values/Strings.xml .. line 18 - 19 
        //Google >> ../Properties/AndroidManifest.xml .. line 52
        //*********************************************************
        public static bool ShowFacebookLogin = true;
        public static bool ShowGoogleLogin = false; // Next Version

        //ADMOB >> Please add the code ads in the Here and Strings.xml 
        //*********************************************************
        public static bool ShowAdmobBanner = true;
        public static bool ShowAdmobInterstitial = true;
        public static bool ShowAdmobRewardVideo = true;
         
        public static string AdAppId = "ca-app-pub-5135691635931982~6131426175";
        public static string AdInterstitialKey = "ca-app-pub-5135691635931982/5365139416";
        public static string AdRewardVideoKey = "ca-app-pub-5135691635931982/3896021367";

        //Three times after entering the ad is displayed
        public static int ShowAdmobInterstitialCount = 2;
        public static int ShowAdmobRewardedVideoCount = 2;
         
        //########################### 

        //Last_Messages Page >>
        ///********************************************************* 
        public static bool RunSoundControl = true;
        public static int RefreshChatActivitiesSeconds = 6000; // 6 Seconds
        public static int MessageRequestSpeed = 3000; // 3 Seconds
                  
        //Set Theme Tab
        //*********************************************************
        public static bool SetTabColoredTheme = false;
        public static bool SetTabDarkTheme = false;

        public static string TabColoredColor = MainColor;
        public static bool SetTabIsTitledWithText = false;

        //Bypass Web Errors  
        //*********************************************************
        public static bool TurnTrustFailureOnWebException = true;
        public static bool TurnSecurityProtocolType3072On = true;

        //Show custom error reporting page
        public static bool RenderPriorityFastPostLoad = true;
    }
}
