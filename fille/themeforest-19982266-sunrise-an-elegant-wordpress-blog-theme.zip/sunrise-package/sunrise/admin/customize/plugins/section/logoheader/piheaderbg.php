<?php
/**
 * Created by Next-theme
 */

$wp_customize->add_section(
    'pi_headerbg',
    array(
        'title'     => esc_html__('Header Background', 'sunrise'),
        'panel'     => 'pi_logoheader_panel',
        'priority'  => $this->piSectionPriority++
    )
);

$wp_customize->add_setting(
    'pi_options[logoheader][headerbg]',
    array(
        'default'       =>  esc_url(parent::$piOptions['logoheader']['headerbg']),
        'type'          => 'option',
        'capability'    => 'edit_theme_options',
        'sanitize_callback' => array($this, 'sunrise_sanitize_data')
    )
);

$wp_customize->add_control(
    new WP_Customize_Image_Control(
        $wp_customize,
        'pi_options[logoheader][headerbg]',
        array(
            'label'      => esc_html__( 'Upload', 'sunrise'),
            'section'    => 'pi_headerbg',
            'settings'   => 'pi_options[logoheader][headerbg]',
        )
    )
);

$wp_customize->add_setting(
    'pi_desc_headerbg',
    array(
        'default'   =>'',
        'type'      =>'',
        'capability'=>'edit_theme_options',
        'sanitize_callback' =>  'sunrise_sanitize_data'
    )
);
$wp_customize->add_control(
    new piDescription(
        $wp_customize,
        'pi_desc_headerbg',
        array(
            'label'    => sunrise_wp_kses( esc_html__('You should use an image smaller than 1200px', 'sunrise'), false ),
            'section'  => 'pi_headerbg',
            'settings' => 'pi_desc_headerbg',
            'priority' => $this->piSectionPriority++,
            'type'     => 'description'
        )
    )
);