<?php
/*Related Posts*/
function sunrise_render_related_posts()
{
    $status  = SunriseBlogCustomize::sunrise_refresh_in_customize("pi_options[content][related_posts][toggle]")  ? SunriseBlogCustomize::sunrise_refresh_in_customize("pi_options[related_posts][toggle]") : SunriseBlogFramework::$piOptions['content']['related_posts']['toggle'];

    $status  = $status == "disable" || $status == '0' ? 0 : $status;
    if ( !empty($status) )
    {
        do_action('pi_before_related_posts');

        $by = SunriseBlogCustomize::sunrise_refresh_in_customize('pi_options[content][related_posts][get_by]') ? SunriseBlogCustomize::sunrise_refresh_in_customize('pi_options[content][related_posts][get_by]') : SunriseBlogFramework::$piOptions['content']['related_posts']['get_by'];

        global $post;

        if ( $by != 'tag' )
        {
            $getTerms = get_the_category($post->ID);
            $key      = 'category__in';
        }else{
            $getTerms = wp_get_post_tags($post->ID);
            $key      = 'tag__in';
        }

        if ( $getTerms ) :

            foreach ( $getTerms as $term )
            {
                $aBy[] = $term->term_id;
            }

            $args=array(
                'post__not_in'          => array($post->ID),
                'posts_per_page'        => 3,
                'ignore_sticky_posts'   => 1
            );

            $args[$key] = $aBy;

            $query = new WP_Query($args);
            if( $query->have_posts() ) :
                ?>
                <div class="related-post pi-related_posts">
                    <?php  sunrise_render_related_posts_title(); ?>
                    <div class="pi-row">
                        <?php
                        while ($query->have_posts()) : $query->the_post();
                            ?>
                            <?php if ( has_post_thumbnail() ) : ?>
                            <div class="pi-three-column">
                                <div class="related-post-item">
                                    <div class="post-media">
                                        <div class="image-wrap">

                                            <a href="<?php the_permalink(); ?>" rel="bookmark">
                                            <?php the_post_thumbnail( array(245, 165) ); ?>
                                            </a>

                                        </div>
                                    </div>
                                    <div class="post-body">
                                        <div class="post-title">
                                            <h2><a href="<?php the_permalink(); ?>" rel="bookmark"><?php the_title(); ?></a></h2>
                                        </div>
                                        <div class="post-date">
                                            <span><?php echo sunrise_get_the_date($post->ID, 'M d, Y'); ?></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php endif; ?>
                        <?php
                        endwhile;
                        ?>
                    </div>
                </div>
            <?php
            endif;wp_reset_postdata();
        endif;
        do_action('pi_after_related_posts');
    }
}
function sunrise_render_related_posts_title()
{
    $title  = SunriseBlogCustomize::sunrise_refresh_in_customize("pi_options[content][related_posts][title]")  ? SunriseBlogCustomize::sunrise_refresh_in_customize("pi_options[content][related_posts][title]") : SunriseBlogFramework::$piOptions['content']['related_posts']['title'];

    if ( !empty($title) )
    {
        do_action('pi_before_related_posts_title');
        if ( has_filter('pi_related_posts_title') )
        {
            $title = apply_filters('pi_related_posts_title', $title);
        }else{
            $title = '<h3 class="related-post-title">'.$title.'</h3>';
        }
        sunrise_wp_kses($title);
        do_action('pi_after_related_posts_title');
    }

}
