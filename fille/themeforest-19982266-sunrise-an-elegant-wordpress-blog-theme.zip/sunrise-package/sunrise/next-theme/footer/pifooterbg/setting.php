<?php
/**
 * Created by Next-theme
 */

add_action('pi_hook_before_footerjs', 'pi_add_footer_bg', 10, 3);
function pi_add_footer_bg($wp_customize, $sectionPrior, $controlPrior)
{
    $wp_customize->add_section(
        'pi_footer_bg',
        array(
            'title'     => esc_html__('Footer Background', 'sunrise'),
            'panel'     => 'pi_footer_panel',
            'priority'  => $sectionPrior
        )
    );

    $wp_customize->add_setting(
        'pi_options[footer][footerbg]',
        array(
            'default'           =>  '',
            'type'              => 'option',
            'capability'        => 'edit_theme_options',
            'sanitize_callback' => 'sunrise_sanitize_data'
        )
    );

    $wp_customize->add_control(
        new WP_Customize_Image_Control(
            $wp_customize,
            'pi_options[footer][footerbg]',
            array(
                'label'      => esc_html__( 'Upload', 'sunrise'),
                'section'    => 'pi_footer_bg',
                'settings'   => 'pi_options[footer][footerbg]',
            )
        )
    );

    $wp_customize->add_setting(
        'pi_desc_footer_bg',
        array(
            'default'   =>'',
            'type'      =>'',
            'capability'=>'edit_theme_options',
            'sanitize_callback' =>  'sunrise_sanitize_data'
        )
    );
    $wp_customize->add_control(
        new piDescription(
            $wp_customize,
            'pi_desc_footer_bg',
            array(
                'label'    => sunrise_wp_kses( esc_html__('You should use an image smaller than 1200px', 'sunrise'), false ),
                'section'  => 'pi_footer_bg',
                'settings' => 'pi_desc_footer_bg',
                'priority' => $controlPrior++,
                'type'     => 'description'
            )
        )
    );
}