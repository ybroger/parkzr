<?php
/**
 * Created by Next-theme
 */

$wp_customize->add_section('pi_promo_secondblock', array(
    'title'     => esc_html__('Second Block', 'sunrise'),
    'panel'     => 'pi_promo_panel',
    'priority'  => $this->piSectionPriority++
));


$wp_customize->add_setting(
    "pi_options[pi_promo][secondblock][heading]",
    array(
        'default'       =>  '',
        'type'          => 'option',
        'capability'    => 'edit_theme_options',
        'sanitize_callback' => array($this, 'sunrise_sanitize_data')
    )
);
$wp_customize->add_control('pi_options[pi_promo][secondblock][heading]',
    array(
        'label' 	=> esc_html__('Heading', 'sunrise'),
        'section' 	=> 'pi_promo_secondblock',
        'settings' 	=> 'pi_options[pi_promo][secondblock][heading]',
        'priority'  => $this->piControlPriority++,
        'type' 		=> 'text'
    )
);

$wp_customize->add_setting(
    "pi_options[pi_promo][secondblock][description]",
    array(
        'default'       =>  '',
        'type'          => 'option',
        'capability'    => 'edit_theme_options',
        'sanitize_callback' => array($this, 'sunrise_sanitize_data')
    )
);
$wp_customize->add_control('pi_options[pi_promo][secondblock][description]',
    array(
        'label'     => esc_html__('Description', 'sunrise'),
        'section'   => 'pi_promo_secondblock',
        'settings'  => 'pi_options[pi_promo][secondblock][description]',
        'priority'  => $this->piControlPriority++,
        'type'      => 'text'
    )
);

$wp_customize->add_setting(
    "pi_options[pi_promo][secondblock][link]",
    array(
        'default'       =>  '',
        'type'          => 'option',
        'capability'    => 'edit_theme_options',
        'sanitize_callback' => array($this, 'sunrise_sanitize_data')
    )
);
$wp_customize->add_control('pi_options[pi_promo][secondblock][link]',
    array(
        'label' 	=> esc_html__('Link', 'sunrise'),
        'section' 	=> 'pi_promo_secondblock',
        'settings' 	=> 'pi_options[pi_promo][secondblock][link]',
        'priority'  => $this->piControlPriority++,
        'type' 		=> 'text'
    )
);

$wp_customize->add_setting(
    "pi_options[pi_promo][secondblock][target]",
    array(
        'default'       =>  '_self',
        'type'          => 'option',
        'capability'    => 'edit_theme_options',
        'sanitize_callback' => array($this, 'sunrise_sanitize_data')
    )
);
$wp_customize->add_control('pi_options[pi_promo][secondblock][target]',
    array(
        'label' 	=> esc_html__('When user click on this box, where to open the link.', 'sunrise'),
        'section' 	=> 'pi_promo_secondblock',
        'settings' 	=> 'pi_options[pi_promo][secondblock][target]',
        'priority'  => $this->piControlPriority++,
        'type' 		=> 'select',
        'choices'   => array(
            '_self'  => esc_html__('Self', 'sunrise'),
            '_blank' => esc_html__('New Window', 'sunrise')
        )
    )
);

$wp_customize->add_setting(
    "pi_options[pi_promo][secondblock][bg_img]",
    array(
        'default'       =>  '',
        'type'          => 'option',
        'capability'    => 'edit_theme_options',
        'sanitize_callback' => array($this, 'sunrise_sanitize_data')
    )
);
$wp_customize->add_control(
    new WP_Customize_Image_Control(
        $wp_customize,
        'pi_options[pi_promo][secondblock][bg_img]',
        array(
            'label'     => esc_html__('Background Image', 'sunrise'),
            'section'   => 'pi_promo_secondblock',
            'settings'  => 'pi_options[pi_promo][secondblock][bg_img]',
            'priority'=>$this->piControlPriority++
        )
    )
);
