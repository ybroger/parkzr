<?php
/**
 * Render custom js
 */
function sunrise_render_footer_custom_js()
{
	if ( SunriseBlogCustomize::sunrise_refresh_in_customize('pi_options[footer][custom_js]') ) {
		$customJs = SunriseBlogCustomize::sunrise_refresh_in_customize('pi_options[footer][custom_js]');
	}else if ( isset(SunriseBlogFramework::$piOptions['footer']['custom_js']) ){
		$customJs = SunriseBlogFramework::$piOptions['footer']['custom_js'];
	}else{
		$customJs = '';
	}
    return $customJs;
}
