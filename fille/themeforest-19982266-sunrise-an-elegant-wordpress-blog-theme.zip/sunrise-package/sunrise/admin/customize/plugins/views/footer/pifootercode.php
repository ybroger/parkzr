<?php
/**
 * Render Footer Code
 */
function sunrise_render_footer_custom_code()
{
    $customCode = SunriseBlogCustomize::sunrise_refresh_in_customize("pi_options[footer][footer_code]") ? SunriseBlogCustomize::sunrise_refresh_in_customize("pi_options[footer][footer_code]") : SunriseBlogFramework::$piOptions['footer']['footer_code'];
    if ( $customCode !='' )
    {
        $customCode = str_replace("&#039", '\'', $customCode);
        sunrise_wp_kses($customCode)."\n";
    }
}
