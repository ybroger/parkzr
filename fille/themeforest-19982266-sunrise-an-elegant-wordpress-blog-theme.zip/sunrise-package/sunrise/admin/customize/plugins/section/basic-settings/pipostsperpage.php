<?php
/**
 * Set number of posts per page
 * @since 1.0
 */
$wp_customize->add_section('pi_posts_per_page', array(
    'title'     => esc_html__('Posts per page', 'sunrise'),
    'panel'     => 'sunrise_basic_settings_panel',
    'priority'  => $this->piSectionPriority++
));

$wp_customize->add_setting(
    'posts_per_page',
    array(
        'default'           =>  get_option('posts_per_page'),
        'type'              =>  'option',
        'capability'        =>  'edit_theme_options',
        'sanitize_callback' =>  array($this, 'sunrise_sanitize_data')
    )
);
$wp_customize->add_control(
    'posts_per_page',
    array(
        'label'             => '',
        'section'           => 'pi_posts_per_page',
        'settings'          => 'posts_per_page',
        'priority'          => $this->piControlPriority++,
        'type'              => 'text',
        'active_callback'   => array($this, 'pi_is_not_page_template')
    )
);


/**
 * In the case of page template
 */


$wp_customize->add_setting(
    'pi_options[basic_settings][posts_per_page]',
    array(
        'default'           =>  get_option('posts_per_page'),
        'type'              =>  'option',
        'capability'        =>  'edit_theme_options',
        'sanitize_callback' =>  array($this, 'sunrise_sanitize_data')
    )
);

$wp_customize->add_control( 'pi_options[basic_settings][posts_per_page]',
    array(
        'label'           => '',
        'section'         => 'pi_posts_per_page',
        'settings'        => 'pi_options[basic_settings][posts_per_page]',
        'type'            => 'text',
        'active_callback' => array($this, 'sunrise_is_page_template')
    )
);
