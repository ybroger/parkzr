﻿using System;
using System.Collections.Generic;
using System.Net;
using Android.App;
using Android.Content;
using Android.Content.Res;
using Android.Graphics;
using Android.Views;
using Android.Widget;
using Com.Nostra13.Universalimageloader.Core;
using Com.Nostra13.Universalimageloader.Core.Assist;
using Com.Nostra13.Universalimageloader.Core.Display;
using Com.Nostra13.Universalimageloader.Core.Listener;
using Com.Nostra13.Universalimageloader.Utils;
using Java.IO;
using Java.Lang;
using QuickDate.Helpers.Utils;
using Console = System.Console;
using Exception = System.Exception;

namespace QuickDate.Helpers.CacheLoaders
{
    public class ImageCacheLoader
    {
        public static DisplayImageOptions DefaultOptions;
        public static DisplayImageOptions CircleOptions;
        public static DisplayImageOptions RoundedOptions;
        public static ImageSize SizeMinimized = new ImageSize(30, 30);

        public static void InitImageLoader(Context context)
        {
            try
            {
                SetImageOption();

                ImageLoaderConfiguration config = new ImageLoaderConfiguration.Builder(context)
                    .ThreadPriority(Thread.NormPriority - 2)
                    .TasksProcessingOrder(QueueProcessingType.Lifo)
                    .DefaultDisplayImageOptions(DefaultOptions)
                    .DiskCacheSize(100 * 1024 * 1024)
                    .Build();

                ImageLoader.Instance.SetDefaultLoadingListener(new ImageLoadingListener());

                if (!ImageLoader.Instance.IsInited)
                    ImageLoader.Instance.Init(config);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public static void SetImageOption()
        {
            try
            {
                DefaultOptions = new DisplayImageOptions.Builder()
                    .ShowImageOnLoading(Resource.Drawable.ImagePlacholder)
                    .ShowImageForEmptyUri(Resource.Drawable.ImagePlacholder)
                    .ShowImageOnFail(Resource.Drawable.ImagePlacholder)
                    .CacheInMemory(true)
                    .CacheOnDisk(true)
                    .ConsiderExifParams(true)
                    .Displayer(new FadeInBitmapDisplayer(500))
                    .ImageScaleType(ImageScaleType.Exactly)
                    .Build();

                CircleOptions = new DisplayImageOptions.Builder()
                    .ShowImageOnLoading(Resource.Drawable.ImagePlacholder_circle)
                    .ShowImageForEmptyUri(Resource.Drawable.ImagePlacholder_circle)
                    .ShowImageOnFail(Resource.Drawable.ImagePlacholder_circle)
                    .CacheInMemory(true)
                    .CacheOnDisk(true)
                    .ConsiderExifParams(true)
                    .Displayer(new FadeInBitmapDisplayer(500)).Displayer(new CircleBitmapDisplayer())
                    .ImageScaleType(ImageScaleType.Exactly)
                    .Build();
                 
                RoundedOptions = new DisplayImageOptions.Builder()
                    .ShowImageOnLoading(Resource.Drawable.ImagePlacholder)
                    .ShowImageForEmptyUri(Resource.Drawable.ImagePlacholder)
                    .ShowImageOnFail(Resource.Drawable.ImagePlacholder)
                    .CacheInMemory(true)
                    .CacheOnDisk(true)
                    .ConsiderExifParams(true)
                    .Displayer(new FadeInBitmapDisplayer(500)).Displayer(new RoundedBitmapDisplayer(20))
                    .ImageScaleType(ImageScaleType.Exactly) 
                    .Build();

            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="url">any url like websites or disk or storage will work</param>
        /// <param name="image">ImageView view</param>
        /// <param name="downsized"> compress the image to 100 x 100 px</param>
        /// <param name="circle">Set to true with Downsized true if you want to display the image as circle</param>
        public static void LoadImage(string url, ImageView image, bool downsized, bool circle)
        {
            try
            {
                var options = DefaultOptions;

                if (circle)
                    options = CircleOptions;

                if (downsized)
                {
                    ImageLoader.Instance.LoadImage(url, options, new WithParamImageLoadingListener(image, circle));
                }
                else
                {
                    if (url.Contains("FirstImageOne") || url.Contains("FirstImageTwo") || url.Contains("no_profile_image") ||
                        url.Contains("no_profile_image_circle") || url.Contains("ImagePlacholder") || url.Contains("ImagePlacholder_circel"))
                    {
                        Resources res = Application.Context.Resources;

                        if (circle)
                        {
                            Bitmap myBitmap;
                            if (url.Contains("FirstImageOne"))
                                myBitmap = BitmapFactory.DecodeResource(res, Resource.Drawable.FirstImageOne);
                            else if (url.Contains("FirstImageTwo"))
                                myBitmap = BitmapFactory.DecodeResource(res, Resource.Drawable.FirstImageTwo);
                            else if (url.Contains("no_profile_image_circle"))
                                myBitmap = BitmapFactory.DecodeResource(res, Resource.Drawable.no_profile_image_circle);
                            else if (url.Contains("no_profile_image"))
                                myBitmap = BitmapFactory.DecodeResource(res, Resource.Drawable.no_profile_image);
                            else if (url.Contains("ImagePlacholder"))
                                myBitmap = BitmapFactory.DecodeResource(res, Resource.Drawable.ImagePlacholder);
                            else if (url.Contains("ImagePlacholder_circel"))
                                myBitmap = BitmapFactory.DecodeResource(res, Resource.Drawable.ImagePlacholder_circle);
                            else
                                myBitmap = BitmapFactory.DecodeResource(res, Resource.Drawable.no_profile_image);

                            Bitmap croppedBitmap = GetCroppedBitmap(myBitmap);
                            image.SetImageBitmap(croppedBitmap);
                        }
                        else
                        {
                            if (url.Contains("FirstImageOne"))
                                image.SetImageResource(Resource.Drawable.FirstImageOne);
                            else if (url.Contains("FirstImageTwo"))
                                image.SetImageResource(Resource.Drawable.FirstImageTwo);
                            else if (url.Contains("no_profile_image_circle"))
                                image.SetImageResource(Resource.Drawable.no_profile_image_circle);
                            else if (url.Contains("no_profile_image"))
                                image.SetImageResource(Resource.Drawable.no_profile_image);
                            else if (url.Contains("ImagePlacholder"))
                                image.SetImageResource(Resource.Drawable.ImagePlacholder);
                            else if (url.Contains("ImagePlacholder_circel"))
                                image.SetImageResource(Resource.Drawable.ImagePlacholder_circle);
                            else
                                image.SetImageResource(Resource.Drawable.no_profile_image);
                        }
                    }
                    else if (!string.IsNullOrEmpty(url) && (url.Contains("file://") || url.Contains("content://") || url.Contains("storage")))
                    {
                        ImageLoader.Instance.DisplayImage(url, image, options, new WithParamImageLoadingListener(image, circle));
                    }
                    else
                    {
                        ImageLoader.Instance.DisplayImage(url, image, options);
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public static void LoadRoundedImage(string url, ImageView image, bool downsized)
        {
            try
            {
                var options = RoundedOptions;
                ImageLoader.Instance.DisplayImage(url, image, options, new WithParamImageLoadingListener(image, false)); 
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
         
        public class ImageLoadingListener : Java.Lang.Object, IImageLoadingListener
        {
            public bool CacheFound = false;
            public void OnLoadingCancelled(string imageUri, View view)
            {

            }

            public void OnLoadingComplete(string imageUri, View view, Bitmap loadedImage)
            {
                try
                {
                    
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                }
            }

            public void OnLoadingFailed(string imageUri, View view, FailReason failReason)
            {

            }

            public void OnLoadingStarted(string imageUri, View view)
            {
                try
                { 
                    IList<string> memCache = MemoryCacheUtils.FindCacheKeysForImageUri(imageUri, ImageLoader.Instance.MemoryCache);
                    if (memCache?.Count != 0)
                    {
                        CacheFound = true;
                    }

                    if (!CacheFound)
                    {
                        File discCache = DiskCacheUtils.FindInCache(imageUri, ImageLoader.Instance.DiskCache);
                        if (discCache != null)
                        {
                            CacheFound = discCache.Exists();
                        }
                    }
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                }
            }
        }

        public class WithParamImageLoadingListener : Java.Lang.Object, IImageLoadingListener
        {
            public ImageView Image;
            public bool Circle;
            public bool CacheFound = false;

            public WithParamImageLoadingListener(ImageView image, bool circle)
            {
                try
                {
                    Image = image;
                    Circle = circle;
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                }
            }

            public void OnLoadingCancelled(string imageUri, View view)
            {

            }

            public void OnLoadingComplete(string imageUri, View view, Bitmap loadedImage)
            {
                try
                {
                    if (view != null)
                    {
                        
                    }
                    else
                    {
                        if (Circle)
                        {
                            Bitmap croppedBitmap = GetCroppedBitmap(loadedImage);
                            Image.SetImageBitmap(croppedBitmap);
                        }
                        else
                        {
                            Image.SetImageBitmap(loadedImage);
                        }
                    }
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                }
            }

            public void OnLoadingFailed(string imageUri, View view, FailReason failReason)
            {
                try
                {
                    GC.Collect();

                    Bitmap myBitmap;
                    Resources res = Application.Context.Resources;
                     
                    if (imageUri.Contains("FirstImageOne") || imageUri.Contains("FirstImageTwo") || imageUri.Contains("no_profile_image") ||
                        imageUri.Contains("no_profile_image_circle") || imageUri.Contains("ImagePlacholder") ||imageUri.Contains("ImagePlacholder_circel"))
                    {
                        if (Circle)
                        {
                            if (imageUri.Contains("FirstImageOne"))
                                myBitmap = BitmapFactory.DecodeResource(res, Resource.Drawable.FirstImageOne);
                            else if (imageUri.Contains("FirstImageTwo"))
                                myBitmap = BitmapFactory.DecodeResource(res, Resource.Drawable.FirstImageTwo);
                            else if (imageUri.Contains("no_profile_image_circle"))
                                myBitmap = BitmapFactory.DecodeResource(res, Resource.Drawable.no_profile_image_circle);
                            else if (imageUri.Contains("no_profile_image"))
                                myBitmap = BitmapFactory.DecodeResource(res, Resource.Drawable.no_profile_image);
                            else if (imageUri.Contains("ImagePlacholder"))
                                myBitmap = BitmapFactory.DecodeResource(res, Resource.Drawable.ImagePlacholder);
                            else if (imageUri.Contains("ImagePlacholder_circel"))
                                myBitmap = BitmapFactory.DecodeResource(res, Resource.Drawable.ImagePlacholder_circle);
                            else
                                myBitmap = BitmapFactory.DecodeResource(res, Resource.Drawable.no_profile_image);

                            Bitmap croppedBitmap = GetCroppedBitmap(myBitmap);
                            Image.SetImageBitmap(croppedBitmap);
                        }
                        else
                        {
                            if (imageUri.Contains("FirstImageOne"))
                                Image.SetImageResource(Resource.Drawable.FirstImageOne);
                            else if (imageUri.Contains("FirstImageTwo"))
                                Image.SetImageResource(Resource.Drawable.FirstImageTwo);
                            else if (imageUri.Contains("no_profile_image_circle"))
                                Image.SetImageResource(Resource.Drawable.no_profile_image_circle);
                            else if (imageUri.Contains("no_profile_image"))
                                Image.SetImageResource(Resource.Drawable.no_profile_image);
                            else if (imageUri.Contains("ImagePlacholder"))
                                Image.SetImageResource(Resource.Drawable.ImagePlacholder);
                            else if (imageUri.Contains("ImagePlacholder_circel"))
                                Image.SetImageResource(Resource.Drawable.ImagePlacholder_circle);
                            else
                                Image.SetImageResource(Resource.Drawable.no_profile_image); 
                        }
                    }
                    else if (!string.IsNullOrEmpty(imageUri) && imageUri.Contains("http"))
                    {
                        Bitmap bitmap = GetImageBitmapFromUrl(imageUri);
                        if (Circle)
                        {
                            Bitmap croppedBitmap = GetCroppedBitmap(bitmap);
                            Image.SetImageBitmap(croppedBitmap);
                        }
                        else
                        {
                            Image.SetImageBitmap(bitmap);
                        }
                    }
                    else if (!string.IsNullOrEmpty(imageUri) && (imageUri.Contains("file://") || imageUri.Contains("content://") || imageUri.Contains("storage")))
                    {
                        var file = Android.Net.Uri.FromFile(new File(imageUri));
                        myBitmap = BitmapFactory.DecodeFile(file.Path);
                        if (Circle)
                        {
                            Bitmap croppedBitmap = GetCroppedBitmap(myBitmap);
                            Image.SetImageBitmap(croppedBitmap);
                        }
                        else
                        {
                            try
                            {
                                if (myBitmap != null)
                                {
                                    Image.SetImageBitmap(myBitmap);
                                }
                                else
                                {
                                    BitmapFactory.Options options = new BitmapFactory.Options();
                                    options.InSampleSize = 2;
                                    Bitmap bitmap = BitmapFactory.DecodeFile(file.Path, options);
                                    Image.SetImageBitmap(bitmap);
                                }
                            }
                            catch (OutOfMemoryError ex)
                            {
                                GC.Collect();
                                Console.WriteLine(ex);
                            }
                            catch (Exception e)
                            {
                                Console.WriteLine(e);
                            } 
                        }
                    }
                    else
                    {
                        Image.SetImageResource(Resource.Drawable.no_profile_image);
                    } 
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                }
            }
             
            public Bitmap GetImageBitmapFromUrl(string url)
            {
                if (IMethods.CheckConnectivity())
                    using (var webClient = new WebClient())
                    {
                        var imageBytes = webClient.DownloadData(url);
                        if (imageBytes != null && imageBytes.Length > 0)
                            return BitmapFactory.DecodeByteArray(imageBytes, 0, imageBytes.Length);
                    }

                return null;
            }

            private Bitmap AddBorderBitmap(Bitmap bitmap, int borderSize)
            {
                try
                {
                    Bitmap bmpWithBorder = Bitmap.CreateBitmap(bitmap.Width + borderSize * 2, bitmap.Height + borderSize * 2, bitmap.GetConfig());
                    Canvas canvas = new Canvas(bmpWithBorder);
                    canvas.DrawColor(Color.Red);
                    canvas.DrawBitmap(bitmap, borderSize, borderSize, null);
                    return bmpWithBorder;
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                    return bitmap;
                }
            }

            public void OnLoadingStarted(string imageUri, View view)
            {
                try
                {
                     
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                }
            }
        }


        public static Bitmap GetCroppedBitmap(Bitmap bitmap)
        {
            try
            {
                Bitmap output = Bitmap.CreateBitmap(bitmap.Width, bitmap.Height, Bitmap.Config.Argb8888);
                Canvas canvas = new Canvas(output);

                Color color = Color.ParseColor("#424242");
                Paint paint = new Paint();
                Rect rect = new Rect(0, 0, bitmap.Width, bitmap.Height);

                paint.AntiAlias = true;
                canvas.DrawARGB(0, 0, 0, 0);
                paint.Color = color;
                // canvas.drawRoundRect(rectF, roundPx, roundPx, paint);
                canvas.DrawCircle(bitmap.Width / 2, bitmap.Height / 2, bitmap.Width / 2, paint);

                paint.SetXfermode(new PorterDuffXfermode(PorterDuff.Mode.SrcIn));
                canvas.DrawBitmap(bitmap, rect, rect, paint);
                //Bitmap _bmp = Bitmap.createScaledBitmap(output, 60, 60, false);
                //return _bmp;
                return output;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                return bitmap;
            }
        }

    }
}