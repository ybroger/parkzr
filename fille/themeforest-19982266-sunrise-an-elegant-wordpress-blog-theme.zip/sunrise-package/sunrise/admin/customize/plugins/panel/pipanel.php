<?php
/**
 * Hook into before  panels
 */
do_action('pi_hook_before_panels', $wp_customize, array('panel_order'=>$this->piPanelPriority, 'section_order'=>$this->piSectionPriority, 'control_order'=>$this->piControlPriority));


do_action('pi_hook_before_panels', $wp_customize, $this->piPanelPriority);

/*Basic Settings*/
$wp_customize->add_panel( 'sunrise_basic_settings_panel', array(
    'priority'		 => $this->piPanelPriority++,
    'capability'     => 'edit_theme_options',
    'theme_supports' => '',
    'title'          => esc_html__('Basic Settings', 'sunrise')
) );
/*End/Basic Settings*/

/*Typography*/
$wp_customize->add_panel( 'pi_typography_panel', array(
    'priority'		 => $this->piPanelPriority++,
    'capability'     => 'edit_theme_options',
    'theme_supports' => '',
    'title'          => esc_html__('Typography', 'sunrise')
) );
/*End/Typography*/

/*Logo & Header*/
$wp_customize->add_panel( 'pi_logoheader_panel', array(
    'priority'		 => $this->piPanelPriority++,
    'capability'     => 'edit_theme_options',
    'theme_supports' => '',
    'title'          => esc_html__('Logo &amp; Header', 'sunrise')
) );
/*End/Logo & Header*/

/*Featured Posts*/
$wp_customize->add_panel( 'pi_featured_posts_panel', array(
    'priority'		 => $this->piPanelPriority++,
    'capability'     => 'edit_theme_options',
    'theme_supports' => '',
    'title'          => esc_html__('Featured Slider', 'sunrise')
) );
/*End/Featured Posts*/

/*Below Featured Posts*/
$wp_customize->add_panel( 'pi_promo_panel', array(
    'priority'		 => $this->piPanelPriority++,
    'capability'     => 'edit_theme_options',
    'theme_supports' => '',
    'title'          => esc_html__('Promo Area', 'sunrise')
) );
/*End/Below Featured Posts*/

/*Content*/
do_action('pi_hook_before_content_panel', $wp_customize, $this->piPanelPriority);
$wp_customize->add_panel( 'pi_content_panel', array(
    'priority'		 => $this->piPanelPriority++,
    'capability'     => 'edit_theme_options',
    'theme_supports' => '',
    'title'          => esc_html__('Content', 'sunrise')
) );
do_action('pi_hook_after_content_panel', $wp_customize, $this->piPanelPriority);
/*End/Content*/

/*Archive*/
$wp_customize->add_panel( 'pi_archive_panel', array(
    'priority'		 => $this->piPanelPriority++,
    'capability'     => 'edit_theme_options',
    'theme_supports' => '',
    'title'          => esc_html__('Archive', 'sunrise')
) );
/*End/Archive*/

/*Footer*/
$wp_customize->add_panel( 'pi_footer_panel', array(
    'priority'		 => $this->piPanelPriority++,
    'capability'     => 'edit_theme_options',
    'theme_supports' => '',
    'title'          => esc_html__('Footer', 'sunrise')
) );
/*End/Footer*/

do_action('pi_hook_after_panels', $wp_customize, $this->piPanelPriority);

/**
 * Hook into after panels
 */
do_action('pi_hook_after_panels', $wp_customize, array('panel_order'=>$this->piPanelPriority, 'section_order'=>$this->piSectionPriority, 'control_order'=>$this->piControlPriority));
