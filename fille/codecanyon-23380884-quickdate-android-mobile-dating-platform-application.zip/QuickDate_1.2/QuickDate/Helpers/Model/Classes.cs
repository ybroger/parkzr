﻿namespace QuickDate.Helpers.Model
{
    public class Classes
    {
         
         
    }
}